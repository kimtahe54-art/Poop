import { useEffect, useMemo, useState } from 'react';
import { Modal, RarityTag, Coin, fmt } from './ui';
import { EggArt } from './components/Egg';
import { Penguin } from './components/Penguin';
import { EGGS, NV, RARITY, THEMES, speciesName, speciesTier, speciesTheme } from './data/penguinData';
import { EggItem, Owned, buyEgg, breed, hatchEgg, specOf, toast, useG } from './store';
import { sfx } from './audio';

// ───────── 상점 ─────────
export function ShopPanel({ onClose }: { onClose: () => void }) {
  const s = useG();
  return (
    <Modal title="펭귄 상점" icon="🛍️" onClose={onClose} wide>
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <p className="text-sm text-pink-500 font-bold">코인으로 알을 사서 부화장에서 부화시켜요! 보유 알: {s.eggs.length}개</p>
        <Coin n={s.coins} className="text-lg text-amber-600" />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {EGGS.map((e) => {
          const tot = e.weights.reduce((a, b) => a + b, 0);
          const top = e.weights.map((w, i) => ({ w, i })).filter((x) => x.w > 0).pop()!;
          return (
            <div key={e.id} className="rounded-3xl bg-white border-4 border-pink-100 p-3 flex flex-col items-center text-center shadow-sm">
              <div style={{ animation: 'bob 2.4s ease-in-out infinite', animationDelay: e.id * 0.2 + 's' }}><EggArt type={e.id} size={64} /></div>
              <div className="font-bold text-pink-600 mt-1">{e.name}</div>
              <div className="text-[11px] text-gray-500 min-h-[32px] leading-tight">{e.desc}</div>
              <div className="text-[11px] mt-1 text-sky-600">최고 등급 <span style={{ color: RARITY[top.i].color }} className="font-bold">{RARITY[top.i].name}</span> {Math.round((top.w / tot) * 100)}%</div>
              <button className="btn-main px-4 py-1.5 mt-2 text-sm w-full" disabled={s.coins < e.price} onClick={() => { if (buyEgg(e.id)) { sfx('buy'); toast(`${e.name} 구매!`); } else sfx('error'); }}>
                <Coin n={e.price} className="justify-center text-white" />
              </button>
            </div>
          );
        })}
      </div>
    </Modal>
  );
}

// ───────── 부화장 ─────────
function HatchScene({ egg, onDone }: { egg: EggItem; onDone: (more: boolean) => void }) {
  const [phase, setPhase] = useState(0); // 0 흔들 1 균열 2 폭발 3 공개
  const [res, setRes] = useState<{ p: Owned; isNew: boolean } | null>(null);
  useEffect(() => {
    const had = new Set(useGSnapshot().dex);
    const p = hatchEgg(egg.uid);
    if (p) setRes({ p, isNew: !had.has(p.sid) });
    const ts = [
      setTimeout(() => { setPhase(1); sfx('crack'); }, 800), setTimeout(() => sfx('crack'), 1300), setTimeout(() => { setPhase(2); sfx('crack'); }, 1800),
      setTimeout(() => { setPhase(3); sfx('hatch'); }, 2300),
    ];
    sfx('wobble');
    const iv = setInterval(() => sfx('wobble'), 420);
    setTimeout(() => clearInterval(iv), 1800);
    return () => { ts.forEach(clearTimeout); clearInterval(iv); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const tier = res ? speciesTier(res.p.sid >= 0 ? res.p.sid : 0) : 0;
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-b from-indigo-900/90 to-pink-900/90">
      {phase < 3 && (
        <div className={phase === 2 ? 'scale-125 transition-transform duration-300' : ''}>
          <div className={phase < 2 ? 'shake' : ''}><EggArt type={egg.type} c1={egg.c1} c2={egg.c2} size={170} crack={phase === 0 ? 0 : phase === 1 ? 2 : 3} /></div>
          <p className="text-center text-white text-xl mt-6 font-bold">두근두근… 알이 움직여요!</p>
        </div>
      )}
      {phase === 2 && <div className="absolute inset-0 bg-white" style={{ animation: 'floatUp .5s forwards' }} />}
      {phase === 3 && res && (
        <div className="flex flex-col items-center pop-in px-4 text-center">
          <div className="relative">
            <div className="absolute inset-[-40px] rounded-full opacity-70 blur-2xl" style={{ background: RARITY[tier].glow }} />
            {Array.from({ length: 12 }, (_, i) => <span key={i} className="absolute text-2xl" style={{ left: '50%', top: '50%', transform: `rotate(${i * 30}deg) translateY(-150px)`, animation: 'twinkle 1.2s infinite', animationDelay: i * 0.1 + 's' }}>✨</span>)}
            <div className="relative" style={{ animation: 'bobBig 2s ease-in-out infinite' }}><Penguin spec={specOf(res.p)} size={190} /></div>
          </div>
          {res.isNew && <div className="mt-3 px-4 py-1 rounded-full bg-yellow-300 text-yellow-800 font-bold shadow animate-bounce">🎉 NEW! 도감 등록</div>}
          <div className="mt-3 text-white text-2xl font-bold">{res.p.name}</div>
          <div className="text-pink-100 text-lg">{speciesName(res.p.sid)}</div>
          <div className="mt-1"><RarityTag tier={tier} /></div>
          <div className="flex gap-3 mt-6">
            <button className="btn-main px-6 py-2 text-lg" onClick={() => onDone(true)}>다음 알 부화</button>
            <button className="btn-cute px-6 py-2 text-lg text-pink-500" onClick={() => onDone(false)}>확인</button>
          </div>
        </div>
      )}
    </div>
  );
}
import { getState } from './store';
const useGSnapshot = () => getState();

export function HatchPanel({ onClose, goShop }: { onClose: () => void; goShop: () => void }) {
  const s = useG();
  const [egg, setEgg] = useState<EggItem | null>(null);
  const groups = useMemo(() => s.eggs, [s.eggs]);
  const start = (e: EggItem) => { sfx('click'); setEgg(e); };
  return (
    <>
      <Modal title="부화장" icon="🐣" onClose={onClose} tone="yellow" wide>
        <p className="text-sm text-amber-700 font-bold mb-3">알을 누르면 부화가 시작돼요! 현재 알 {groups.length}개 · 펭귄 {s.pens.length}마리</p>
        {groups.length === 0 ? (
          <div className="text-center py-12"><div className="text-6xl mb-3">🥚</div><p className="mb-4">보유한 알이 없어요. 상점에서 알을 사거나 에그메이킹 룸에서 교배해보세요!</p><button className="btn-main px-6 py-2" onClick={goShop}>상점 가기</button></div>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-6 gap-3">
            {groups.map((e) => (
              <button key={e.uid} onClick={() => start(e)} className="rounded-3xl bg-white border-4 border-amber-100 p-2 flex flex-col items-center hover:scale-105 transition">
                <EggArt type={e.type} c1={e.c1} c2={e.c2} size={56} />
                <span className="text-xs font-bold text-amber-700 mt-1">{e.type < 0 ? '교배 알 💞' : EGGS[e.type].name}</span>
                <span className="text-[11px] text-pink-500">부화하기</span>
              </button>
            ))}
          </div>
        )}
      </Modal>
      {egg && <HatchScene key={egg.uid} egg={egg} onDone={(more) => { const next = more ? getState().eggs[0] : null; setEgg(next || null); }} />}
    </>
  );
}

// ───────── 에그메이킹 룸 (교배) ─────────
export function BreedPanel({ onClose, goHatch }: { onClose: () => void; goHatch: () => void }) {
  const s = useG();
  const [a, setA] = useState<string>('');
  const [b, setB] = useState<string>('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<EggItem | null>(null);
  const pa = s.pens.find((p) => p.uid === a), pb = s.pens.find((p) => p.uid === b);
  const choose = (p: Owned) => {
    if (busy) return; sfx('click'); setResult(null);
    if (p.uid === a) return setA(''); if (p.uid === b) return setB('');
    if (!a) setA(p.uid); else if (!b) setB(p.uid); else { setA(p.uid); setB(''); }
  };
  const go = () => {
    if (!pa || !pb) return; setBusy(true); setResult(null); sfx('wobble');
    const iv = setInterval(() => sfx('squeak'), 450);
    setTimeout(() => { clearInterval(iv); const e = breed(pa, pb); setResult(e); setBusy(false); sfx('hatch'); toast('새로운 알이 생겼어요! 💞'); }, 2400);
  };
  const Slot = ({ p, label }: { p?: Owned; label: string }) => (
    <div className="flex flex-col items-center w-28 sm:w-36">
      <div className="w-full aspect-[4/5] rounded-3xl bg-white border-4 border-dashed border-pink-300 flex items-center justify-center overflow-hidden">
        {p ? <div style={busy ? { animation: 'hop .5s infinite' } : { animation: 'bob 2s infinite' }}><Penguin spec={specOf(p)} size={96} /></div> : <span className="text-pink-300 text-sm">{label}</span>}
      </div>
      <div className="text-xs font-bold text-pink-600 mt-1 truncate max-w-full">{p ? p.name : ''}</div>
    </div>
  );
  return (
    <Modal title="에그메이킹 룸" icon="💞" onClose={onClose} tone="purple" wide>
      <p className="text-sm text-fuchsia-600 font-bold mb-3 text-center">펭귄 두 마리를 골라 교배하면 새로운 알을 얻어요! <span className="bg-fuchsia-100 px-2 rounded-full">완전 무료 · 무제한</span></p>
      <div className="flex items-center justify-center gap-3 sm:gap-6 mb-4 relative">
        <Slot p={pa} label="부모 1" />
        <div className="flex flex-col items-center">
          <div className={'text-5xl ' + (busy ? 'animate-ping' : '')}>💗</div>
          {result ? <div className="pop-in"><EggArt type={-1} c1={result.c1} c2={result.c2} size={64} /></div> : <div className="text-3xl opacity-40">🥚</div>}
        </div>
        <Slot p={pb} label="부모 2" />
      </div>
      <div className="flex justify-center gap-3 mb-4">
        <button className="btn-main px-8 py-3 text-xl" disabled={!pa || !pb || busy} onClick={go}>{busy ? '교배 중…' : '💞 교배하기 (무료)'}</button>
        {result && <button className="btn-cute px-5 py-3 text-pink-500 font-bold" onClick={goHatch}>🐣 부화하러 가기</button>}
      </div>
      {result && <p className="text-center text-sm text-fuchsia-600 mb-3">두 펭귄의 특징을 이어받은 알이에요. 부화해서 어떤 아기 펭귄인지 확인해요!</p>}
      <div className="text-sm font-bold text-gray-500 mb-2">내 펭귄 ({s.pens.length}) — 눌러서 부모 선택</div>
      {s.pens.length < 2 ? <p className="text-center py-8 text-gray-500">교배하려면 펭귄이 2마리 이상 필요해요. 알을 부화해보세요!</p> : (
        <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-2 max-h-[34vh] overflow-y-auto scroll-soft p-1">
          {s.pens.map((p) => (
            <button key={p.uid} onClick={() => choose(p)} className={'rounded-2xl bg-white border-4 p-1 flex flex-col items-center ' + (p.uid === a || p.uid === b ? 'border-pink-400 bg-pink-50' : 'border-transparent')}>
              <Penguin spec={specOf(p)} size={54} still /><span className="text-[10px] truncate w-full">{p.name}</span>
            </button>
          ))}
        </div>
      )}
    </Modal>
  );
}

export { THEMES, NV, speciesTheme, fmt };
