// 귀여운 배경음악 + 효과음 (WebAudio 합성, 외부 파일 없음)
let ctx: AudioContext | null = null;
let master: GainNode;
let bgmGain: GainNode;
let sfxGain: GainNode;
let timer: number | null = null;
let nextT = 0;
let step = 0;
export const audioState = { bgm: true, sfx: true, started: false };

function ensure() {
  if (!ctx) {
    const AC = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC() as AudioContext;
    master = ctx.createGain();
    master.gain.value = 0.9;
    master.connect(ctx.destination);
    bgmGain = ctx.createGain();
    bgmGain.gain.value = audioState.bgm ? 0.16 : 0;
    bgmGain.connect(master);
    sfxGain = ctx.createGain();
    sfxGain.gain.value = audioState.sfx ? 0.5 : 0;
    sfxGain.connect(master);
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

function tone(freq: number, t: number, dur: number, type: OscillatorType, vol: number, dest: AudioNode, slideTo?: number) {
  if (!ctx) return;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g);
  g.connect(dest);
  o.start(t);
  o.stop(t + dur + 0.05);
}

const ROOTS = [60, 57, 53, 55, 60, 57, 65, 55];
const MEL: number[][] = [
  [76, -1, 79, -1, 76, 74, 72, -1],
  [72, -1, 76, -1, 81, 79, 76, -1],
  [77, -1, 81, -1, 77, 76, 72, -1],
  [74, 76, 79, -1, 74, -1, 71, -1],
  [79, -1, 76, 79, 84, -1, 81, 79],
  [76, -1, 72, -1, 76, 79, 81, -1],
  [77, 79, 81, -1, 84, 81, 77, -1],
  [79, -1, 74, 76, 79, -1, 83, -1],
];
const STEP = 0.24;

function schedule() {
  if (!ctx) return;
  while (nextT < ctx.currentTime + 0.4) {
    const bar = Math.floor(step / 8) % 8;
    const s = step % 8;
    const root = ROOTS[bar];
    // 베이스
    if (s % 4 === 0) tone(mtof(root - 12), nextT, STEP * 3.6, 'triangle', 0.5, bgmGain);
    // 아르페지오
    const arp = [0, 7, 12, 7, 4, 7, 12, 16][s];
    tone(mtof(root + arp), nextT, STEP * 1.5, 'sine', 0.16, bgmGain);
    // 멜로디 (뮤직박스 느낌)
    const m = MEL[bar][s];
    if (m > 0) {
      tone(mtof(m), nextT, STEP * 2.2, 'triangle', 0.4, bgmGain);
      tone(mtof(m + 12), nextT, STEP * 1.2, 'sine', 0.08, bgmGain);
    }
    // 하이햇 느낌
    if (s % 2 === 1) tone(mtof(96), nextT, 0.03, 'square', 0.015, bgmGain);
    nextT += STEP;
    step++;
  }
}

export function startBgm() {
  const c = ensure();
  if (!c) return;
  audioState.started = true;
  if (timer == null) {
    nextT = c.currentTime + 0.1;
    timer = window.setInterval(schedule, 120);
  }
}

export function setBgm(on: boolean) {
  audioState.bgm = on;
  if (on) startBgm();
  if (bgmGain && ctx) bgmGain.gain.setTargetAtTime(on ? 0.16 : 0, ctx.currentTime, 0.05);
}
export function setSfx(on: boolean) {
  audioState.sfx = on;
  if (sfxGain && ctx) sfxGain.gain.setTargetAtTime(on ? 0.5 : 0, ctx.currentTime, 0.05);
}

export function sfx(name: string) {
  const c = ensure();
  if (!c || !audioState.sfx) return;
  const t = c.currentTime;
  const d = sfxGain;
  switch (name) {
    case 'click': tone(880, t, 0.08, 'sine', 0.5, d); tone(1320, t + 0.04, 0.08, 'sine', 0.3, d); break;
    case 'pop': tone(500, t, 0.12, 'sine', 0.6, d, 1200); break;
    case 'coin': tone(988, t, 0.09, 'square', 0.25, d); tone(1319, t + 0.08, 0.25, 'square', 0.25, d); break;
    case 'buy': [660, 880, 1100, 1320].forEach((f, i) => tone(f, t + i * 0.06, 0.15, 'triangle', 0.4, d)); break;
    case 'error': tone(220, t, 0.18, 'sawtooth', 0.25, d, 150); break;
    case 'hit': tone(200, t, 0.2, 'sawtooth', 0.35, d, 80); break;
    case 'jump': tone(400, t, 0.18, 'square', 0.18, d, 900); break;
    case 'shoot': tone(1200, t, 0.1, 'square', 0.1, d, 400); break;
    case 'flap': tone(500, t, 0.1, 'triangle', 0.4, d, 800); break;
    case 'wobble': tone(300, t, 0.1, 'triangle', 0.5, d, 380); tone(380, t + 0.12, 0.1, 'triangle', 0.5, d, 300); break;
    case 'crack': tone(150, t, 0.08, 'square', 0.3, d); tone(2000, t, 0.05, 'square', 0.12, d); break;
    case 'hatch': [523, 659, 784, 1047, 1319, 1568].forEach((f, i) => tone(f, t + i * 0.09, 0.3, 'triangle', 0.45, d)); break;
    case 'win': [523, 659, 784, 1047].forEach((f, i) => tone(f, t + i * 0.12, 0.28, 'triangle', 0.45, d)); tone(1319, t + 0.5, 0.5, 'sine', 0.4, d); break;
    case 'lose': [440, 392, 330, 262].forEach((f, i) => tone(f, t + i * 0.14, 0.25, 'triangle', 0.4, d)); break;
    case 'note0': tone(523, t, 0.3, 'triangle', 0.6, d); break;
    case 'note1': tone(659, t, 0.3, 'triangle', 0.6, d); break;
    case 'note2': tone(784, t, 0.3, 'triangle', 0.6, d); break;
    case 'note3': tone(1047, t, 0.3, 'triangle', 0.6, d); break;
    case 'squeak': tone(1400, t, 0.07, 'sine', 0.5, d, 2200); tone(1800, t + 0.08, 0.08, 'sine', 0.5, d, 2400); break;
    case 'splash': tone(300, t, 0.3, 'sine', 0.5, d, 90); break;
    case 'tick': tone(1500, t, 0.03, 'square', 0.12, d); break;
    default: tone(700, t, 0.08, 'sine', 0.4, d);
  }
}
