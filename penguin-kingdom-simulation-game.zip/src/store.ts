import { useSyncExternalStore } from 'react';
import { EGGS, NAMES, PSpec, breedResult, drawSpecies, pick, speciesSpec, uid } from './data/penguinData';
import { BUILDINGS, SPECIAL_IDS } from './data/buildings';
import { DECOS } from './components/DecoArt';
import { SEA } from './components/SeaArt';

export interface Owned { uid: string; sid: number; name: string; custom?: PSpec; at: number }
export interface EggItem { uid: string; type: number; baby?: number; c1?: string; c2?: string }
export interface PItem { id: string; t: number; x: number; y: number }
export interface Town { id: string; name: string; mayor?: string; b: PItem[]; d: PItem[] }
export interface GState {
  coins: number; eggs: EggItem[]; pens: Owned[]; dex: number[]; towns: Town[]; town: string;
  sea: Record<number, number>; bankLast: number; daily: string; bgm: boolean; sfx: boolean; best: Record<string, number>;
}

export const WORLD = { w: 2400, h: 1400 };
const KEY = 'penguin-nara-save-v1';

function initTown(): Town {
  const pos: [number, number][] = [[820, 660], [1020, 640], [1220, 660], [1420, 640], [920, 880], [1120, 860], [1320, 880], [1520, 860]];
  const keys = Object.values(SPECIAL_IDS);
  const b: PItem[] = keys.map((t, i) => ({ id: 'sp' + i, t, x: pos[i][0], y: pos[i][1] }));
  b.push({ id: 'h0', t: 0, x: 700, y: 1100 }, { id: 'h1', t: 1, x: 940, y: 1130 }, { id: 'h2', t: 4, x: 1180, y: 1100 }, { id: 'h3', t: 5, x: 1420, y: 1130 });
  const d: PItem[] = [
    { id: 'd0', t: 0, x: 640, y: 760 }, { id: 'd1', t: 1, x: 1660, y: 760 }, { id: 'd2', t: 2, x: 700, y: 900 }, { id: 'd3', t: 3, x: 1620, y: 1000 },
    { id: 'd4', t: 4, x: 1070, y: 1010 }, { id: 'd5', t: 5, x: 860, y: 1010 }, { id: 'd6', t: 8, x: 1220, y: 1010 }, { id: 'd7', t: 24, x: 1740, y: 1120 }, { id: 'd8', t: 15, x: 560, y: 1200 },
  ];
  return { id: 'main', name: '펭귄나라', b, d };
}

function fresh(): GState {
  return {
    coins: 1500, eggs: [{ uid: uid(), type: 0 }, { uid: uid(), type: 0 }, { uid: uid(), type: 1 }], pens: [], dex: [], towns: [initTown()], town: 'main',
    sea: {}, bankLast: Date.now(), daily: '', bgm: true, sfx: true, best: {},
  };
}

function load(): GState {
  try {
    const s = localStorage.getItem(KEY);
    if (s) { const o = JSON.parse(s); return { ...fresh(), ...o }; }
  } catch { /* ignore */ }
  return fresh();
}

let state: GState = load();
const subs = new Set<() => void>();
const subscribe = (f: () => void) => { subs.add(f); return () => { subs.delete(f); }; };
export const getState = () => state;
let saveT: number | null = null;
function save() {
  if (saveT != null) return;
  saveT = window.setTimeout(() => { saveT = null; try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* ignore */ } }, 300);
}
export function mutate(fn: (s: GState) => void) {
  const d = structuredClone(state);
  fn(d);
  state = d;
  save();
  subs.forEach((f) => f());
}
export const useG = () => useSyncExternalStore(subscribe, getState, getState);
export function resetAll() { state = fresh(); localStorage.removeItem(KEY); subs.forEach((f) => f()); }

// ---- 토스트 ----
const tsubs = new Set<(m: string) => void>();
export const toast = (m: string) => tsubs.forEach((f) => f(m));
export const onToast = (f: (m: string) => void) => { tsubs.add(f); return () => { tsubs.delete(f); }; };

export const curTown = (s: GState) => s.towns.find((t) => t.id === s.town) || s.towns[0];
export const specOf = (p: Owned): PSpec => p.custom || speciesSpec(p.sid);

// ---- 액션 ----
export const earn = (n: number) => mutate((s) => { s.coins += Math.round(n); });
export function spend(n: number): boolean {
  if (state.coins < n) return false;
  mutate((s) => { s.coins -= n; });
  return true;
}
export function buyEgg(type: number): boolean {
  if (!spend(EGGS[type].price)) return false;
  mutate((s) => { s.eggs.push({ uid: uid(), type }); });
  return true;
}
export function hatchEgg(eggUid: string): Owned | null {
  const e = state.eggs.find((x) => x.uid === eggUid);
  if (!e) return null;
  const sid = e.baby != null ? e.baby : drawSpecies(e.type);
  const p: Owned = { uid: uid(), sid, name: pick(NAMES), at: Date.now() };
  mutate((s) => {
    s.eggs = s.eggs.filter((x) => x.uid !== eggUid);
    s.pens.push(p);
    if (!s.dex.includes(sid)) s.dex.push(sid);
  });
  return p;
}
export function breed(a: Owned, b: Owned): EggItem {
  const r = breedResult(a.custom ? -1 : a.sid, b.custom ? -1 : b.sid);
  const egg: EggItem = { uid: uid(), type: -1, baby: r.sid, c1: r.c1, c2: r.c2 };
  mutate((s) => { s.eggs.push(egg); });
  return egg;
}
export function buyItem(kind: 'b' | 'd', t: number, x: number, y: number): string | null {
  const price = kind === 'b' ? BUILDINGS[t].price : DECOS[t].price;
  if (state.coins < price) return null;
  const id = uid();
  mutate((s) => {
    s.coins -= price;
    const tw = curTown(s);
    tw[kind].push({ id, t, x, y });
  });
  return id;
}
export function moveItem(kind: 'b' | 'd', id: string, x: number, y: number) {
  mutate((s) => { const it = curTown(s)[kind].find((i) => i.id === id); if (it) { it.x = x; it.y = y; } });
}
export function removeItem(kind: 'b' | 'd', id: string) {
  mutate((s) => {
    const tw = curTown(s);
    const it = tw[kind].find((i) => i.id === id);
    if (!it) return;
    const price = kind === 'b' ? BUILDINGS[it.t].price : DECOS[it.t].price;
    s.coins += Math.floor(price / 2);
    tw[kind] = tw[kind].filter((i) => i.id !== id);
  });
}
export function buySea(id: number): boolean {
  if (!spend(SEA[id].price)) return false;
  mutate((s) => { s.sea[id] = (s.sea[id] || 0) + 1; });
  return true;
}
export function addTown(townName: string, penName: string, spec: PSpec) {
  const p: Owned = { uid: uid(), sid: -1, name: penName, custom: spec, at: Date.now() };
  const id = 'town' + uid();
  mutate((s) => {
    s.pens.push(p);
    s.towns.push({
      id, name: townName, mayor: p.uid,
      b: [{ id: 'a' + uid(), t: 0, x: 1000, y: 800 }, { id: 'b' + uid(), t: 1, x: 1260, y: 830 }, { id: 'c' + uid(), t: 5, x: 1500, y: 800 }],
      d: [{ id: 'e' + uid(), t: 0, x: 880, y: 900 }, { id: 'f' + uid(), t: 5, x: 1130, y: 920 }, { id: 'g' + uid(), t: 19, x: 1380, y: 920 }],
    });
    s.town = id;
  });
}
export const BANK_RATE = 2;
export const BANK_CAP = 3000;
export const bankPending = (s: GState) => Math.min(BANK_CAP, Math.floor(((Date.now() - s.bankLast) / 1000) * BANK_RATE));
export function claimBank() {
  const n = bankPending(state);
  if (n <= 0) return 0;
  mutate((s) => { s.coins += n; s.bankLast = Date.now(); });
  return n;
}
export function claimDaily(): number {
  const today = new Date().toDateString();
  if (state.daily === today) return 0;
  mutate((s) => { s.coins += 500; s.daily = today; });
  return 500;
}
export function setBest(game: string, score: number) {
  if ((state.best[game] || 0) < score) mutate((s) => { s.best[game] = score; });
}
