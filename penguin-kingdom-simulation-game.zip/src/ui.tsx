import { useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { RARITY } from './data/penguinData';
import { onToast } from './store';
import { sfx } from './audio';

export const fmt = (n: number) => n.toLocaleString('ko-KR');

export function Modal({ title, icon, onClose, children, wide, tone = 'pink' }: { title: string; icon?: string; onClose: () => void; children: ReactNode; wide?: boolean; tone?: string }) {
  const grad: Record<string, string> = { pink: 'from-pink-300 to-rose-300', sky: 'from-sky-300 to-cyan-300', purple: 'from-violet-300 to-fuchsia-300', yellow: 'from-amber-300 to-yellow-200', green: 'from-emerald-300 to-teal-200' };
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-2 sm:p-4 bg-sky-900/40 backdrop-blur-[2px]" onPointerDown={(e) => { if (e.target === e.currentTarget) { sfx('click'); onClose(); } }}>
      <div className={'pop-in flex flex-col w-full max-h-[94vh] rounded-[28px] border-[5px] border-white bg-gradient-to-b from-white to-pink-50 shadow-2xl overflow-hidden ' + (wide ? 'max-w-5xl' : 'max-w-2xl')} style={{ touchAction: 'auto' }}>
        <div className={'flex items-center justify-between px-5 py-3 bg-gradient-to-r text-white ' + (grad[tone] || grad.pink)}>
          <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2" style={{ textShadow: '0 2px 0 #0002' }}><span className="text-3xl">{icon}</span>{title}</h2>
          <button className="w-10 h-10 rounded-full bg-white/90 text-pink-500 text-xl font-bold shadow" onClick={() => { sfx('click'); onClose(); }}>✕</button>
        </div>
        <div className="p-4 overflow-y-auto scroll-soft text-gray-700" style={{ touchAction: 'pan-y' }}>{children}</div>
      </div>
    </div>
  );
}

export function ToastHost() {
  const [list, setList] = useState<{ id: number; m: string }[]>([]);
  useEffect(() => onToast((m) => {
    const id = Math.random();
    setList((l) => [...l.slice(-3), { id, m }]);
    setTimeout(() => setList((l) => l.filter((x) => x.id !== id)), 2200);
  }), []);
  return (
    <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[60] flex flex-col items-center gap-2 pointer-events-none">
      {list.map((t) => <div key={t.id} className="pop-in px-5 py-2 rounded-full bg-white/95 border-4 border-pink-300 text-pink-600 font-bold shadow-lg">{t.m}</div>)}
    </div>
  );
}

export const RarityTag = ({ tier, small }: { tier: number; small?: boolean }) => (
  <span className={'inline-block rounded-full text-white font-bold ' + (small ? 'px-2 text-[10px]' : 'px-3 py-0.5 text-xs')} style={{ background: RARITY[tier].color }}>{RARITY[tier].name}</span>
);

export const Coin = ({ n, className = '' }: { n: number; className?: string }) => (
  <span className={'inline-flex items-center gap-1 font-bold ' + className}><span className="inline-block w-5 h-5 rounded-full bg-gradient-to-br from-yellow-200 to-amber-400 border-2 border-amber-500 text-[11px] leading-4 text-center text-amber-700">₵</span>{fmt(n)}</span>
);
