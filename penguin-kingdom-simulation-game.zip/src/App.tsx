import { useEffect, useRef, useState } from 'react';
import { Town, Sel } from './Town';
import { Interior } from './Interior';
import { AquariumPanel } from './Aquarium';
import { ArcadePanel } from './Arcade';
import { BreedPanel, HatchPanel, ShopPanel } from './panels1';
import { BankPanel, BuildPanel, CreatePanel, DexPanel } from './panels2';
import { Coin, ToastHost } from './ui';
import { BUILDINGS } from './data/buildings';
import { DECOS } from './components/DecoArt';
import { PItem, buyItem, curTown, mutate, removeItem, toast, useG } from './store';
import { audioState, setBgm, setSfx, sfx, startBgm } from './audio';

type PanelName = 'shop' | 'hatch' | 'breed' | 'build' | 'buildD' | 'aqua' | 'arcade' | 'dex' | 'bank' | 'create' | null;

export default function App() {
  const s = useG();
  const town = curTown(s);
  const [panel, setPanel] = useState<PanelName>(null);
  const [inside, setInside] = useState<PItem | null>(null);
  const [edit, setEdit] = useState(false);
  const [sel, setSel] = useState<Sel | null>(null);
  const [bgm, setBgmS] = useState(audioState.bgm);
  const [sfxOn, setSfxS] = useState(audioState.sfx);
  const centerRef = useRef({ x: 1180, y: 780 });

  useEffect(() => {
    audioState.bgm = s.bgm; audioState.sfx = s.sfx; setBgmS(s.bgm); setSfxS(s.sfx);
    const first = () => { if (audioState.bgm) startBgm(); window.removeEventListener('pointerdown', first); };
    window.addEventListener('pointerdown', first);
    return () => window.removeEventListener('pointerdown', first);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const open = (p: PanelName) => { sfx('click'); setPanel(p); };
  const onOpen = (it: PItem) => {
    const def = BUILDINGS[it.t];
    if (def.special) {
      const map: Record<string, PanelName> = { shop: 'shop', egg: 'breed', arcade: 'arcade', aqua: 'aqua', bank: 'bank', hatch: 'hatch', dex: 'dex', deco: 'buildD' };
      setPanel(map[def.special]);
    } else setInside(it);
  };
  const place = (kind: 'b' | 'd', t: number) => {
    const c = centerRef.current;
    const x = Math.round(c.x + (Math.random() - 0.5) * 120), y = Math.round(Math.max(560, c.y + (Math.random() - 0.5) * 120));
    const id = buyItem(kind, t, x, y);
    if (!id) { sfx('error'); toast('코인이 부족해요!'); return; }
    sfx('buy'); toast(`${kind === 'b' ? BUILDINGS[t].name : DECOS[t].name} 설치! 드래그로 옮겨요`);
    setPanel(null); setEdit(true); setSel({ kind, id });
  };
  const selItem = sel ? (sel.kind === 'b' ? town.b : town.d).find((i) => i.id === sel.id) : null;
  const selName = selItem ? (sel!.kind === 'b' ? BUILDINGS[selItem.t].name : DECOS[selItem.t].name) : '';
  const selPrice = selItem ? (sel!.kind === 'b' ? BUILDINGS[selItem.t].price : DECOS[selItem.t].price) : 0;

  const Btn = ({ icon, label, onClick, badge, active }: { icon: string; label: string; onClick: () => void; badge?: number; active?: boolean }) => (
    <button onClick={onClick} className={'relative shrink-0 flex flex-col items-center justify-center w-[58px] h-[58px] sm:w-[66px] sm:h-[62px] btn-cute ' + (active ? '!bg-pink-200' : '')}>
      <span className="text-2xl sm:text-[26px] leading-none">{icon}</span>
      <span className="text-[10px] sm:text-[11px] font-bold text-pink-600 mt-0.5">{label}</span>
      {badge ? <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-rose-500 text-white text-[11px] font-bold flex items-center justify-center border-2 border-white">{badge}</span> : null}
    </button>
  );

  return (
    <div className="fixed inset-0 overflow-hidden bg-sky-200 select-none">
      <Town edit={edit} sel={sel} setSel={setSel} onOpen={onOpen} centerRef={centerRef} />

      {/* 상단 UI */}
      <div className="absolute top-0 inset-x-0 z-30 p-2 flex flex-col gap-2 pointer-events-none">
        <div className="flex items-center gap-2 pointer-events-auto">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/90 border-4 border-amber-200 shadow-lg">
            <Coin n={s.coins} className="text-lg text-amber-600" />
          </div>
          <div className="flex items-center gap-1 px-2 py-1.5 rounded-full bg-white/90 border-4 border-sky-200 shadow-lg max-w-[46vw]">
            <span>🏡</span>
            <select className="bg-transparent font-bold text-sky-700 text-sm outline-none max-w-[28vw] sm:max-w-none" value={s.town} onChange={(e) => { sfx('click'); mutate((d) => { d.town = e.target.value; }); setSel(null); }}>
              {s.towns.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <div className="ml-auto flex gap-1.5">
            <button className="btn-cute w-10 h-10 text-lg" title="배경음악" onClick={() => { const v = !bgm; setBgmS(v); setBgm(v); mutate((d) => { d.bgm = v; }); sfx('click'); }}>{bgm ? '🎵' : '🔇'}</button>
            <button className="btn-cute w-10 h-10 text-lg" title="효과음" onClick={() => { const v = !sfxOn; setSfxS(v); setSfx(v); mutate((d) => { d.sfx = v; }); if (v) sfx('click'); }}>{sfxOn ? '🔔' : '🔕'}</button>
          </div>
        </div>
        <div className="flex gap-2 overflow-x-auto scroll-soft pb-2 pt-1 px-1 pointer-events-auto">
          <Btn icon="🛍️" label="상점" onClick={() => open('shop')} />
          <Btn icon="🐣" label="부화장" badge={s.eggs.length} onClick={() => open('hatch')} />
          <Btn icon="💞" label="에그메이킹" onClick={() => open('breed')} />
          <Btn icon="🏗️" label="건설" onClick={() => open('build')} />
          <Btn icon="🎀" label="꾸미기" active={edit} onClick={() => { sfx('click'); setEdit(!edit); setSel(null); }} />
          <Btn icon="🐠" label="아쿠아리움" onClick={() => open('aqua')} />
          <Btn icon="🕹️" label="미니게임" onClick={() => open('arcade')} />
          <Btn icon="📖" label="도감" onClick={() => open('dex')} />
          <Btn icon="🏦" label="은행" onClick={() => open('bank')} />
          <Btn icon="➕" label="추가" onClick={() => open('create')} />
        </div>
      </div>

      {/* 안내 */}
      {s.pens.length === 0 && !panel && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 pop-in px-5 py-3 rounded-3xl bg-white/95 border-4 border-pink-300 text-pink-600 font-bold text-center shadow-xl max-w-[90vw]">
          🥚 알이 {s.eggs.length}개 있어요! <button className="btn-main px-3 py-1 ml-2 text-sm" onClick={() => open('hatch')}>🐣 부화하러 가기</button>
        </div>
      )}
      {edit && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2 px-4 py-2 rounded-full bg-white/95 border-4 border-emerald-300 shadow-xl max-w-[96vw]">
          <span className="text-sm font-bold text-emerald-600">{sel && selItem ? `✋ ${selName}` : '🎀 꾸미기 모드: 눌러서 선택, 드래그로 이동'}</span>
          {sel && selItem && <button className="btn-cute px-3 py-1 text-sm text-rose-500 font-bold" onClick={() => { removeItem(sel.kind, sel.id); sfx('pop'); toast(`삭제 (+${Math.floor(selPrice / 2)} 환불)`); setSel(null); }}>🗑 삭제</button>}
          <button className="btn-main px-4 py-1 text-sm" onClick={() => { setEdit(false); setSel(null); sfx('click'); }}>완료</button>
        </div>
      )}

      {panel === 'shop' && <ShopPanel onClose={() => setPanel(null)} />}
      {panel === 'hatch' && <HatchPanel onClose={() => setPanel(null)} goShop={() => setPanel('shop')} />}
      {panel === 'breed' && <BreedPanel onClose={() => setPanel(null)} goHatch={() => setPanel('hatch')} />}
      {(panel === 'build' || panel === 'buildD') && <BuildPanel key={panel} initialTab={panel === 'buildD' ? 'd' : 'b'} onClose={() => setPanel(null)} onBuy={place} />}
      {panel === 'aqua' && <AquariumPanel onClose={() => setPanel(null)} />}
      {panel === 'arcade' && <ArcadePanel onClose={() => setPanel(null)} />}
      {panel === 'dex' && <DexPanel onClose={() => setPanel(null)} />}
      {panel === 'bank' && <BankPanel onClose={() => setPanel(null)} />}
      {panel === 'create' && <CreatePanel onClose={() => setPanel(null)} />}
      {inside && <Interior item={inside} onClose={() => setInside(null)} />}
      <ToastHost />
    </div>
  );
}
