import { useEffect, useRef } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { Penguin } from '../components/Penguin';
import { PSpec, speciesSpec } from '../data/penguinData';
import { curTown, getState, specOf } from '../store';
import { sfx } from '../audio';

export interface GameProps { onFinish: (score: number, coins: number) => void }
export interface Api {
  W: number; H: number; keys: Set<string>; hit: Set<string>;
  ptr: { x: number; y: number; down: boolean; pressed: boolean; moved: boolean; sx: number; sy: number };
  finish: (score: number, coins: number) => void; sfx: (n: string) => void;
}
export interface Loop { update: (dt: number) => void; draw: (c: CanvasRenderingContext2D) => void }

const cache = new Map<string, HTMLImageElement>();
export function spriteOf(spec: PSpec): HTMLImageElement {
  const key = JSON.stringify(spec);
  let img = cache.get(key);
  if (!img) {
    const svg = renderToStaticMarkup(<Penguin spec={spec} size={200} still idp="spr" />).replace('<svg ', '<svg xmlns="http://www.w3.org/2000/svg" ');
    img = new Image();
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    cache.set(key, img);
  }
  return img;
}
export function favSpec(): PSpec {
  const s = getState();
  const t = curTown(s);
  const p = s.pens.find((x) => x.uid === t.mayor) || s.pens[s.pens.length - 1];
  return p ? specOf(p) : speciesSpec(0);
}
export function mySprite() { return spriteOf(favSpec()); }
/** 중심(cx,cy) 기준 너비 w로 펭귄 스프라이트를 그린다 */
export function drawPeng(c: CanvasRenderingContext2D, img: HTMLImageElement, cx: number, cy: number, w: number, rot = 0, flip = false) {
  const h = (w * 258) / 200;
  c.save();
  c.translate(cx, cy);
  if (rot) c.rotate(rot);
  if (flip) c.scale(-1, 1);
  if (img.complete && img.naturalWidth) c.drawImage(img, -w / 2, -h * 0.5 + h * 0.108, w, h);
  else { c.font = `${w}px serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('🐧', 0, 0); }
  c.restore();
}

export function rr(c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rad = Math.min(r, w / 2, h / 2);
  c.beginPath();
  c.moveTo(x + rad, y);
  c.arcTo(x + w, y, x + w, y + h, rad);
  c.arcTo(x + w, y + h, x, y + h, rad);
  c.arcTo(x, y + h, x, y, rad);
  c.arcTo(x, y, x + w, y, rad);
  c.closePath();
}
export function bgGrad(c: CanvasRenderingContext2D, W: number, H: number, a: string, b: string) {
  const g = c.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, a); g.addColorStop(1, b);
  c.fillStyle = g; c.fillRect(0, 0, W, H);
}
export function txt(c: CanvasRenderingContext2D, s: string, x: number, y: number, size = 18, color = '#fff', align: CanvasTextAlign = 'left', stroke = '#0006') {
  c.font = `bold ${size}px "Jua","Malgun Gothic",sans-serif`;
  c.textAlign = align; c.textBaseline = 'middle';
  c.lineWidth = Math.max(3, size / 5); c.strokeStyle = stroke; c.lineJoin = 'round';
  c.strokeText(s, x, y); c.fillStyle = color; c.fillText(s, x, y);
}
export function emo(c: CanvasRenderingContext2D, e: string, x: number, y: number, size: number, rot = 0) {
  c.save(); c.translate(x, y); if (rot) c.rotate(rot);
  c.font = `${size}px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",serif`; c.textAlign = 'center'; c.textBaseline = 'middle';
  c.fillText(e, 0, 0); c.restore();
}
export function snowBg(c: CanvasRenderingContext2D, W: number, H: number, t: number, a = '#bfe8ff', b = '#f2fbff') {
  bgGrad(c, W, H, a, b);
  c.fillStyle = '#ffffffaa';
  for (let i = 0; i < 28; i++) { const x = (i * 97 + Math.sin(t + i) * 12) % W; const y = (i * 53 + t * (20 + (i % 5) * 8)) % H; c.beginPath(); c.arc(x, y, 1.5 + (i % 3), 0, 7); c.fill(); }
}

interface CGProps {
  W: number; H: number; make: (api: Api) => Loop; onFinish: (s: number, c: number) => void;
  pad?: 'lr' | 'dir' | 'act' | 'lract' | 'none';
}

export function CanvasGame({ W, H, make, onFinish, pad = 'none' }: CGProps) {
  const ref = useRef<HTMLCanvasElement>(null);
  const keysRef = useRef<{ keys: Set<string>; hit: Set<string> } | null>(null);
  if (!keysRef.current) keysRef.current = { keys: new Set(), hit: new Set() };
  useEffect(() => {
    const cv = ref.current!;
    const c = cv.getContext('2d')!;
    const DPR = 2;
    cv.width = W * DPR; cv.height = H * DPR;
    const { keys, hit } = keysRef.current!;
    const ptr = { x: W / 2, y: H / 2, down: false, pressed: false, moved: false, sx: 0, sy: 0 };
    let ended = false;
    const api: Api = { W, H, keys, hit, ptr, sfx, finish: (s, co) => { if (ended) return; ended = true; setTimeout(() => onFinish(s, co), 50); } };
    const g = make(api);
    let last = performance.now();
    let raf = 0;
    const frame = (t: number) => {
      const dt = Math.min(0.05, (t - last) / 1000);
      last = t;
      c.setTransform(DPR, 0, 0, DPR, 0, 0);
      g.update(dt);
      g.draw(c);
      ptr.pressed = false; hit.clear();
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    const norm = (k: string) => (k === ' ' ? ' ' : k.length === 1 ? k.toLowerCase() : k);
    const kd = (e: KeyboardEvent) => {
      const k = norm(e.key);
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(k)) e.preventDefault();
      if (!keys.has(k)) hit.add(k);
      keys.add(k);
    };
    const ku = (e: KeyboardEvent) => { keys.delete(norm(e.key)); };
    const pos = (e: PointerEvent) => {
      const r = cv.getBoundingClientRect();
      ptr.x = ((e.clientX - r.left) / r.width) * W;
      ptr.y = ((e.clientY - r.top) / r.height) * H;
    };
    const pd = (e: PointerEvent) => { pos(e); ptr.down = true; ptr.pressed = true; ptr.moved = true; ptr.sx = ptr.x; ptr.sy = ptr.y; try { cv.setPointerCapture(e.pointerId); } catch { /* */ } };
    const pm = (e: PointerEvent) => { pos(e); ptr.moved = true; };
    const pu = () => { ptr.down = false; };
    window.addEventListener('keydown', kd); window.addEventListener('keyup', ku);
    cv.addEventListener('pointerdown', pd); cv.addEventListener('pointermove', pm); cv.addEventListener('pointerup', pu); cv.addEventListener('pointercancel', pu);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku);
      cv.removeEventListener('pointerdown', pd); cv.removeEventListener('pointermove', pm); cv.removeEventListener('pointerup', pu); cv.removeEventListener('pointercancel', pu);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setKey = (k: string, on: boolean) => {
    const { keys, hit } = keysRef.current!;
    if (on) { if (!keys.has(k)) hit.add(k); keys.add(k); } else keys.delete(k);
  };
  const B = ({ k, label, cls = '' }: { k: string; label: string; cls?: string }) => (
    <button className={'btn-cute w-16 h-14 text-2xl select-none ' + cls}
      onPointerDown={(e) => { e.preventDefault(); setKey(k, true); }} onPointerUp={() => setKey(k, false)} onPointerLeave={() => setKey(k, false)} onPointerCancel={() => setKey(k, false)}>{label}</button>
  );
  return (
    <div className="flex flex-col items-center gap-2">
      <canvas ref={ref} className="rounded-2xl border-4 border-white shadow-lg bg-sky-100" style={{ width: `min(100%, calc(60vh * ${W / H}))`, aspectRatio: `${W}/${H}`, touchAction: 'none' }} />
      {pad === 'lr' && <div className="flex gap-4"><B k="ArrowLeft" label="◀" /><B k="ArrowRight" label="▶" /></div>}
      {pad === 'act' && <div className="flex gap-4"><B k=" " label="점프!" cls="w-40" /></div>}
      {pad === 'lract' && <div className="flex gap-3"><B k="ArrowLeft" label="◀" /><B k=" " label="●" /><B k="ArrowRight" label="▶" /></div>}
      {pad === 'dir' && (
        <div className="grid grid-cols-3 gap-1"><span /><B k="ArrowUp" label="▲" /><span /><B k="ArrowLeft" label="◀" /><B k="ArrowDown" label="▼" /><B k="ArrowRight" label="▶" /></div>
      )}
    </div>
  );
}

export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
export const rand = (a: number, b: number) => a + Math.random() * (b - a);
export const shuffle = <T,>(a: T[]): T[] => { const r = a.slice(); for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; };
