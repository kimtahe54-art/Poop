import { useEffect, useRef, useState } from 'react';
import { GameProps, shuffle } from './engine';
import { Hud, Wrap, useEnd } from './puzzleA';
import { pick, rnd } from '../data/penguinData';
import { sfx } from '../audio';

// ───────── 23. 하이로우 카드 ─────────
const SUITS = ['🐧', '❄️', '🐟', '⭐'];
export const HiLow = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const draw = () => ({ v: 1 + rnd(13), s: pick(SUITS) });
  const [cur, setCur] = useState(draw);
  const [nxt, setNxt] = useState<{ v: number; s: string } | null>(null);
  const [streak, setStreak] = useState(0);
  const [lives, setLives] = useState(3);
  const [lock, setLock] = useState(false);
  const bestR = useRef(0);
  const label = (v: number) => (v === 1 ? 'A' : v === 11 ? 'J' : v === 12 ? 'Q' : v === 13 ? 'K' : String(v));
  const guess = (hi: boolean) => {
    if (lock) return; setLock(true);
    const n = draw(); setNxt(n);
    const right = hi ? n.v >= cur.v : n.v <= cur.v;
    setTimeout(() => {
      if (right) { sfx('coin'); setStreak(streak + 1); } else { sfx('error'); setLives(lives - 1); setStreak(0); }
      const sc = right ? streak + 1 : streak;
      bestR.current = Math.max(sc, bestR.current); const best = bestR.current;
      if (!right && lives - 1 <= 0) { end(best, Math.min(300, best * 20 + 20)); return; }
      setCur(n); setNxt(null); setLock(false);
    }, 900);
  };
  const Card = ({ c, hide }: { c: { v: number; s: string } | null; hide?: boolean }) => (
    <div className={'w-28 h-40 rounded-2xl border-4 flex flex-col items-center justify-center text-4xl font-bold shadow-lg ' + (!c || hide ? 'bg-gradient-to-br from-pink-300 to-sky-300 border-white' : 'bg-white border-pink-200 text-pink-500')}>
      {c && !hide ? <><span>{label(c.v)}</span><span className="text-5xl">{c.s}</span></> : <span className="text-5xl">🐾</span>}
    </div>
  );
  return (
    <Wrap>
      <Hud><span>🔥 연속 {streak}</span><span>{'❤'.repeat(lives)}</span></Hud>
      <div className="flex items-center gap-6 my-4"><Card c={cur} /><span className="text-3xl">➡️</span><Card c={nxt} hide={!nxt} /></div>
      <p className="text-sky-700 mb-3">다음 카드는 지금 카드보다 높을까요, 낮을까요? (같으면 정답!)</p>
      <div className="grid grid-cols-2 gap-3 w-full">
        <button className="btn-main py-4 text-xl" disabled={lock} onClick={() => guess(true)}>⬆️ 높다</button>
        <button className="btn-main py-4 text-xl" disabled={lock} onClick={() => guess(false)}>⬇️ 낮다</button>
      </div>
      <button className="btn-cute mt-3 px-4 py-2" onClick={() => end(Math.max(streak, bestR.current), Math.min(300, Math.max(streak, bestR.current) * 20 + 20), 200)}>그만하고 코인 받기</button>
    </Wrap>
  );
};

// ───────── 24. 산수 풍선 ─────────
export const MathBalloons = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const mkQ = (lvl: number) => {
    const ops = lvl < 4 ? ['+', '-'] : ['+', '-', '×'];
    const op = pick(ops); let a = 2 + rnd(8 + lvl * 2), b = 2 + rnd(8 + lvl * 2);
    if (op === '×') { a = 2 + rnd(8); b = 2 + rnd(8); }
    if (op === '-' && b > a) [a, b] = [b, a];
    const ans = op === '+' ? a + b : op === '-' ? a - b : a * b;
    const opts = new Set<number>([ans]); while (opts.size < 4) opts.add(Math.max(0, ans + rnd(11) - 5));
    return { text: `${a} ${op} ${b}`, ans, opts: shuffle([...opts]), id: Math.random() };
  };
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [q, setQ] = useState(() => mkQ(0));
  const lost = useRef(false);
  const miss = () => { if (lost.current) return; lost.current = true; sfx('error'); const l = lives - 1; setLives(l); if (l <= 0) end(score, Math.min(300, score * 12)); else { setQ(mkQ(score)); } setTimeout(() => (lost.current = false), 50); };
  const click = (n: number) => { if (lives <= 0) return; if (n === q.ans) { sfx('pop'); const s = score + 1; setScore(s); setQ(mkQ(s)); if (s >= 25) end(s, 300); } else miss(); };
  const dur = Math.max(4.5, 9 - score * 0.2);
  return (
    <Wrap>
      <Hud><span>🎈 {score}</span><span>{'❤'.repeat(Math.max(0, lives))}</span></Hud>
      <div className="text-4xl font-bold text-pink-500 mb-2 bg-white rounded-2xl px-6 py-2 border-4 border-pink-200">{q.text} = ?</div>
      <div className="relative w-full h-[380px] rounded-3xl bg-gradient-to-b from-sky-300 to-sky-100 overflow-hidden border-4 border-white">
        {q.opts.map((o, i) => (
          <button key={q.id + '-' + i} onClick={() => click(o)} onAnimationEnd={() => { if (o === q.ans) miss(); }}
            className="absolute bottom-[-90px] w-20 h-24 rounded-[50%_50%_50%_50%/60%_60%_40%_40%] text-3xl font-bold text-white border-2 border-white/70 shadow-lg"
            style={{ left: `${6 + i * 24}%`, background: ['#ff7eb6', '#ffb44a', '#5ac8a0', '#7a8aff'][i], animation: `rise ${dur + i * 0.6}s linear forwards`, animationDelay: `${i * 0.2}s` }}>
            {o}
          </button>
        ))}
      </div>
    </Wrap>
  );
};

// ───────── 25. 색깔 코드 맞추기 (마스터마인드) ─────────
const MC = ['#ff6a8a', '#ffb43a', '#ffe34a', '#4ac88a', '#4aa8ff', '#a070ff'];
export const Mastermind = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const [code] = useState(() => Array.from({ length: 4 }, () => rnd(6)));
  const [cur, setCur] = useState<number[]>([]);
  const [hist, setHist] = useState<{ g: number[]; b: number; w: number }[]>([]);
  const [done, setDone] = useState(false);
  const submit = () => {
    if (cur.length < 4) return;
    let b = 0; const cc: number[] = [], gg: number[] = [];
    cur.forEach((v, i) => { if (v === code[i]) b++; else { cc.push(code[i]); gg.push(v); } });
    let w = 0; gg.forEach((v) => { const k = cc.indexOf(v); if (k >= 0) { w++; cc.splice(k, 1); } });
    const h = [...hist, { g: cur, b, w }]; setHist(h); setCur([]); sfx(b === 4 ? 'win' : 'click');
    if (b === 4) { setDone(true); end(1, 60 + (8 - h.length) * 30); } else if (h.length >= 8) { setDone(true); sfx('lose'); end(0, 15); }
  };
  return (
    <Wrap>
      <Hud><span>시도 {hist.length}/8</span><span>{done ? code.map((c, i) => <span key={i} style={{ color: MC[c] }}>●</span>) : '? ? ? ?'}</span></Hud>
      <div className="w-full bg-white/70 rounded-3xl p-3 border-4 border-pink-100 flex flex-col gap-1.5 max-h-[300px] overflow-auto scroll-soft">
        {hist.map((h, i) => (
          <div key={i} className="flex items-center gap-2">
            {h.g.map((c, k) => <div key={k} className="w-9 h-9 rounded-full border-2 border-white shadow" style={{ background: MC[c] }} />)}
            <div className="ml-auto flex gap-0.5 flex-wrap w-16">{Array.from({ length: h.b }, (_, k) => <span key={'b' + k} className="w-3.5 h-3.5 rounded-full bg-gray-700" />)}{Array.from({ length: h.w }, (_, k) => <span key={'w' + k} className="w-3.5 h-3.5 rounded-full bg-white border-2 border-gray-400" />)}</div>
          </div>
        ))}
        {!done && <div className="flex gap-2 items-center">{[0, 1, 2, 3].map((k) => <button key={k} onClick={() => setCur(cur.filter((_, i) => i !== k))} className="w-9 h-9 rounded-full border-2 border-dashed border-pink-300" style={{ background: cur[k] != null ? MC[cur[k]] : '#fff' }} />)}</div>}
      </div>
      <div className="flex gap-2 mt-3">{MC.map((c, i) => <button key={i} disabled={done} onClick={() => cur.length < 4 && (setCur([...cur, i]), sfx('tick'))} className="w-11 h-11 rounded-full border-4 border-white shadow-md" style={{ background: c }} />)}</div>
      <button className="btn-main mt-3 px-8 py-2 text-lg" disabled={cur.length < 4 || done} onClick={submit}>확인</button>
      <p className="text-xs text-sky-700 mt-2 text-center">● 검정 = 색·위치 모두 정답 / ○ 흰색 = 색만 정답. 같은 색이 중복될 수 있어요.</p>
    </Wrap>
  );
};

// ───────── 26. 슬라이딩 퍼즐 ─────────
const TILE_E = ['🐧', '🐟', '⭐', '🍓', '🍦', '🎈', '🐚', '🍪'];
export const SlidePuzzle = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const [t, setT] = useState<number[]>(() => {
    let a = [1, 2, 3, 4, 5, 6, 7, 8, 0]; let last = -1;
    for (let k = 0; k < 150; k++) { const z = a.indexOf(0), x = z % 3, y = Math.floor(z / 3); const nb: number[] = []; if (x > 0) nb.push(z - 1); if (x < 2) nb.push(z + 1); if (y > 0) nb.push(z - 3); if (y < 2) nb.push(z + 3); const m = pick(nb.filter((n) => n !== last)); last = z; a = a.slice(); a[z] = a[m]; a[m] = 0; }
    return a;
  });
  const [moves, setMoves] = useState(0);
  const tap = (i: number) => {
    const z = t.indexOf(0), x = i % 3, y = Math.floor(i / 3), zx = z % 3, zy = Math.floor(z / 3);
    if (Math.abs(x - zx) + Math.abs(y - zy) !== 1) return;
    const n = t.slice(); n[z] = n[i]; n[i] = 0; setT(n); setMoves(moves + 1); sfx('click');
    if (n.every((v, k) => v === (k === 8 ? 0 : k + 1))) { sfx('win'); end(1, Math.max(50, 260 - moves * 3)); }
  };
  const COL = ['#ffb0cc', '#ffd27a', '#a8e8b8', '#9ad0ff', '#d0b0ff', '#ffc0a0', '#a0e8e0', '#f0c8f0'];
  return (
    <Wrap>
      <Hud><span>👣 {moves}번</span><span>1~8 순서대로!</span></Hud>
      <div className="grid grid-cols-3 gap-2 w-72 p-2 bg-sky-200 rounded-3xl">
        {t.map((v, i) => <button key={i} onClick={() => tap(i)} className={'aspect-square rounded-2xl text-4xl flex flex-col items-center justify-center font-bold border-4 border-white transition-all ' + (v ? '' : 'opacity-0')} style={{ background: v ? COL[v - 1] : 'transparent' }}>{v ? <><span>{TILE_E[v - 1]}</span><span className="text-lg text-white" style={{ textShadow: '0 1px 2px #0006' }}>{v}</span></> : ''}</button>)}
      </div>
    </Wrap>
  );
};

// ───────── 27. 시몬 따라하기 ─────────
export const Simon = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const [seq, setSeq] = useState<number[]>(() => [rnd(4)]);
  const [step, setStep] = useState(0);
  const [lit, setLit] = useState(-1);
  const [showing, setShowing] = useState(true);
  const [over, setOver] = useState(false);
  const timers = useRef<number[]>([]);
  useEffect(() => {
    setShowing(true); setStep(0);
    seq.forEach((p, i) => {
      timers.current.push(window.setTimeout(() => { setLit(p); sfx('note' + p); }, 800 + i * 650));
      timers.current.push(window.setTimeout(() => setLit(-1), 800 + i * 650 + 400));
    });
    timers.current.push(window.setTimeout(() => setShowing(false), 800 + seq.length * 650));
    return () => { timers.current.forEach(clearTimeout); timers.current = []; };
  }, [seq]);
  const press = (p: number) => {
    if (showing || over) return;
    setLit(p); sfx('note' + p); setTimeout(() => setLit(-1), 200);
    if (p !== seq[step]) { setOver(true); sfx('lose'); end(seq.length - 1, Math.min(300, (seq.length - 1) * 14 + 10)); return; }
    if (step + 1 === seq.length) { setTimeout(() => setSeq([...seq, rnd(4)]), 500); setShowing(true); } else setStep(step + 1);
  };
  const C = [['#ff7eb6', '#ffd0e4'], ['#ffc83a', '#fff0b0'], ['#4ac88a', '#c8f8e0'], ['#5aa8ff', '#d0e8ff']];
  return (
    <Wrap>
      <Hud><span>단계 {seq.length}</span><span>{showing ? '👀 잘 보세요!' : over ? '틀렸어요!' : '🎵 따라 해보세요!'}</span></Hud>
      <div className="grid grid-cols-2 gap-3 w-72">
        {C.map((c, i) => <button key={i} onClick={() => press(i)} className="aspect-square rounded-3xl border-4 border-white text-5xl transition-all" style={{ background: lit === i ? c[1] : c[0], boxShadow: lit === i ? `0 0 30px ${c[0]}` : '0 4px 0 #0002', transform: lit === i ? 'scale(1.06)' : '' }}>{['🐧', '🐟', '⭐', '❄️'][i]}</button>)}
      </div>
    </Wrap>
  );
};

// ───────── 28. 4x4 스도쿠 ─────────
function makeSudoku() {
  const base = (r: number, c: number) => (r * 2 + Math.floor(r / 2) + c) % 4;
  const digits = shuffle([1, 2, 3, 4]);
  const rows = [...shuffle([0, 1]), ...shuffle([2, 3])];
  const cols = [...shuffle([0, 1]), ...shuffle([2, 3])];
  const sol = rows.map((r) => cols.map((c) => digits[base(r, c)]));
  const hidden = new Set(shuffle(Array.from({ length: 16 }, (_, i) => i)).slice(0, 8));
  return { sol: sol.flat(), hidden };
}
export const Sudoku = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const [pz] = useState(makeSudoku);
  const [vals, setVals] = useState<number[]>(() => pz.sol.map((v, i) => (pz.hidden.has(i) ? 0 : v)));
  const [sel, setSel] = useState(-1);
  const [mist, setMist] = useState(0);
  const [hints, setHints] = useState(0);
  const check = (n: number[]) => { if (n.every((v, i) => v === pz.sol[i])) { sfx('win'); end(1, Math.max(40, 180 - mist * 15 - hints * 30)); } };
  const put = (d: number) => {
    if (sel < 0 || !pz.hidden.has(sel)) return;
    if (pz.sol[sel] !== d) { setMist(mist + 1); sfx('error'); return; }
    const n = vals.slice(); n[sel] = d; setVals(n); sfx('pop'); check(n);
  };
  const hint = () => { const e = vals.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0); if (!e.length) return; const i = pick(e); const n = vals.slice(); n[i] = pz.sol[i]; setVals(n); setHints(hints + 1); sfx('coin'); check(n); };
  return (
    <Wrap>
      <Hud><span>❌ {mist}</span><span>💡 힌트 {hints}</span></Hud>
      <div className="grid grid-cols-4 w-72 border-4 border-sky-400 rounded-xl overflow-hidden bg-white">
        {vals.map((v, i) => {
          const x = i % 4, y = Math.floor(i / 4);
          return <button key={i} onClick={() => setSel(i)} className={'aspect-square text-3xl font-bold flex items-center justify-center ' + (sel === i ? 'bg-pink-100 ' : '') + (pz.hidden.has(i) ? 'text-pink-500' : 'text-sky-700')} style={{ borderRight: x === 1 ? '3px solid #38a0e8' : x < 3 ? '1px solid #cfe6f5' : 'none', borderBottom: y === 1 ? '3px solid #38a0e8' : y < 3 ? '1px solid #cfe6f5' : 'none' }}>{v ? ['', '🐧', '🐟', '⭐', '🍓'][v] : ''}</button>;
        })}
      </div>
      <div className="flex gap-2 mt-4">{[1, 2, 3, 4].map((d) => <button key={d} onClick={() => put(d)} className="btn-cute w-14 h-14 text-3xl">{['', '🐧', '🐟', '⭐', '🍓'][d]}</button>)}</div>
      <button className="btn-cute mt-3 px-5 py-2" onClick={hint}>💡 힌트 보기</button>
      <p className="text-xs text-sky-700 mt-2 text-center">가로·세로·2×2 칸에 같은 그림이 겹치지 않게 채워요.</p>
    </Wrap>
  );
};

// ───────── 29. 펭귄 퀴즈 ─────────
const QUIZ: [string, string[], number][] = [
  ['가장 큰 펭귄은 누구일까요?', ['황제펭귄', '아델리펭귄', '쇠푸른펭귄', '마카로니펭귄'], 0],
  ['가장 작은 펭귄은?', ['임금펭귄', '쇠푸른펭귄', '젠투펭귄', '황제펭귄'], 1],
  ['펭귄은 어떤 동물일까요?', ['포유류', '어류', '조류', '파충류'], 2],
  ['황제펭귄의 알을 품는 건?', ['엄마', '아빠', '할머니', '이웃'], 1],
  ['펭귄이 추위를 이기려고 모여 서로 체온을 나누는 행동은?', ['허들링', '러닝', '스트레칭', '점핑'], 0],
  ['아기 펭귄을 부르는 말은?', ['새끼 곰', '병아리', '올챙이', '망아지'], 1],
  ['펭귄이 좋아하는 먹이는?', ['당근', '크릴과 물고기', '풀', '치즈'], 1],
  ['펭귄이 청혼할 때 주는 선물은?', ['조약돌', '꽃', '사탕', '반지'], 0],
  ['펭귄 무리를 부르는 말은?', ['콜로니', '팩', '떼구름', '리그'], 0],
  ['펭귄은 하늘을 날 수 있을까요?', ['네, 아주 높이!', '날지 못하지만 수영 선수!', '밤에만 날아요', '바람 불 때만'], 1],
  ['갤라파고스펭귄은 어디 가까이 살까요?', ['북극', '적도 근처', '사막 한가운데', '히말라야'], 1],
  ['펭귄의 날개는 무엇처럼 쓰일까요?', ['지느러미 같은 노', '낙하산', '우산', '부채'], 0],
];
export const Quiz = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const [qs] = useState(() => shuffle(QUIZ).slice(0, 10).map((q) => { const opts = shuffle(q[1].map((t, i) => ({ t, ok: i === q[2] }))); return { q: q[0], opts }; }));
  const [i, setI] = useState(0);
  const [ok, setOk] = useState(0);
  const [pick_, setPick] = useState(-1);
  const ans = (k: number) => {
    if (pick_ >= 0) return; setPick(k); const right = qs[i].opts[k].ok; sfx(right ? 'coin' : 'error');
    const n = ok + (right ? 1 : 0); if (right) setOk(n);
    setTimeout(() => { if (i + 1 >= qs.length) end(n, 10 + n * 22, 100); else { setI(i + 1); setPick(-1); } }, 900);
  };
  return (
    <Wrap>
      <Hud><span>문제 {i + 1}/10</span><span>✅ {ok}</span></Hud>
      <div className="w-full bg-white rounded-3xl border-4 border-sky-200 p-5 text-center text-xl font-bold text-sky-700 mb-3">🐧 {qs[i].q}</div>
      <div className="grid grid-cols-1 gap-2 w-full">
        {qs[i].opts.map((o, k) => <button key={k} onClick={() => ans(k)} className={'btn-cute py-3 text-lg font-bold text-gray-600 ' + (pick_ >= 0 && o.ok ? '!bg-green-200 !border-green-400' : pick_ === k ? '!bg-red-200 !border-red-400' : '')}>{o.t}</button>)}
      </div>
    </Wrap>
  );
};

// ───────── 30. 캔디 매치3 ─────────
const FR = ['🍓', '🍋', '🍈', '🫐', '🍭'];
const GN = 7;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
function findMatches(g: number[]) {
  const m = new Set<number>();
  for (let y = 0; y < GN; y++) for (let x = 0; x < GN; x++) {
    const v = g[y * GN + x]; if (v < 0) continue;
    if (x < GN - 2 && g[y * GN + x + 1] === v && g[y * GN + x + 2] === v) { m.add(y * GN + x); m.add(y * GN + x + 1); m.add(y * GN + x + 2); }
    if (y < GN - 2 && g[(y + 1) * GN + x] === v && g[(y + 2) * GN + x] === v) { m.add(y * GN + x); m.add((y + 1) * GN + x); m.add((y + 2) * GN + x); }
  }
  return m;
}
export const Match3 = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const [g, setG] = useState<number[]>(() => { let a: number[]; do { a = Array.from({ length: GN * GN }, () => rnd(5)); } while (findMatches(a).size); return a; });
  const [sel, setSel] = useState(-1);
  const [moves, setMoves] = useState(20);
  const [score, setScore] = useState(0);
  const [busy, setBusy] = useState(false);
  const [popping, setPopping] = useState<Set<number>>(new Set());
  const gr = useRef(g); gr.current = g;
  const swapTry = async (a: number, b: number) => {
    setBusy(true);
    let n = gr.current.slice(); [n[a], n[b]] = [n[b], n[a]]; setG(n); gr.current = n; await sleep(200);
    let m = findMatches(n);
    if (!m.size) { sfx('error'); [n[a], n[b]] = [n[b], n[a]]; n = n.slice(); setG(n); gr.current = n; await sleep(150); setBusy(false); return; }
    setMoves((v) => v - 1);
    let combo = 1, gain = 0;
    while (m.size) {
      sfx(combo > 1 ? 'win' : 'pop'); setPopping(new Set(m)); await sleep(260);
      gain += m.size * 10 * combo; setScore((s) => s + m.size * 10 * combo);
      n = n.slice(); m.forEach((i) => (n[i] = -1));
      for (let x = 0; x < GN; x++) { const col: number[] = []; for (let y = GN - 1; y >= 0; y--) if (n[y * GN + x] >= 0) col.push(n[y * GN + x]); while (col.length < GN) col.push(rnd(5)); for (let y = GN - 1, k = 0; y >= 0; y--, k++) n[y * GN + x] = col[k]; }
      setPopping(new Set()); setG(n); gr.current = n; await sleep(260); m = findMatches(n); combo++;
    }
    setBusy(false); void gain;
  };
  useEffect(() => { if (moves <= 0 && !busy) { const s = score; end(s, Math.min(300, Math.round(s / 6)), 800); } }, [moves, busy, score, end]);
  const tap = (i: number) => {
    if (busy || moves <= 0) return;
    if (sel < 0) { setSel(i); sfx('tick'); return; }
    const d = Math.abs((sel % GN) - (i % GN)) + Math.abs(Math.floor(sel / GN) - Math.floor(i / GN));
    if (d === 1) { const s = sel; setSel(-1); swapTry(s, i); } else setSel(i);
  };
  return (
    <Wrap>
      <Hud><span>🍬 {score}</span><span>남은 이동 {Math.max(0, moves)}</span></Hud>
      <div className="grid grid-cols-7 gap-1 w-full p-2 bg-pink-200 rounded-3xl">
        {g.map((v, i) => <button key={i} onClick={() => tap(i)} className={'aspect-square rounded-xl text-3xl flex items-center justify-center bg-white border-2 transition-all duration-200 ' + (sel === i ? 'border-pink-500 scale-110' : 'border-pink-100') + (popping.has(i) ? ' scale-0 opacity-0' : '')}>{FR[v]}</button>)}
      </div>
      <p className="text-xs text-sky-700 mt-2">인접한 두 과일을 바꿔 3개 이상 맞춰요!</p>
    </Wrap>
  );
};
