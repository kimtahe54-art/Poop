import { useCallback, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { GameProps, shuffle } from './engine';
import { Penguin } from '../components/Penguin';
import { SeaArt, SeaDefs, SEA } from '../components/SeaArt';
import { TOTAL_SPECIES, pick, rnd, speciesSpec } from '../data/penguinData';
import { sfx } from '../audio';

export function useEnd(onFinish: GameProps['onFinish']) {
  const done = useRef(false);
  return useCallback((s: number, c: number, delay = 1100) => {
    if (done.current) return;
    done.current = true;
    setTimeout(() => onFinish(s, c), delay);
  }, [onFinish]);
}
export const Hud = ({ children }: { children: ReactNode }) => (
  <div className="flex justify-between items-center gap-3 px-4 py-2 mb-3 rounded-2xl bg-white/80 border-2 border-pink-200 text-pink-600 font-bold text-lg">{children}</div>
);
export const Wrap = ({ children }: { children: ReactNode }) => <div className="flex flex-col items-center w-full max-w-md mx-auto">{children}</div>;

// ───────── 15. 펭귄 짝맞추기 ─────────
export const Memory = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const [cards] = useState(() => {
    const ids = new Set<number>(); while (ids.size < 8) ids.add(rnd(TOTAL_SPECIES));
    return shuffle([...ids, ...ids].map((sid, i) => ({ k: i, sid })));
  });
  const [open, setOpen] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [lock, setLock] = useState(false);
  const flip = (i: number) => {
    if (lock || open.includes(i) || matched.includes(i)) return;
    sfx('click');
    const o = [...open, i]; setOpen(o);
    if (o.length === 2) {
      setMoves((m) => m + 1); setLock(true);
      if (cards[o[0]].sid === cards[o[1]].sid) {
        setTimeout(() => { sfx('coin'); const m = [...matched, o[0], o[1]]; setMatched(m); setOpen([]); setLock(false); if (m.length === 16) { sfx('win'); end(100 - moves, Math.max(40, 200 - (moves + 1) * 8)); } }, 500);
      } else setTimeout(() => { setOpen([]); setLock(false); }, 800);
    }
  };
  return (
    <Wrap>
      <Hud><span>👣 {moves}번</span><span>짝 {matched.length / 2}/8</span></Hud>
      <div className="grid grid-cols-4 gap-2 w-full">
        {cards.map((c, i) => {
          const show = open.includes(i) || matched.includes(i);
          return (
            <button key={c.k} onClick={() => flip(i)} className={'aspect-[3/4] rounded-2xl border-4 flex items-center justify-center transition-all ' + (show ? 'bg-white border-pink-300 ' : 'bg-gradient-to-br from-pink-300 to-sky-300 border-white ') + (matched.includes(i) ? 'opacity-70' : '')}>
              {show ? <Penguin spec={speciesSpec(c.sid)} size={58} still /> : <span className="text-3xl">🐾</span>}
            </button>
          );
        })}
      </div>
    </Wrap>
  );
};

// ───────── 16. 눈송이 2048 ─────────
type Grid = number[][];
const TILE_C: Record<number, string> = { 0: '#e8f4fb', 2: '#fff', 4: '#ffeef6', 8: '#ffc8dc', 16: '#ffb0cc', 32: '#ff98bc', 64: '#ff80ac', 128: '#ffd86a', 256: '#ffc84a', 512: '#9fe0ff', 1024: '#7fc8ff', 2048: '#c0a0ff' };
function slideRow(r: number[]) {
  const a = r.filter(Boolean); let gain = 0;
  for (let i = 0; i < a.length - 1; i++) if (a[i] === a[i + 1]) { a[i] *= 2; gain += a[i]; a.splice(i + 1, 1); }
  while (a.length < 4) a.push(0);
  return { row: a, gain };
}
function addTile(g: Grid) {
  const e: [number, number][] = [];
  g.forEach((r, y) => r.forEach((v, x) => { if (!v) e.push([y, x]); }));
  if (!e.length) return g;
  const [y, x] = pick(e); const n = g.map((r) => r.slice()); n[y][x] = Math.random() < 0.85 ? 2 : 4; return n;
}
export const Game2048 = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const [g, setG] = useState<Grid>(() => addTile(addTile(Array.from({ length: 4 }, () => [0, 0, 0, 0]))));
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);
  const gRef = useRef(g); gRef.current = g;
  const sRef = useRef(score); sRef.current = score;
  const touch = useRef<{ x: number; y: number } | null>(null);
  const move = useCallback((d: 'L' | 'R' | 'U' | 'D') => {
    const cur = gRef.current; let gain = 0;
    const rot = (m: Grid) => m[0].map((_, i) => m.map((r) => r[i]).reverse());
    let m = cur.map((r) => r.slice());
    const times = { L: 0, D: 1, R: 2, U: 3 }[d];
    for (let i = 0; i < times; i++) m = rot(m);
    m = m.map((r) => { const o = slideRow(r); gain += o.gain; return o.row; });
    for (let i = 0; i < (4 - times) % 4; i++) m = rot(m);
    if (JSON.stringify(m) === JSON.stringify(cur)) return;
    sfx(gain ? 'pop' : 'tick');
    const n = addTile(m); setG(n); setScore((s) => s + gain);
    const can = n.some((r, y) => r.some((v, x) => !v || (x < 3 && v === r[x + 1]) || (y < 3 && v === n[y + 1][x])));
    if (!can) { setOver(true); sfx('lose'); end(sRef.current + gain, Math.min(300, Math.round((sRef.current + gain) / 10))); }
  }, [end]);
  useEffect(() => {
    const kd = (e: KeyboardEvent) => { const m: Record<string, 'L' | 'R' | 'U' | 'D'> = { ArrowLeft: 'L', ArrowRight: 'R', ArrowUp: 'U', ArrowDown: 'D', a: 'L', d: 'R', w: 'U', s: 'D' }; if (m[e.key]) { e.preventDefault(); move(m[e.key]); } };
    window.addEventListener('keydown', kd); return () => window.removeEventListener('keydown', kd);
  }, [move]);
  return (
    <Wrap>
      <Hud><span>❄️ {score}</span><button className="btn-cute px-3 text-sm" onClick={() => { setOver(true); end(score, Math.min(300, Math.round(score / 10)), 300); }}>그만하기</button></Hud>
      <div className="grid grid-cols-4 gap-2 p-2 rounded-3xl bg-sky-200 w-full touch-none"
        onPointerDown={(e) => { touch.current = { x: e.clientX, y: e.clientY }; }}
        onPointerUp={(e) => { const t = touch.current; if (!t) return; const dx = e.clientX - t.x, dy = e.clientY - t.y; if (Math.hypot(dx, dy) > 24) move(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'R' : 'L') : dy > 0 ? 'D' : 'U'); touch.current = null; }}>
        {g.flat().map((v, i) => (
          <div key={i} className="aspect-square rounded-2xl flex items-center justify-center text-2xl font-bold border-2 border-white/70" style={{ background: TILE_C[v] || '#9a70ff', color: v > 4 ? '#fff' : '#d0608a', textShadow: v > 4 ? '0 1px 2px #0004' : 'none' }}>
            {v ? <span className="flex flex-col items-center leading-none"><span className="text-sm">{v >= 128 ? '🐧' : '❄️'}</span>{v}</span> : ''}
          </div>
        ))}
      </div>
      <p className="mt-3 text-sm text-sky-700">화살표 키 또는 스와이프로 같은 숫자를 합쳐요!</p>
      {over && <p className="mt-2 text-pink-500 font-bold">게임 끝!</p>}
    </Wrap>
  );
};

// ───────── 17. 얼음 지뢰찾기 ─────────
export const Mines = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const N = 8, M = 10;
  const [cells, setCells] = useState<{ m: boolean; r: boolean; f: boolean; n: number }[] | null>(null);
  const [flagMode, setFlagMode] = useState(false);
  const [state, setState] = useState<'play' | 'win' | 'lose'>('play');
  const [t0] = useState(Date.now());
  const build = (safe: number) => {
    const arr = Array.from({ length: N * N }, () => ({ m: false, r: false, f: false, n: 0 }));
    const cand = shuffle(Array.from({ length: N * N }, (_, i) => i).filter((i) => Math.abs((i % N) - (safe % N)) > 1 || Math.abs(Math.floor(i / N) - Math.floor(safe / N)) > 1));
    cand.slice(0, M).forEach((i) => (arr[i].m = true));
    arr.forEach((c, i) => { const x = i % N, y = Math.floor(i / N); let n = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const nx = x + dx, ny = y + dy; if (nx >= 0 && ny >= 0 && nx < N && ny < N && arr[ny * N + nx].m) n++; } c.n = n; });
    return arr;
  };
  const click = (i: number) => {
    if (state !== 'play') return;
    let cs = cells ? cells.map((c) => ({ ...c })) : build(i);
    if (cs[i].r) return;
    if (flagMode) { cs[i].f = !cs[i].f; sfx('tick'); setCells(cs); return; }
    if (cs[i].f) return;
    if (cs[i].m) { cs.forEach((c) => { if (c.m) c.r = true; }); setCells(cs); setState('lose'); sfx('lose'); end(0, Math.round(cs.filter((c) => c.r && !c.m).length / 2)); return; }
    const q = [i];
    while (q.length) {
      const k = q.pop()!; if (cs[k].r || cs[k].f) continue; cs[k].r = true;
      if (cs[k].n === 0) { const x = k % N, y = Math.floor(k / N); for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const nx = x + dx, ny = y + dy; if (nx >= 0 && ny >= 0 && nx < N && ny < N) q.push(ny * N + nx); } }
    }
    sfx('pop'); setCells(cs);
    if (cs.filter((c) => c.r).length === N * N - M) { setState('win'); sfx('win'); const sec = (Date.now() - t0) / 1000; end(100, Math.min(300, 140 + Math.max(0, Math.round(120 - sec)))); }
  };
  const view = cells || Array.from({ length: N * N }, () => ({ m: false, r: false, f: false, n: 0 }));
  const NC = ['', '#3a8ae8', '#2aa860', '#e8503a', '#7a4ae0', '#c8742a', '#2ab0b0', '#333', '#888'];
  return (
    <Wrap>
      <Hud><span>🧊 개구쟁이 물범 {M - view.filter((c) => c.f).length}</span><button className={'btn-cute px-3 text-sm ' + (flagMode ? '!bg-pink-200' : '')} onClick={() => setFlagMode(!flagMode)}>🚩 깃발 {flagMode ? 'ON' : 'OFF'}</button></Hud>
      <div className="grid grid-cols-8 gap-1 w-full p-2 bg-sky-200 rounded-3xl">
        {view.map((c, i) => (
          <button key={i} onClick={() => click(i)} className={'aspect-square rounded-xl text-lg font-bold flex items-center justify-center border-2 ' + (c.r ? 'bg-white border-sky-100' : 'bg-gradient-to-br from-cyan-100 to-sky-300 border-white')}>
            {c.r ? (c.m ? '🦭' : c.n ? <span style={{ color: NC[c.n] }}>{c.n}</span> : '') : c.f ? '🚩' : ''}
          </button>
        ))}
      </div>
      <p className="mt-3 text-sm text-sky-700">숫자는 주변 8칸의 물범 수! 물범이 없는 칸을 모두 열어요.</p>
      {state === 'win' && <p className="text-pink-500 font-bold mt-2">클리어! 🎉</p>}{state === 'lose' && <p className="text-pink-500 font-bold mt-2">앗, 물범을 깨웠어요!</p>}
    </Wrap>
  );
};

// ───────── 18. 틱택토 (3판) ─────────
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const winner = (b: string[]) => { for (const [x, y, z] of LINES) if (b[x] && b[x] === b[y] && b[x] === b[z]) return b[x]; return b.every(Boolean) ? 'D' : ''; };
function minimax(b: string[], turn: string): number {
  const w = winner(b); if (w === 'O') return 1; if (w === 'X') return -1; if (w === 'D') return 0;
  const sc = b.map((v, i) => { if (v) return null; const n = b.slice(); n[i] = turn; return minimax(n, turn === 'O' ? 'X' : 'O'); }).filter((v) => v !== null) as number[];
  return turn === 'O' ? Math.max(...sc) : Math.min(...sc);
}
export const TicTacToe = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const [b, setB] = useState<string[]>(Array(9).fill(''));
  const [round, setRound] = useState(1);
  const [res, setRes] = useState<number[]>([]);
  const [msg, setMsg] = useState('내 차례! (🐧 = X)');
  const [lock, setLock] = useState(false);
  const finishRound = (nb: string[], w: string) => {
    const r = w === 'X' ? 2 : w === 'D' ? 1 : 0; const rs = [...res, r]; setRes(rs); setLock(true);
    setMsg(w === 'X' ? '이겼다! 🎉' : w === 'D' ? '비겼어요!' : '졌어요 ㅠㅠ'); sfx(w === 'X' ? 'win' : w === 'D' ? 'click' : 'lose');
    setTimeout(() => {
      if (rs.length >= 3) { const wins = rs.filter((x) => x === 2).length, draws = rs.filter((x) => x === 1).length; end(wins, 20 + wins * 80 + draws * 30, 200); }
      else { setB(Array(9).fill('')); setRound(round + 1); setLock(false); setMsg('내 차례!'); }
    }, 1200);
    void nb;
  };
  const play = (i: number) => {
    if (b[i] || lock) return; sfx('pop');
    const nb = b.slice(); nb[i] = 'X'; setB(nb);
    let w = winner(nb); if (w) return finishRound(nb, w);
    setLock(true);
    setTimeout(() => {
      const empt = nb.map((v, k) => (v ? -1 : k)).filter((k) => k >= 0);
      let mv = pick(empt);
      if (Math.random() > 0.3) { let best = -2; for (const k of empt) { const n = nb.slice(); n[k] = 'O'; const s = minimax(n, 'X'); if (s > best) { best = s; mv = k; } } }
      nb[mv] = 'O'; setB(nb.slice()); sfx('click'); w = winner(nb);
      if (w) finishRound(nb, w); else setLock(false);
    }, 450);
  };
  return (
    <Wrap>
      <Hud><span>{round}/3 라운드</span><span>{res.map((r) => (r === 2 ? '🏆' : r === 1 ? '🤝' : '💧')).join(' ')}</span></Hud>
      <div className="grid grid-cols-3 gap-2 w-72">
        {b.map((v, i) => <button key={i} onClick={() => play(i)} className="aspect-square rounded-2xl bg-white border-4 border-sky-200 text-5xl flex items-center justify-center">{v === 'X' ? '🐧' : v === 'O' ? '🐻‍❄️' : ''}</button>)}
      </div>
      <p className="mt-3 text-pink-500 font-bold">{msg}</p>
    </Wrap>
  );
};

// ───────── 19. 사목 (커넥트 포) ─────────
const R = 6, C = 7;
function win4(b: number[][], p: number) {
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) for (const [dr, dc] of [[0, 1], [1, 0], [1, 1], [1, -1]]) {
    let k = 0; for (; k < 4; k++) { const rr = r + dr * k, cc = c + dc * k; if (rr < 0 || rr >= R || cc < 0 || cc >= C || b[rr][cc] !== p) break; } if (k === 4) return true;
  }
  return false;
}
function dropAt(b: number[][], c: number, p: number) { for (let r = R - 1; r >= 0; r--) if (!b[r][c]) { const n = b.map((x) => x.slice()); n[r][c] = p; return n; } return null; }
function evalB(b: number[][]) {
  let s = 0;
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) for (const [dr, dc] of [[0, 1], [1, 0], [1, 1], [1, -1]]) {
    let me = 0, op = 0, ok = true;
    for (let k = 0; k < 4; k++) { const rr = r + dr * k, cc = c + dc * k; if (rr < 0 || rr >= R || cc < 0 || cc >= C) { ok = false; break; } if (b[rr][cc] === 2) me++; else if (b[rr][cc] === 1) op++; }
    if (!ok) continue; if (me && !op) s += [0, 1, 6, 30][me] ?? 0; if (op && !me) s -= [0, 1, 6, 40][op] ?? 0;
  }
  for (let r = 0; r < R; r++) if (b[r][3] === 2) s += 3;
  return s;
}
function search(b: number[][], depth: number, p: number, al: number, be: number): number {
  if (win4(b, 2)) return 10000 + depth; if (win4(b, 1)) return -10000 - depth;
  if (depth === 0) return evalB(b);
  let any = false;
  if (p === 2) { let v = -1e9; for (const c of [3, 2, 4, 1, 5, 0, 6]) { const n = dropAt(b, c, 2); if (!n) continue; any = true; v = Math.max(v, search(n, depth - 1, 1, al, be)); al = Math.max(al, v); if (al >= be) break; } return any ? v : 0; }
  let v = 1e9; for (const c of [3, 2, 4, 1, 5, 0, 6]) { const n = dropAt(b, c, 1); if (!n) continue; any = true; v = Math.min(v, search(n, depth - 1, 2, al, be)); be = Math.min(be, v); if (al >= be) break; } return any ? v : 0;
}
export const Connect4 = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const [b, setB] = useState<number[][]>(Array.from({ length: R }, () => Array(C).fill(0)));
  const [lock, setLock] = useState(false);
  const [msg, setMsg] = useState('열을 눌러 🐧을 떨어뜨리세요! 4개를 먼저 이으면 승리!');
  const fin = (w: number) => { setLock(true); setMsg(w === 1 ? '이겼어요! 🎉' : w === 2 ? '졌어요…' : '무승부!'); sfx(w === 1 ? 'win' : w === 2 ? 'lose' : 'click'); end(w === 1 ? 1 : 0, w === 1 ? 220 : w === 0 ? 80 : 25); };
  const play = (c: number) => {
    if (lock) return; const nb = dropAt(b, c, 1); if (!nb) return; sfx('pop'); setB(nb);
    if (win4(nb, 1)) return fin(1);
    if (nb.every((r) => r.every(Boolean))) return fin(0);
    setLock(true);
    setTimeout(() => {
      let best = -1e9, mv = 3; const cols = shuffle([0, 1, 2, 3, 4, 5, 6]);
      for (const k of cols) { const n = dropAt(nb, k, 2); if (!n) continue; const s = search(n, 4, 1, -1e9, 1e9) + Math.random() * 2; if (s > best) { best = s; mv = k; } }
      const n2 = dropAt(nb, mv, 2)!; setB(n2); sfx('click');
      if (win4(n2, 2)) return fin(2);
      if (n2.every((r) => r.every(Boolean))) return fin(0);
      setLock(false);
    }, 500);
  };
  return (
    <Wrap>
      <div className="grid grid-cols-7 gap-1 p-2 bg-sky-400 rounded-3xl w-full">
        {Array.from({ length: C }, (_, c) => (
          <div key={c} onClick={() => play(c)} className="flex flex-col gap-1 cursor-pointer">
            {b.map((row, r) => <div key={r} className="aspect-square rounded-full bg-sky-100 flex items-center justify-center text-2xl border-2 border-sky-300">{row[c] === 1 ? '🐧' : row[c] === 2 ? '🐻‍❄️' : ''}</div>)}
          </div>
        ))}
      </div>
      <p className="mt-3 text-pink-500 font-bold text-center">{msg}</p>
    </Wrap>
  );
};

// ───────── 20. 불끄기 ─────────
export const Lights = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const [g, setG] = useState<boolean[]>(() => {
    const a = Array(25).fill(false); const press = (i: number) => { const x = i % 5, y = Math.floor(i / 5); [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([dx, dy]) => { const nx = x + dx, ny = y + dy; if (nx >= 0 && ny >= 0 && nx < 5 && ny < 5) a[ny * 5 + nx] = !a[ny * 5 + nx]; }); };
    for (let k = 0; k < 9; k++) press(rnd(25)); if (a.every((v) => !v)) press(12); return a;
  });
  const [moves, setMoves] = useState(0);
  const press = (i: number) => {
    const n = g.slice(); const x = i % 5, y = Math.floor(i / 5);
    [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([dx, dy]) => { const nx = x + dx, ny = y + dy; if (nx >= 0 && ny >= 0 && nx < 5 && ny < 5) n[ny * 5 + nx] = !n[ny * 5 + nx]; });
    setG(n); setMoves(moves + 1); sfx('click');
    if (n.every((v) => !v)) { sfx('win'); end(100, Math.max(40, 240 - moves * 6)); }
  };
  return (
    <Wrap>
      <Hud><span>👆 {moves}번</span><span>불 켜진 방 {g.filter(Boolean).length}</span></Hud>
      <div className="grid grid-cols-5 gap-2 w-full p-3 bg-indigo-900 rounded-3xl">
        {g.map((v, i) => <button key={i} onClick={() => press(i)} className={'aspect-square rounded-2xl text-3xl flex items-center justify-center border-2 transition-all ' + (v ? 'bg-yellow-200 border-yellow-50 shadow-[0_0_18px_#ffe66a]' : 'bg-indigo-800 border-indigo-700')}>{v ? '🐧' : '🌙'}</button>)}
      </div>
      <p className="mt-3 text-sm text-sky-700">누르면 상하좌우 방의 불이 바뀌어요. 모든 불을 꺼보세요!</p>
    </Wrap>
  );
};

// ───────── 21. 색깔 말 맞추기 (스트루프) ─────────
const SC = [['빨강', '#ff4a5a'], ['파랑', '#3a8aff'], ['초록', '#2ab860'], ['노랑', '#e8b800'], ['보라', '#9a5aff'], ['분홍', '#ff6ab8']];
export const Stroop = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const mk = () => { const w = rnd(6); let c = rnd(6); if (Math.random() < 0.8) while (c === w) c = rnd(6); return { w, c }; };
  const [q, setQ] = useState(mk);
  const [time, setTime] = useState(30);
  const [ok, setOk] = useState(0);
  const [bad, setBad] = useState(0);
  const over = time <= 0;
  useEffect(() => { if (over) { end(ok, Math.min(300, ok * 8)); return; } const id = setTimeout(() => setTime((t) => t - 1), 1000); return () => clearTimeout(id); }, [time, over, ok, end]);
  const ans = (i: number) => { if (over) return; if (i === q.c) { setOk(ok + 1); sfx('coin'); } else { setBad(bad + 1); setTime((t) => Math.max(0, t - 2)); sfx('error'); } setQ(mk()); };
  return (
    <Wrap>
      <Hud><span>⏱ {time}초</span><span>✅ {ok} ❌ {bad}</span></Hud>
      <div className="w-full rounded-3xl bg-white border-4 border-pink-200 py-10 text-center">
        <div className="text-sm text-gray-400 mb-2">글자의 '색깔'은 무엇일까요?</div>
        <div className="text-7xl font-bold" style={{ color: SC[q.c][1] }}>{SC[q.w][0]}</div>
      </div>
      <div className="grid grid-cols-3 gap-2 mt-4 w-full">{SC.map((c, i) => <button key={i} onClick={() => ans(i)} className="btn-cute py-3 text-xl font-bold text-gray-600">{c[0]}</button>)}</div>
    </Wrap>
  );
};

// ───────── 22. 물고기 분류 ─────────
export const Sorting = ({ onFinish }: GameProps) => {
  const end = useEnd(onFinish);
  const mk = () => ({ color: rnd(2), dir: rnd(2) });
  const [fish, setFish] = useState(mk);
  const [n, setN] = useState(0);
  const [ok, setOk] = useState(0);
  const [streak, setStreak] = useState(0);
  const [time, setTime] = useState(40);
  const [flash, setFlash] = useState('');
  const rule = Math.floor(n / 7) % 2; // 0 색깔, 1 방향
  const over = time <= 0;
  useEffect(() => { if (over) { end(ok, Math.min(300, ok * 7)); return; } const id = setTimeout(() => setTime((t) => t - 1), 1000); return () => clearTimeout(id); }, [time, over, ok, end]);
  const ans = useCallback((side: number) => {
    if (over) return;
    const correct = rule === 0 ? fish.color : fish.dir;
    if (side === correct) { setOk((o) => o + 1 + (streak >= 4 ? 1 : 0)); setStreak((s) => s + 1); sfx('coin'); setFlash('✅'); } else { setStreak(0); setTime((t) => Math.max(0, t - 2)); sfx('error'); setFlash('❌'); }
    setN((x) => x + 1); setFish(mk()); setTimeout(() => setFlash(''), 250);
  }, [over, rule, fish, streak]);
  useEffect(() => { const kd = (e: KeyboardEvent) => { if (e.key === 'ArrowLeft') ans(0); if (e.key === 'ArrowRight') ans(1); }; window.addEventListener('keydown', kd); return () => window.removeEventListener('keydown', kd); }, [ans]);
  const def = SEA[fish.color === 0 ? 0 : 3];
  return (
    <Wrap>
      <Hud><span>⏱ {time}초</span><span>🔥 연속 {streak}</span><span>⭐ {ok}</span></Hud>
      <div className="w-full text-center rounded-2xl py-2 mb-2 font-bold text-white" style={{ background: rule === 0 ? '#ff7eb6' : '#5aa8ff' }}>
        {rule === 0 ? '🎨 색깔 규칙: 파란 물고기 ◀ 왼쪽 / 분홍 물고기 오른쪽 ▶' : '↔️ 방향 규칙: 보는 방향 쪽 바구니로!'}
      </div>
      <div className="relative w-full h-48 rounded-3xl bg-gradient-to-b from-sky-200 to-sky-400 flex items-center justify-center overflow-hidden">
        <svg viewBox="-70 -50 140 100" width="190"><SeaDefs /><g transform={`scale(${fish.dir === 0 ? -1.3 : 1.3} 1.3)`}><SeaArt d={{ ...def, size: 1 }} /></g></svg>
        <div className="absolute inset-0 flex items-center justify-center text-6xl pointer-events-none">{flash}</div>
      </div>
      <div className="grid grid-cols-2 gap-3 mt-3 w-full">
        <button className="btn-main py-4 text-2xl" onClick={() => ans(0)}>◀ 왼쪽</button>
        <button className="btn-main py-4 text-2xl" onClick={() => ans(1)}>오른쪽 ▶</button>
      </div>
      <p className="text-xs text-sky-700 mt-2">7마리마다 규칙이 바뀌어요! (키보드 ←/→ 가능)</p>
    </Wrap>
  );
};
