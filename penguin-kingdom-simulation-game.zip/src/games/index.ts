import type { ComponentType } from 'react';
import type { GameProps } from './engine';
import { Breakout, Dodge, Flappy, Rhythm, Shooter, Snake, Stack } from './canvasA';
import { Doodle, Frogger, Hockey, Maze, Miner, Plinko, Sled } from './canvasB';
import { Connect4, Game2048, Lights, Memory, Mines, Sorting, Stroop, TicTacToe } from './puzzleA';
import { HiLow, Mastermind, MathBalloons, Match3, Quiz, SlidePuzzle, Simon, Sudoku } from './puzzleB';

export interface GameDef { id: string; title: string; icon: string; desc: string; how: string; type: string; comp: ComponentType<GameProps> }

export const GAMES: GameDef[] = [
  { id: 'flappy', title: '플래피 펭귄', icon: '🕊️', type: '액션', desc: '얼음 기둥 사이를 날아라!', how: '화면을 탭(스페이스)하면 날개짓! 기둥에 닿으면 끝나요.', comp: Flappy },
  { id: 'dodge', title: '눈덩이 피하기', icon: '☃️', type: '액션', desc: '떨어지는 눈덩이를 피하고 생선을 모아요', how: '← → 또는 화면을 드래그해서 움직여요. 🐟 +10, ⭐ +50, 💖 목숨 회복!', comp: Dodge },
  { id: 'breakout', title: '벽돌깨기', icon: '🧱', type: '아케이드', desc: '캔디 벽돌을 모두 깨요', how: '패들을 움직여 공을 튕겨요. 탭/스페이스로 발사!', comp: Breakout },
  { id: 'snake', title: '물고기 뱀', icon: '🐍', type: '아케이드', desc: '펭귄 행렬이 길어져요', how: '방향키/스와이프로 방향 전환. 벽과 내 몸에 부딪히면 끝!', comp: Snake },
  { id: 'shooter', title: '우주 펭귄 슈터', icon: '🚀', type: '슈팅', desc: '로켓을 타고 외계 UFO를 물리쳐요', how: '화면을 누른 채 드래그(또는 방향키)로 이동. 자동 발사! 🔫 아이템은 3연발.', comp: Shooter },
  { id: 'stack', title: '타워 쌓기', icon: '🏗️', type: '타이밍', desc: '블록을 정확히 쌓아 올려요', how: '탭/스페이스로 블록을 떨어뜨려요. 어긋난 만큼 잘려나가요. 연속 퍼펙트는 보너스!', comp: Stack },
  { id: 'rhythm', title: '리듬 펭귄', icon: '🎵', type: '리듬', desc: '음표를 맞춰 연주해요', how: 'D F J K 키 또는 해당 레인을 터치! 선에 맞게 누르면 PERFECT!', comp: Rhythm },
  { id: 'miner', title: '보물 낚시', icon: '🎣', type: '액션', desc: '갈고리를 던져 보물을 건져요', how: '갈고리가 흔들릴 때 탭/스페이스로 발사! 무거운 건 천천히 올라와요.', comp: Miner },
  { id: 'frogger', title: '얼음강 건너기', icon: '🧊', type: '액션', desc: '위험한 길과 강을 건너요', how: '방향키/스와이프로 이동. 길의 동물을 피하고 강에서는 얼음 위에 타세요!', comp: Frogger },
  { id: 'doodle', title: '구름 점프', icon: '☁️', type: '플랫폼', desc: '구름을 밟고 하늘 높이!', how: '← → 또는 드래그로 좌우 이동. 🍄은 슈퍼점프, 갈색 구름은 부서져요.', comp: Doodle },
  { id: 'sled', title: '썰매 레이스', icon: '🛷', type: '레이싱', desc: '눈길을 달리며 장애물을 피해요', how: '← → 키 또는 화면 좌/우를 눌러 차선 변경! 🐟은 모으고 나무·바위·눈사람은 피해요.', comp: Sled },
  { id: 'hockey', title: '에어하키', icon: '🏒', type: '스포츠', desc: '북극곰과 대결! 먼저 5골', how: '마우스/터치로 내 말렛을 움직여 퍽을 상대 골대에 넣어요.', comp: Hockey },
  { id: 'plinko', title: '눈공 플링코', icon: '⚪', type: '확률', desc: '핀 사이로 눈공을 떨어뜨려요', how: '위치를 정하고 탭! 가장자리 칸이 100점이에요. 눈공은 6개.', comp: Plinko },
  { id: 'maze', title: '미로 탈출', icon: '🌀', type: '퍼즐', desc: '생선을 모으고 출구로!', how: '방향키/스와이프로 이동해 🏁 출구까지. 🐟 6마리를 모두 모으면 고득점!', comp: Maze },
  { id: 'memory', title: '펭귄 짝맞추기', icon: '🃏', type: '기억력', desc: '같은 펭귄 카드를 찾아요', how: '카드를 두 장씩 뒤집어 같은 펭귄을 찾아요. 적게 뒤집을수록 코인 UP!', comp: Memory },
  { id: '2048', title: '눈송이 2048', icon: '🔢', type: '퍼즐', desc: '같은 숫자를 합쳐요', how: '방향키/스와이프로 타일을 밀어요. 같은 숫자끼리 합쳐져요.', comp: Game2048 },
  { id: 'mines', title: '얼음 지뢰찾기', icon: '🦭', type: '추리', desc: '숨은 물범을 피해 얼음을 깨요', how: '숫자는 주변 8칸의 물범 수. 🚩 모드로 의심되는 곳에 깃발을 꽂아요.', comp: Mines },
  { id: 'tictactoe', title: '펭귄 틱택토', icon: '❌', type: '두뇌', desc: '북극곰과 3판 승부', how: '가로·세로·대각선으로 3개를 먼저 이으면 승리! 이기면 보너스.', comp: TicTacToe },
  { id: 'connect4', title: '사목 대결', icon: '🔴', type: '두뇌', desc: '북극곰 AI와 4목 대결', how: '열을 눌러 말을 떨어뜨려요. 4개를 먼저 이으면 승리!', comp: Connect4 },
  { id: 'lights', title: '불끄기 퍼즐', icon: '💡', type: '퍼즐', desc: '모든 방의 불을 꺼요', how: '방을 누르면 상하좌우의 불이 바뀌어요. 적게 눌러 클리어!', comp: Lights },
  { id: 'stroop', title: '색깔 말 맞추기', icon: '🎨', type: '반응', desc: '글자 색깔을 재빨리 맞춰요', how: '글자의 뜻이 아니라 "글자 색"을 골라요! 틀리면 시간이 줄어요.', comp: Stroop },
  { id: 'sorting', title: '물고기 분류', icon: '🐠', type: '반응', desc: '바뀌는 규칙에 맞게 분류해요', how: '규칙(색깔/방향)에 맞는 바구니를 골라요. 규칙은 7마리마다 바뀌어요!', comp: Sorting },
  { id: 'hilow', title: '하이로우 카드', icon: '🎴', type: '확률', desc: '다음 카드를 예측해요', how: '다음 카드가 높은지 낮은지 맞혀 연속 기록을 세워요.', comp: HiLow },
  { id: 'math', title: '산수 풍선', icon: '🎈', type: '두뇌', desc: '정답 풍선을 터뜨려요', how: '문제의 정답이 적힌 풍선을 눌러요. 정답 풍선이 날아가면 목숨이 줄어요!', comp: MathBalloons },
  { id: 'mastermind', title: '색깔 코드 해독', icon: '🔐', type: '추리', desc: '비밀 색깔 코드를 맞혀요', how: '4개 색을 골라 확인! ● 검정은 색·위치 정답, ○ 흰색은 색만 정답.', comp: Mastermind },
  { id: 'slide', title: '슬라이딩 퍼즐', icon: '🧩', type: '퍼즐', desc: '타일을 밀어 순서대로', how: '빈칸 옆의 타일을 눌러 밀어요. 1~8 순서로 맞추면 성공!', comp: SlidePuzzle },
  { id: 'simon', title: '시몬 따라하기', icon: '🎹', type: '기억력', desc: '소리와 빛의 순서를 기억해요', how: '깜빡이는 순서를 잘 보고 똑같이 눌러요. 단계가 점점 길어져요!', comp: Simon },
  { id: 'sudoku', title: '미니 스도쿠', icon: '🔣', type: '퍼즐', desc: '4×4 그림 스도쿠', how: '가로·세로·2×2 칸에 같은 그림이 겹치지 않게 채워요.', comp: Sudoku },
  { id: 'quiz', title: '펭귄 상식 퀴즈', icon: '❓', type: '퀴즈', desc: '펭귄 박사에 도전!', how: '10문제 중 많이 맞힐수록 코인을 많이 받아요.', comp: Quiz },
  { id: 'match3', title: '캔디 매치 3', icon: '🍬', type: '퍼즐', desc: '같은 과일 3개를 맞춰요', how: '인접한 과일을 바꿔 3개 이상 이어요. 연쇄가 터질수록 점수 UP!', comp: Match3 },
];
