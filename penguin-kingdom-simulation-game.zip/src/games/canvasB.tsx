import { CanvasGame, GameProps, bgGrad, clamp, drawPeng, emo, mySprite, rand, rr, shuffle, snowBg, txt } from './engine';
import { pick } from '../data/penguinData';

// ───────── 8. 보물 낚시 (골드 마이너) ─────────
export const Miner = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={540} onFinish={onFinish} pad="act" make={(a) => {
    const spr = mySprite();
    const OX = 180, OY = 100;
    const defs = [['🐟', 30, 1.0, 16], ['🐠', 60, 1.3, 16], ['🦀', 80, 1.6, 18], ['🐚', 100, 1.0, 14], ['💎', 250, 0.9, 12], ['🪨', 15, 3.2, 24], ['👢', 5, 1.2, 16], ['🐙', 150, 2.2, 22]] as const;
    const items: { x: number; y: number; e: string; v: number; w: number; r: number }[] = [];
    for (let i = 0; i < 16; i++) {
      const d = defs[Math.random() < 0.25 ? 5 : Math.floor(rand(0, defs.length))];
      let x = 0, y = 0, ok = false;
      for (let k = 0; k < 30 && !ok; k++) { x = rand(30, 330); y = rand(190, 500); ok = items.every((o) => Math.hypot(o.x - x, o.y - y) > o.r + d[3] + 6); }
      items.push({ x, y, e: d[0], v: d[1], w: d[2], r: d[3] });
    }
    let t = 0, ang = 0, state: 'swing' | 'out' | 'back' = 'swing', len = 30, score = 0, time = 55, caught: typeof items[0] | null = null, pop = { s: '', t: 0 };
    const tip = () => ({ x: OX + Math.sin(ang) * len, y: OY + Math.cos(ang) * len });
    return {
      update(dt) {
        t += dt; time -= dt; pop.t -= dt;
        if (state === 'swing') {
          ang = Math.sin(t * 1.9) * 1.15;
          if (a.ptr.pressed || a.hit.has(' ') || a.hit.has('ArrowDown')) { state = 'out'; a.sfx('splash'); }
        } else if (state === 'out') {
          len += 330 * dt; const p = tip();
          for (const it of items) if (Math.hypot(it.x - p.x, it.y - p.y) < it.r + 6) { caught = it; break; }
          if (caught) { items.splice(items.indexOf(caught), 1); state = 'back'; a.sfx('pop'); }
          else if (p.x < 5 || p.x > 355 || p.y > 530) state = 'back';
        } else {
          len -= (caught ? 300 / caught.w : 360) * dt;
          if (len <= 30) { len = 30; state = 'swing'; if (caught) { score += caught.v; pop = { s: `+${caught.v}`, t: 0.8 }; a.sfx(caught.v >= 60 ? 'coin' : 'click'); caught = null; } }
        }
        if (time <= 0 || items.length === 0) a.finish(score, Math.min(300, Math.round(score / 4)));
      },
      draw(c) {
        bgGrad(c, a.W, a.H, '#bfe8ff', '#2a78c0');
        c.fillStyle = '#fff'; rr(c, 0, 0, a.W, 106, 0); c.fill(); c.fillStyle = '#dff2ff'; c.fillRect(0, 96, a.W, 12);
        for (let i = 0; i < 8; i++) { c.fillStyle = '#ffffff22'; c.beginPath(); c.arc((i * 70 + t * 12) % 380, 200 + i * 40, 10 + i, 0, 7); c.fill(); }
        items.forEach((it) => emo(c, it.e, it.x, it.y, it.r * 2));
        const p = tip();
        c.strokeStyle = '#6a4a2a'; c.lineWidth = 3; c.beginPath(); c.moveTo(OX, OY); c.lineTo(p.x, p.y); c.stroke();
        c.strokeStyle = '#c0c8d8'; c.lineWidth = 4; c.beginPath(); c.arc(p.x, p.y + 2, 8, 0.1 * Math.PI - ang, 0.9 * Math.PI - ang + Math.PI * 0); c.stroke();
        if (caught) emo(c, caught.e, p.x, p.y + 14, caught.r * 2);
        drawPeng(c, spr, OX - 38, 62, 46); emo(c, '🎣', OX - 8, 78, 26);
        txt(c, `💰 ${score}`, 12, 24, 20, '#ff6fa5'); txt(c, `${Math.max(0, Math.ceil(time))}초`, a.W - 12, 24, 20, '#4a8ad8', 'right');
        if (pop.t > 0) txt(c, pop.s, 180, 140, 28, '#ffe86a', 'center');
      },
    };
  }} />
);

// ───────── 9. 얼음강 건너기 ─────────
export const Frogger = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={480} onFinish={onFinish} pad="dir" make={(a) => {
    const spr = mySprite();
    const CS = 40, OY = 40, ROWS = 10;
    interface Row { v: number; sp: number; w: number; n: number; e: string; off: number; kind: 'road' | 'river' | 'safe' }
    const rows: Row[] = [];
    for (let r = 0; r < ROWS; r++) {
      if (r === 0 || r === 4 || r === 9) rows.push({ v: 0, sp: 0, w: 0, n: 0, e: '', off: 0, kind: 'safe' });
      else if (r < 4) rows.push({ v: (r % 2 ? 1 : -1) * (50 + r * 18), sp: 150 + r * 10, w: 38, n: 4, e: pick(['🦭', '🐻‍❄️', '🛷']), off: rand(0, 100), kind: 'road' });
      else rows.push({ v: (r % 2 ? -1 : 1) * (36 + (r - 4) * 12), sp: 150, w: 70 + (r % 2) * 20, n: 4, e: '', off: rand(0, 100), kind: 'river' });
    }
    let px = 180, py = 0, lives = 3, score = 0, time = 75, dead = 0, t = 0, maxRow = 0, carry = 0;
    const posOf = (row: Row, i: number) => { const L = row.sp * row.n; return (((i * row.sp + row.off) % L) + L) % L - row.w - 20; };
    const move = (dx: number, dy: number) => {
      if (dead > 0) return;
      px = clamp(px + dx * CS, 20, 340); py = clamp(py + dy, 0, ROWS - 1); a.sfx('tick');
      if (dy > 0 && py > maxRow) { maxRow = py; score += 10; }
      if (rows[py].kind === 'safe') px = Math.round((px - 20) / CS) * CS + 20;
    };
    const die = () => { lives--; dead = 0.7; a.sfx('splash'); };
    return {
      update(dt) {
        t += dt; time -= dt;
        rows.forEach((r) => (r.off += r.v * dt));
        if (dead > 0) { dead -= dt; if (dead <= 0) { px = 180; py = 0; maxRow = 0; if (lives <= 0) a.finish(score, Math.round(score / 5)); } return; }
        if (a.hit.has('ArrowUp') || a.hit.has('w')) move(0, 1); if (a.hit.has('ArrowDown') || a.hit.has('s')) move(0, -1);
        if (a.hit.has('ArrowLeft') || a.hit.has('a')) move(-1, 0); if (a.hit.has('ArrowRight') || a.hit.has('d')) move(1, 0);
        if (a.ptr.down) { const dx = a.ptr.x - a.ptr.sx, dy = a.ptr.y - a.ptr.sy; if (Math.hypot(dx, dy) > 24) { if (Math.abs(dx) > Math.abs(dy)) move(Math.sign(dx), 0); else move(0, -Math.sign(dy)); a.ptr.sx = a.ptr.x; a.ptr.sy = a.ptr.y; } }
        const row = rows[py];
        if (row.kind === 'road') { for (let i = 0; i < row.n; i++) { const x = posOf(row, i); if (px > x + 16 && px < x + 64) { die(); break; } } }
        else if (row.kind === 'river') {
          let on = false;
          for (let i = 0; i < row.n; i++) { const x = posOf(row, i); if (px > x + 20 && px < x + 20 + row.w) { on = true; break; } }
          if (!on) die(); else { px += row.v * dt; carry = row.v; if (px < 5 || px > 355) die(); }
        } else carry = 0;
        if (py === ROWS - 1) { score += 100 + Math.round(time); a.sfx('win'); px = 180; py = 0; maxRow = 0; }
        if (time <= 0) a.finish(score, Math.round(score / 5));
      },
      draw(c) {
        for (let r = 0; r < ROWS; r++) {
          const y = OY + (ROWS - 1 - r) * CS, row = rows[r];
          c.fillStyle = row.kind === 'river' ? '#6cc4f5' : row.kind === 'road' ? '#c8d6e4' : r === 9 ? '#c8f0d0' : '#fff';
          c.fillRect(0, y, a.W, CS);
          if (row.kind === 'river') { c.strokeStyle = '#ffffff66'; c.lineWidth = 2; c.beginPath(); for (let x = 0; x < a.W; x += 30) { c.moveTo(x + (t * 10) % 30, y + 12); c.quadraticCurveTo(x + 8, y + 6, x + 16, y + 12); } c.stroke(); }
          for (let i = 0; i < row.n; i++) {
            const x = posOf(row, i) + 20;
            if (row.kind === 'river') { c.fillStyle = '#f2fcff'; c.strokeStyle = '#9ad4f0'; c.lineWidth = 3; rr(c, x, y + 4, row.w, CS - 8, 12); c.fill(); c.stroke(); }
            else if (row.kind === 'road') emo(c, row.e, x + 20, y + 21, 30);
          }
        }
        emo(c, '🏁', 180, OY + 20, 30);
        if (dead <= 0 || Math.floor(t * 14) % 2) drawPeng(c, spr, px, OY + (ROWS - 1 - py) * CS + 18, 36, carry ? Math.sin(t * 8) * 0.1 : 0);
        c.fillStyle = '#9fd8ff'; c.fillRect(0, 0, a.W, OY);
        txt(c, `점수 ${score}`, 12, 20, 20, '#fff'); txt(c, '❤'.repeat(Math.max(0, lives)), a.W - 12, 20, 20, '#ff6f9e', 'right'); txt(c, `${Math.max(0, Math.ceil(time))}s`, a.W / 2, 20, 18, '#fff', 'center');
      },
    };
  }} />
);

// ───────── 10. 구름 점프 ─────────
export const Doodle = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={540} onFinish={onFinish} pad="lr" make={(a) => {
    const spr = mySprite();
    interface Pl { x: number; y: number; k: 'n' | 'm' | 'b' | 's'; d: number; gone: boolean }
    const pls: Pl[] = [{ x: 150, y: 500, k: 'n', d: 1, gone: false }];
    let top = 500;
    const gen = () => { const gap = Math.min(112, 60 + (500 - top) / 60); top -= rand(gap * 0.7, gap); const r = Math.random(); pls.push({ x: rand(0, 290), y: top, k: r < 0.12 ? 's' : r < 0.3 ? 'm' : r < 0.42 ? 'b' : 'n', d: Math.random() < 0.5 ? 1 : -1, gone: false }); };
    while (top > -200) gen();
    let x = 180, y = 470, vy = -620, cam = 0, best = 0, t = 0;
    return {
      update(dt) {
        t += dt;
        let dx = 0;
        if (a.keys.has('ArrowLeft') || a.keys.has('a')) dx = -1; else if (a.keys.has('ArrowRight') || a.keys.has('d')) dx = 1;
        if (dx) x += dx * 280 * dt; else if (a.ptr.moved && a.ptr.down) x += clamp(a.ptr.x - x, -300 * dt, 300 * dt);
        if (x < -10) x = a.W + 10; if (x > a.W + 10) x = -10;
        const oy = y; vy += 1500 * dt; y += vy * dt;
        pls.forEach((p) => {
          if (p.k === 'm') { p.x += p.d * 70 * dt; if (p.x < 0 || p.x > 290) p.d *= -1; }
          if (vy > 0 && !p.gone && oy + 24 <= p.y + 4 && y + 24 >= p.y && Math.abs(x - (p.x + 35)) < 48) {
            if (p.k === 'b') { p.gone = true; a.sfx('hit'); } else { vy = p.k === 's' ? -950 : -620; a.sfx('jump'); }
          }
        });
        if (y < cam + 220) cam = y - 220;
        best = Math.max(best, Math.round((500 - y) / 8));
        while (top > cam - 300) gen();
        while (pls.length && pls[0].y > cam + a.H + 50) pls.shift();
        if (y > cam + a.H + 40) a.finish(best, Math.min(300, Math.round(best / 3)));
      },
      draw(c) {
        bgGrad(c, a.W, a.H, '#8fd0ff', '#fde8f4');
        for (let i = 0; i < 6; i++) { c.fillStyle = '#ffffff55'; c.beginPath(); c.ellipse((i * 77 + t * 6) % 400, (i * 120 - cam * 0.2) % 560, 50, 16, 0, 0, 7); c.fill(); }
        c.save(); c.translate(0, -cam);
        pls.forEach((p) => {
          if (p.gone) return;
          c.fillStyle = p.k === 'b' ? '#e0d0c0' : p.k === 'm' ? '#ffd0e8' : '#fff'; c.strokeStyle = p.k === 'b' ? '#b09078' : '#9ad0f0'; c.lineWidth = 3;
          rr(c, p.x, p.y, 70, 16, 8); c.fill(); c.stroke();
          c.beginPath(); c.arc(p.x + 18, p.y, 10, 0, 7); c.arc(p.x + 40, p.y - 4, 12, 0, 7); c.fill(); if (p.k === 's') emo(c, '🍄', p.x + 35, p.y - 14, 24);
        });
        drawPeng(c, spr, x, y, 48, clamp(vy / 2500, -0.2, 0.2));
        c.restore();
        txt(c, `${best} m`, 12, 24, 22, '#fff');
      },
    };
  }} />
);

// ───────── 11. 썰매 레이스 ─────────
export const Sled = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={540} onFinish={onFinish} pad="lr" make={(a) => {
    const spr = mySprite();
    const HZ = 150, PY = 440;
    const objs: { l: number; p: number; k: string }[] = [];
    let lane = 1, px = 180, lives = 3, t = 0, spawn = 0, dist = 0, fish = 0, inv = 0, time = 45;
    const lx = (l: number, p: number) => 180 + (l - 1) * (40 + 100 * p);
    const sy = (p: number) => HZ + (PY + 40 - HZ) * Math.pow(p, 1.5);
    return {
      update(dt) {
        t += dt; time -= dt; inv = Math.max(0, inv - dt);
        if (a.hit.has('ArrowLeft') || a.hit.has('a')) lane = Math.max(0, lane - 1); if (a.hit.has('ArrowRight') || a.hit.has('d')) lane = Math.min(2, lane + 1);
        if (a.ptr.pressed) { if (a.ptr.x < 120) lane = Math.max(0, lane - 1); else if (a.ptr.x > 240) lane = Math.min(2, lane + 1); }
        px += (lx(lane, 0.85) - px) * Math.min(1, dt * 14);
        const sp = 0.42 + t * 0.008; dist += sp * dt * 60;
        spawn -= dt;
        if (spawn <= 0) { spawn = Math.max(0.3, 0.8 - t * 0.01); const r = Math.random(); objs.push({ l: Math.floor(rand(0, 3)), p: 0.02, k: r < 0.45 ? '🌲' : r < 0.65 ? '🪨' : r < 0.9 ? '🐟' : '⛄' }); }
        for (let i = objs.length - 1; i >= 0; i--) {
          const o = objs[i]; o.p += (sp * dt) * (0.6 + o.p * 1.4);
          if (o.p > 0.84 && o.p < 0.98 && o.l === lane) {
            if (o.k === '🐟') { fish++; a.sfx('coin'); objs.splice(i, 1); continue; }
            if (inv <= 0) { lives--; inv = 1.3; a.sfx('hit'); } objs.splice(i, 1); continue;
          }
          if (o.p > 1.15) objs.splice(i, 1);
        }
        if (lives <= 0 || time <= 0) { const s = fish * 20 + Math.round(dist / 4); a.finish(s, Math.min(300, Math.round(s / 5))); lives = 9; time = 99; }
      },
      draw(c) {
        bgGrad(c, a.W, a.H, '#aee0ff', '#f4fbff');
        c.fillStyle = '#d6efff'; c.beginPath(); c.moveTo(0, HZ); c.lineTo(70, HZ - 50); c.lineTo(130, HZ); c.lineTo(210, HZ - 70); c.lineTo(280, HZ); c.lineTo(330, HZ - 40); c.lineTo(360, HZ); c.fill();
        c.fillStyle = '#fff'; c.beginPath(); c.moveTo(165, HZ); c.lineTo(195, HZ); c.lineTo(a.W + 60, a.H); c.lineTo(-60, a.H); c.fill();
        c.strokeStyle = '#bfe2f5'; c.lineWidth = 3;
        for (let l = -0.5; l <= 2.5; l += 1) { c.beginPath(); c.moveTo(lx(l + 0.0, 0) , HZ); c.lineTo(lx(l, 1.1), a.H); c.stroke(); }
        for (let i = 0; i < 8; i++) { const p = ((i / 8 + t * 0.4 * (0.42 + t * 0.008)) % 1); c.strokeStyle = '#d6ecf8'; c.beginPath(); c.moveTo(-20, sy(p)); c.lineTo(a.W + 20, sy(p)); c.stroke(); }
        objs.slice().sort((x, y) => x.p - y.p).forEach((o) => emo(c, o.k, lx(o.l, o.p), sy(o.p) - 10 * o.p, 20 + 70 * o.p));
        if (inv <= 0 || Math.floor(t * 14) % 2) { emo(c, '🛷', px, PY + 22, 70); drawPeng(c, spr, px, PY - 10, 54, Math.sin(t * 5) * 0.06); }
        txt(c, `🐟 ${fish}`, 12, 24, 20, '#4a8ad8'); txt(c, '❤'.repeat(Math.max(0, lives)), a.W - 12, 24, 20, '#ff6f9e', 'right'); txt(c, `${Math.max(0, Math.ceil(time))}s`, a.W / 2, 24, 18, '#4a8ad8', 'center');
      },
    };
  }} />
);

// ───────── 12. 에어하키 ─────────
export const Hockey = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={540} onFinish={onFinish} pad="none" make={(a) => {
    const spr = mySprite();
    const MR = 28, PR = 14, GW = 120;
    const me = { x: 180, y: 470, vx: 0, vy: 0 }, ai = { x: 180, y: 70, vx: 0, vy: 0 };
    const puck = { x: 180, y: 270, vx: 0, vy: 0 };
    let sc = [0, 0], t = 0, wait = 1;
    const serve = (d: number) => { puck.x = 180; puck.y = 270; puck.vx = 0; puck.vy = 0; wait = 1; void d; };
    const hitM = (m: typeof me) => {
      const dx = puck.x - m.x, dy = puck.y - m.y, d = Math.hypot(dx, dy);
      if (d < MR + PR) {
        const nx = dx / (d || 1), ny = dy / (d || 1);
        puck.x = m.x + nx * (MR + PR); puck.y = m.y + ny * (MR + PR);
        const rel = (puck.vx - m.vx) * nx + (puck.vy - m.vy) * ny;
        if (rel < 0) { puck.vx -= 1.9 * rel * nx; puck.vy -= 1.9 * rel * ny; a.sfx('click'); }
        const sp = Math.hypot(puck.vx, puck.vy); if (sp > 700) { puck.vx *= 700 / sp; puck.vy *= 700 / sp; }
      }
    };
    return {
      update(dt) {
        t += dt;
        const ox = me.x, oy = me.y;
        if (a.ptr.moved) { me.x += clamp(a.ptr.x - me.x, -900 * dt, 900 * dt); me.y += clamp(a.ptr.y - 20 - me.y, -900 * dt, 900 * dt); }
        if (a.keys.has('ArrowLeft')) me.x -= 400 * dt; if (a.keys.has('ArrowRight')) me.x += 400 * dt; if (a.keys.has('ArrowUp')) me.y -= 400 * dt; if (a.keys.has('ArrowDown')) me.y += 400 * dt;
        me.x = clamp(me.x, MR, a.W - MR); me.y = clamp(me.y, a.H / 2 + MR, a.H - MR);
        me.vx = (me.x - ox) / dt; me.vy = (me.y - oy) / dt;
        const ax = ai.x, ay = ai.y;
        const spd = 230 + sc[0] * 12;
        let tx = 180, ty = 70;
        if (puck.y < a.H / 2 + 20) { tx = puck.x; ty = puck.vy < 0 || puck.y < 200 ? Math.min(puck.y - 30, 150) : 80; }
        ai.x += clamp(tx - ai.x, -spd * dt, spd * dt); ai.y += clamp(ty - ai.y, -spd * dt, spd * dt);
        ai.x = clamp(ai.x, MR, a.W - MR); ai.y = clamp(ai.y, MR, a.H / 2 - MR);
        ai.vx = (ai.x - ax) / dt; ai.vy = (ai.y - ay) / dt;
        if (wait > 0) { wait -= dt; return; }
        for (let s = 0; s < 3; s++) {
          const d = dt / 3;
          puck.x += puck.vx * d; puck.y += puck.vy * d;
          if (puck.x < PR) { puck.x = PR; puck.vx = Math.abs(puck.vx); } if (puck.x > a.W - PR) { puck.x = a.W - PR; puck.vx = -Math.abs(puck.vx); }
          const inGoal = Math.abs(puck.x - 180) < GW / 2;
          if (puck.y < PR && !inGoal) { puck.y = PR; puck.vy = Math.abs(puck.vy); }
          if (puck.y > a.H - PR && !inGoal) { puck.y = a.H - PR; puck.vy = -Math.abs(puck.vy); }
          hitM(me); hitM(ai);
        }
        puck.vx *= 1 - 0.25 * dt; puck.vy *= 1 - 0.25 * dt;
        if (puck.y < -PR) { sc[0]++; a.sfx('win'); serve(1); }
        if (puck.y > a.H + PR) { sc[1]++; a.sfx('lose'); serve(0); }
        if (sc[0] >= 5 || sc[1] >= 5) a.finish(sc[0], 20 + sc[0] * 30 + (sc[0] > sc[1] ? 60 : 0));
      },
      draw(c) {
        bgGrad(c, a.W, a.H, '#e4f6ff', '#cfeaff');
        c.strokeStyle = '#8fd0f5'; c.lineWidth = 4; c.beginPath(); c.moveTo(0, a.H / 2); c.lineTo(a.W, a.H / 2); c.stroke(); c.beginPath(); c.arc(180, a.H / 2, 50, 0, 7); c.stroke();
        c.strokeStyle = '#ff9ec8'; c.lineWidth = 8; c.beginPath(); c.moveTo(180 - GW / 2, 2); c.lineTo(180 + GW / 2, 2); c.moveTo(180 - GW / 2, a.H - 2); c.lineTo(180 + GW / 2, a.H - 2); c.stroke();
        c.strokeStyle = '#9fd8ff'; c.lineWidth = 6; c.strokeRect(0, 0, a.W, a.H);
        const g = c.createRadialGradient(puck.x - 3, puck.y - 3, 2, puck.x, puck.y, PR); g.addColorStop(0, '#fff'); g.addColorStop(1, '#ff7aa8'); c.fillStyle = g; c.beginPath(); c.arc(puck.x, puck.y, PR, 0, 7); c.fill();
        [[me, '#7fc8ff'], [ai, '#ffb070']].forEach(([m, col]) => { const mm = m as typeof me; c.fillStyle = col as string; c.strokeStyle = '#fff'; c.lineWidth = 4; c.beginPath(); c.arc(mm.x, mm.y, MR, 0, 7); c.fill(); c.stroke(); });
        drawPeng(c, spr, me.x, me.y - 2, 40); emo(c, '🐻‍❄️', ai.x, ai.y, 36);
        txt(c, `${sc[1]}`, 20, a.H / 2 - 24, 30, '#ffb070'); txt(c, `${sc[0]}`, 20, a.H / 2 + 24, 30, '#4a98d8');
        if (wait > 0 && t < 3) txt(c, '먼저 5골!', a.W / 2, a.H / 2 + 80, 24, '#fff', 'center');
      },
    };
  }} />
);

// ───────── 13. 눈공 플링코 ─────────
export const Plinko = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={540} onFinish={onFinish} pad="none" make={(a) => {
    const pegs: { x: number; y: number }[] = [];
    for (let r = 0; r < 9; r++) { const n = r % 2 ? 7 : 8; const off = r % 2 ? 22 + 24 : 22; for (let i = 0; i < n; i++) pegs.push({ x: off + i * 46 - (r % 2 ? 0 : 0) + (r % 2 ? 0 : 0), y: 130 + r * 38 }); }
    const VALS = [100, 40, 15, 5, 15, 40, 100];
    const balls: { x: number; y: number; vx: number; vy: number; done: boolean }[] = [];
    let left = 6, score = 0, aim = 180, t = 0, end = 0, pop = { s: '', t: 0, x: 0 };
    const binW = a.W / 7;
    return {
      update(dt) {
        t += dt; pop.t -= dt;
        if (a.ptr.moved) aim = clamp(a.ptr.x, 20, 340);
        if (a.keys.has('ArrowLeft')) aim = clamp(aim - 200 * dt, 20, 340); if (a.keys.has('ArrowRight')) aim = clamp(aim + 200 * dt, 20, 340);
        if ((a.ptr.pressed || a.hit.has(' ')) && left > 0 && balls.filter((b) => !b.done).length < 3) { balls.push({ x: aim + rand(-2, 2), y: 70, vx: rand(-10, 10), vy: 0, done: false }); left--; a.sfx('pop'); }
        balls.forEach((b) => {
          if (b.done) return;
          for (let s = 0; s < 3; s++) {
            const d = dt / 3; b.vy += 800 * d; b.x += b.vx * d; b.y += b.vy * d;
            if (b.x < 12) { b.x = 12; b.vx = Math.abs(b.vx) * 0.6; } if (b.x > a.W - 12) { b.x = a.W - 12; b.vx = -Math.abs(b.vx) * 0.6; }
            for (const p of pegs) {
              const dx = b.x - p.x, dy = b.y - p.y, dd = Math.hypot(dx, dy);
              if (dd < 17) { const nx = dx / dd, ny = dy / dd; b.x = p.x + nx * 17; b.y = p.y + ny * 17; const dot = b.vx * nx + b.vy * ny; if (dot < 0) { b.vx = (b.vx - 1.55 * dot * nx) * 0.9 + rand(-14, 14); b.vy = (b.vy - 1.55 * dot * ny) * 0.9; a.sfx('tick'); } }
            }
          }
          if (b.y > a.H - 46) { b.done = true; const i = clamp(Math.floor(b.x / binW), 0, 6); score += VALS[i]; pop = { s: `+${VALS[i]}`, t: 1, x: i * binW + binW / 2 }; a.sfx(VALS[i] >= 40 ? 'win' : 'coin'); }
        });
        if (left === 0 && balls.every((b) => b.done)) { end += dt; if (end > 1) a.finish(score, Math.min(300, Math.round(score * 0.9))); }
      },
      draw(c) {
        bgGrad(c, a.W, a.H, '#ffeaf4', '#d8ecff');
        c.fillStyle = '#fff'; rr(c, 0, 0, a.W, 100, 0); c.fill();
        emo(c, '🐧', aim, 52, 40); c.strokeStyle = '#ff9ec8aa'; c.setLineDash([6, 8]); c.beginPath(); c.moveTo(aim, 76); c.lineTo(aim, 120); c.stroke(); c.setLineDash([]);
        pegs.forEach((p) => { c.fillStyle = '#8fd0f5'; c.strokeStyle = '#fff'; c.lineWidth = 2; c.beginPath(); c.arc(p.x, p.y, 7, 0, 7); c.fill(); c.stroke(); });
        VALS.forEach((v, i) => { c.fillStyle = v >= 100 ? '#ffd25a' : v >= 40 ? '#ff9ec8' : v >= 15 ? '#9fd8ff' : '#e0e8f0'; rr(c, i * binW + 2, a.H - 44, binW - 4, 40, 10); c.fill(); txt(c, String(v), i * binW + binW / 2, a.H - 24, 15, '#fff', 'center'); });
        balls.forEach((b) => { if (b.done) return; const g = c.createRadialGradient(b.x - 3, b.y - 3, 1, b.x, b.y, 11); g.addColorStop(0, '#fff'); g.addColorStop(1, '#a8d8f5'); c.fillStyle = g; c.strokeStyle = '#6ab0e0'; c.lineWidth = 2; c.beginPath(); c.arc(b.x, b.y, 11, 0, 7); c.fill(); c.stroke(); });
        txt(c, `점수 ${score}`, 12, 24, 20, '#ff6fa5'); txt(c, `남은 공 ⚪ ${left}`, a.W - 12, 24, 18, '#4a8ad8', 'right');
        if (pop.t > 0) txt(c, pop.s, pop.x, a.H - 70 - (1 - pop.t) * 30, 26, '#ffe86a', 'center');
        if (t < 3) txt(c, '위치를 정하고 탭해서 눈공을 떨어뜨려요!', a.W / 2, 110, 15, '#ff6fa5', 'center');
      },
    };
  }} />
);

// ───────── 14. 미로 탈출 ─────────
export const Maze = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={400} onFinish={onFinish} pad="dir" make={(a) => {
    const spr = mySprite();
    const N = 12, CS = 30, OY = 40;
    const walls = Array.from({ length: N * N }, () => [true, true, true, true]); // 상 우 하 좌
    const vis = new Array(N * N).fill(false);
    const stack = [0]; vis[0] = true;
    const DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0];
    while (stack.length) {
      const cur = stack[stack.length - 1]; const cx = cur % N, cy = Math.floor(cur / N);
      const nb = shuffle([0, 1, 2, 3]).filter((d) => { const nx = cx + DX[d], ny = cy + DY[d]; return nx >= 0 && ny >= 0 && nx < N && ny < N && !vis[ny * N + nx]; });
      if (!nb.length) { stack.pop(); continue; }
      const d = nb[0], n = (cy + DY[d]) * N + cx + DX[d];
      walls[cur][d] = false; walls[n][(d + 2) % 4] = false; vis[n] = true; stack.push(n);
    }
    // 일부 벽 제거로 길 다양화
    for (let i = 0; i < 14; i++) { const x = Math.floor(rand(0, N - 1)), y = Math.floor(rand(0, N)); walls[y * N + x][1] = false; walls[y * N + x + 1][3] = false; }
    let px = 0, py = 0, time = 80, fish = new Set<number>(), t = 0, rep = 0, done = false;
    const fl = shuffle(Array.from({ length: N * N - 2 }, (_, i) => i + 1)).slice(0, 6);
    fl.forEach((f) => fish.add(f));
    const tryMove = (d: number) => {
      if (walls[py * N + px][d]) return;
      px += DX[d]; py += DY[d]; a.sfx('tick');
      if (fish.has(py * N + px)) { fish.delete(py * N + px); a.sfx('coin'); }
      if (px === N - 1 && py === N - 1 && !done) { done = true; a.sfx('win'); const s = (6 - fish.size) * 50 + Math.round(time * 3) + 200; a.finish(s, Math.min(300, Math.round(s / 3))); }
    };
    return {
      update(dt) {
        t += dt; time -= dt; rep -= dt;
        const dirs: [string[], number][] = [[['ArrowUp', 'w'], 0], [[ 'ArrowRight', 'd'], 1], [['ArrowDown', 's'], 2], [['ArrowLeft', 'a'], 3]];
        for (const [ks, d] of dirs) { if (ks.some((k) => a.hit.has(k))) { tryMove(d); rep = 0.2; } else if (rep <= 0 && ks.some((k) => a.keys.has(k))) { tryMove(d); rep = 0.11; } }
        if (a.ptr.down) { const dx = a.ptr.x - a.ptr.sx, dy = a.ptr.y - a.ptr.sy; if (Math.hypot(dx, dy) > 20) { tryMove(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : dy > 0 ? 2 : 0); a.ptr.sx = a.ptr.x; a.ptr.sy = a.ptr.y; } }
        if (time <= 0 && !done) { done = true; const s = (6 - fish.size) * 50; a.finish(s, Math.round(s / 4)); }
      },
      draw(c) {
        snowBg(c, a.W, a.H, t, '#e4f6ff', '#f4fbff');
        c.fillStyle = '#c8f0d0aa'; c.fillRect((N - 1) * CS, OY + (N - 1) * CS, CS, CS);
        emo(c, '🏁', (N - 1) * CS + 15, OY + (N - 1) * CS + 16, 22);
        fish.forEach((f) => emo(c, '🐟', (f % N) * CS + 15, OY + Math.floor(f / N) * CS + 16, 18));
        c.strokeStyle = '#4aa8e0'; c.lineWidth = 4; c.lineCap = 'round'; c.beginPath();
        for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
          const w = walls[y * N + x], X = x * CS, Y = OY + y * CS;
          if (w[0]) { c.moveTo(X, Y); c.lineTo(X + CS, Y); } if (w[3]) { c.moveTo(X, Y); c.lineTo(X, Y + CS); }
          if (y === N - 1 && w[2]) { c.moveTo(X, Y + CS); c.lineTo(X + CS, Y + CS); } if (x === N - 1 && w[1]) { c.moveTo(X + CS, Y); c.lineTo(X + CS, Y + CS); }
        }
        c.stroke(); c.lineCap = 'butt';
        drawPeng(c, spr, px * CS + 15, OY + py * CS + 14, 26);
        txt(c, `🐟 ${6 - fish.size}/6`, 12, 20, 18, '#4a8ad8'); txt(c, `${Math.max(0, Math.ceil(time))}초`, a.W - 12, 20, 18, '#ff6fa5', 'right');
      },
    };
  }} />
);
