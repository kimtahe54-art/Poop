import { CanvasGame, GameProps, clamp, drawPeng, emo, mySprite, rand, rr, snowBg, txt, bgGrad } from './engine';
import { pick } from '../data/penguinData';

// ───────── 1. 플래피 펭귄 ─────────
export const Flappy = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={540} onFinish={onFinish} pad="act" make={(a) => {
    const spr = mySprite();
    const G = a.H - 50;
    let y = 250, vy = 0, t = 0, score = 0, started = false, dead = false, deadT = 0;
    const pipes: { x: number; gy: number; ok: boolean }[] = [];
    for (let i = 0; i < 4; i++) pipes.push({ x: 420 + i * 190, gy: rand(170, G - 170), ok: false });
    return {
      update(dt) {
        t += dt;
        const flap = a.ptr.pressed || a.hit.has(' ') || a.hit.has('ArrowUp');
        if (dead) { deadT += dt; vy += 1200 * dt; y = Math.min(G - 20, y + vy * dt); if (deadT > 1) a.finish(score, score * 9); return; }
        if (flap) { started = true; vy = -310; a.sfx('flap'); }
        if (!started) { y = 250 + Math.sin(t * 4) * 8; return; }
        vy += 950 * dt; y += vy * dt;
        pipes.forEach((p) => {
          p.x -= (140 + score * 2) * dt;
          if (!p.ok && p.x + 30 < 90) { p.ok = true; score++; a.sfx('coin'); }
          if (p.x < -70) { p.x += 4 * 190; p.gy = rand(170, G - 170); p.ok = false; }
          if (Math.abs(p.x - 90) < 44 && (y - 16 < p.gy - 75 || y + 18 > p.gy + 75)) { dead = true; vy = -150; a.sfx('hit'); }
        });
        if (y > G - 20 || y < -20) { dead = true; vy = -100; a.sfx('hit'); }
      },
      draw(c) {
        snowBg(c, a.W, a.H, t);
        pipes.forEach((p) => {
          const g = c.createLinearGradient(p.x - 30, 0, p.x + 30, 0);
          g.addColorStop(0, '#8fdcff'); g.addColorStop(0.5, '#e6fbff'); g.addColorStop(1, '#6cc4f0');
          c.fillStyle = g; c.strokeStyle = '#4aa8e0'; c.lineWidth = 3;
          rr(c, p.x - 28, -10, 56, p.gy - 75 + 10, 8); c.fill(); c.stroke();
          rr(c, p.x - 28, p.gy + 75, 56, G - p.gy - 75, 8); c.fill(); c.stroke();
          rr(c, p.x - 34, p.gy - 75 - 22, 68, 22, 8); c.fill(); c.stroke();
          rr(c, p.x - 34, p.gy + 75, 68, 22, 8); c.fill(); c.stroke();
        });
        c.fillStyle = '#fff'; c.fillRect(0, G, a.W, a.H - G); c.fillStyle = '#cfe9f8'; c.fillRect(0, G, a.W, 6);
        drawPeng(c, spr, 90, y, 50, clamp(vy / 600, -0.5, 0.9));
        txt(c, String(score), a.W / 2, 50, 44, '#fff', 'center');
        if (!started) txt(c, '탭하면 날아올라요!', a.W / 2, 330, 22, '#fff', 'center');
      },
    };
  }} />
);

// ───────── 2. 눈덩이 피하기 ─────────
export const Dodge = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={540} onFinish={onFinish} pad="lr" make={(a) => {
    const spr = mySprite();
    let px = 180, t = 0, lives = 3, score = 0, inv = 0, spawn = 0;
    const items: { x: number; y: number; vy: number; k: string; r: number; rot: number }[] = [];
    const LIMIT = 50;
    return {
      update(dt) {
        t += dt; inv = Math.max(0, inv - dt);
        if (a.keys.has('ArrowLeft') || a.keys.has('a')) px -= 340 * dt;
        else if (a.keys.has('ArrowRight') || a.keys.has('d')) px += 340 * dt;
        else if (a.ptr.moved) px += (a.ptr.x - px) * Math.min(1, dt * 14);
        px = clamp(px, 25, a.W - 25);
        spawn -= dt;
        if (spawn <= 0) {
          spawn = Math.max(0.16, 0.6 - t * 0.008);
          const r = Math.random();
          const k = r < 0.62 ? 'snow' : r < 0.9 ? 'fish' : r < 0.96 ? 'heart' : 'star';
          items.push({ x: rand(20, a.W - 20), y: -30, vy: rand(150, 230) + t * 3, k, r: k === 'snow' ? rand(12, 22) : 14, rot: 0 });
        }
        for (let i = items.length - 1; i >= 0; i--) {
          const it = items[i];
          it.y += it.vy * dt; it.rot += dt * 3;
          if (Math.abs(it.x - px) < it.r + 16 && Math.abs(it.y - (a.H - 70)) < it.r + 22) {
            if (it.k === 'snow') { if (inv <= 0) { lives--; inv = 1.4; a.sfx('hit'); } }
            else { a.sfx('coin'); if (it.k === 'fish') score += 10; else if (it.k === 'star') score += 50; else lives = Math.min(5, lives + 1); }
            items.splice(i, 1);
          } else if (it.y > a.H + 40) { items.splice(i, 1); }
        }
        if (it0(lives) || t > LIMIT) { score += Math.round(t); a.finish(score, Math.round(score / 4)); }
      },
      draw(c) {
        snowBg(c, a.W, a.H, t, '#9fd8ff', '#e6f6ff');
        c.fillStyle = '#fff'; c.fillRect(0, a.H - 40, a.W, 40);
        items.forEach((it) => {
          if (it.k === 'snow') {
            const g = c.createRadialGradient(it.x - it.r * 0.3, it.y - it.r * 0.3, 2, it.x, it.y, it.r);
            g.addColorStop(0, '#fff'); g.addColorStop(1, '#bfe2f5'); c.fillStyle = g; c.strokeStyle = '#8fc4e0'; c.lineWidth = 2;
            c.beginPath(); c.arc(it.x, it.y, it.r, 0, 7); c.fill(); c.stroke();
          } else emo(c, it.k === 'fish' ? '🐟' : it.k === 'heart' ? '💖' : '⭐', it.x, it.y, 28, Math.sin(it.rot) * 0.4);
        });
        if (inv <= 0 || Math.floor(t * 12) % 2) drawPeng(c, spr, px, a.H - 70, 52);
        txt(c, `점수 ${score}`, 12, 24, 20, '#fff');
        txt(c, '❤'.repeat(lives), a.W - 12, 24, 20, '#ff6f9e', 'right');
        txt(c, `${Math.max(0, Math.ceil(LIMIT - t))}초`, a.W / 2, 24, 20, '#fff', 'center');
      },
    };
  }} />
);
const it0 = (n: number) => n <= 0;

// ───────── 3. 벽돌깨기 ─────────
export const Breakout = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={540} onFinish={onFinish} pad="lract" make={(a) => {
    const spr = mySprite();
    const cols = ['#ff8fa8', '#ffb86a', '#ffe36a', '#8fe0a0', '#7fc8ff', '#c0a0ff'];
    const bricks: { x: number; y: number; alive: boolean; c: string }[] = [];
    for (let r = 0; r < 6; r++) for (let q = 0; q < 8; q++) bricks.push({ x: 20 + q * 40, y: 70 + r * 22, alive: true, c: cols[r] });
    let px = 180, lives = 3, score = 0, broken = 0, t = 0;
    const ball = { x: 180, y: 480, vx: 0, vy: 0, on: true };
    const PW = 76, PY = a.H - 50;
    return {
      update(dt) {
        t += dt;
        if (a.keys.has('ArrowLeft')) px -= 380 * dt; else if (a.keys.has('ArrowRight')) px += 380 * dt; else if (a.ptr.moved) px += (a.ptr.x - px) * Math.min(1, dt * 16);
        px = clamp(px, PW / 2, a.W - PW / 2);
        if (ball.on) {
          ball.x = px; ball.y = PY - 12;
          if (a.ptr.pressed || a.hit.has(' ')) { ball.on = false; const sp = 320; ball.vx = rand(-90, 90); ball.vy = -Math.sqrt(sp * sp - ball.vx * ball.vx); }
          return;
        }
        for (let s = 0; s < 3; s++) {
          const d = dt / 3, sp = 1 + broken * 0.006;
          ball.x += ball.vx * d * sp; ball.y += ball.vy * d * sp;
          if (ball.x < 8) { ball.x = 8; ball.vx = Math.abs(ball.vx); } if (ball.x > a.W - 8) { ball.x = a.W - 8; ball.vx = -Math.abs(ball.vx); }
          if (ball.y < 8) { ball.y = 8; ball.vy = Math.abs(ball.vy); }
          if (ball.vy > 0 && ball.y > PY - 14 && ball.y < PY + 6 && Math.abs(ball.x - px) < PW / 2 + 6) {
            const k = (ball.x - px) / (PW / 2); const spd = Math.hypot(ball.vx, ball.vy);
            ball.vx = k * spd * 0.75; ball.vy = -Math.sqrt(Math.max(1, spd * spd - ball.vx * ball.vx)); a.sfx('click');
          }
          for (const b of bricks) {
            if (!b.alive) continue;
            const cx = clamp(ball.x, b.x, b.x + 38), cy = clamp(ball.y, b.y, b.y + 18);
            if ((ball.x - cx) ** 2 + (ball.y - cy) ** 2 < 49) {
              b.alive = false; broken++; score += 10; a.sfx('pop');
              if (Math.abs(ball.x - (b.x + 19)) / 19 > Math.abs(ball.y - (b.y + 9)) / 9) ball.vx *= -1; else ball.vy *= -1;
              break;
            }
          }
        }
        if (ball.y > a.H + 10) { lives--; a.sfx('hit'); ball.on = true; if (lives <= 0) a.finish(score, Math.round(score / 3)); }
        if (broken === bricks.length) { score += 300; a.sfx('win'); a.finish(score, Math.round(score / 3)); }
      },
      draw(c) {
        bgGrad(c, a.W, a.H, '#ffeaf4', '#e4f2ff');
        bricks.forEach((b) => { if (!b.alive) return; c.fillStyle = b.c; c.strokeStyle = '#fff'; c.lineWidth = 2; rr(c, b.x, b.y, 38, 18, 6); c.fill(); c.stroke(); c.fillStyle = '#fff6'; rr(c, b.x + 4, b.y + 3, 30, 4, 2); c.fill(); });
        c.fillStyle = '#8fd8ff'; c.strokeStyle = '#fff'; c.lineWidth = 3; rr(c, px - PW / 2, PY, PW, 14, 7); c.fill(); c.stroke();
        drawPeng(c, spr, px, PY - 10, 34);
        const g = c.createRadialGradient(ball.x - 2, ball.y - 2, 1, ball.x, ball.y, 8); g.addColorStop(0, '#fff'); g.addColorStop(1, '#ff8fb8');
        c.fillStyle = g; c.beginPath(); c.arc(ball.x, ball.y, 8, 0, 7); c.fill();
        txt(c, `점수 ${score}`, 12, 24, 20, '#ff6fa5'); txt(c, '❤'.repeat(lives), a.W - 12, 24, 20, '#ff6f9e', 'right');
        if (ball.on) txt(c, '탭 / 스페이스로 발사!', a.W / 2, 300, 20, '#fff', 'center');
      },
    };
  }} />
);

// ───────── 4. 물고기 뱀 ─────────
export const Snake = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={400} onFinish={onFinish} pad="dir" make={(a) => {
    const N = 18, CS = 20, OY = 40;
    let body = [{ x: 9, y: 9 }, { x: 8, y: 9 }, { x: 7, y: 9 }];
    let dir = { x: 1, y: 0 }, queued = { x: 1, y: 0 }, acc = 0, eaten = 0, t = 0, dead = false, deadT = 0;
    let food = { x: 14, y: 9 }, star: { x: number; y: number; ttl: number } | null = null;
    const place = () => { for (;;) { const p = { x: Math.floor(rand(0, N)), y: Math.floor(rand(0, N)) }; if (!body.some((b) => b.x === p.x && b.y === p.y)) return p; } };
    const setDir = (x: number, y: number) => { if (x !== -dir.x || y !== -dir.y) queued = { x, y }; };
    return {
      update(dt) {
        t += dt;
        if (dead) { deadT += dt; if (deadT > 0.8) a.finish(eaten, eaten * 12); return; }
        if (a.hit.has('ArrowUp') || a.hit.has('w')) setDir(0, -1); if (a.hit.has('ArrowDown') || a.hit.has('s')) setDir(0, 1);
        if (a.hit.has('ArrowLeft') || a.hit.has('a')) setDir(-1, 0); if (a.hit.has('ArrowRight') || a.hit.has('d')) setDir(1, 0);
        if (a.ptr.down) {
          const dx = a.ptr.x - a.ptr.sx, dy = a.ptr.y - a.ptr.sy;
          if (Math.hypot(dx, dy) > 22) { if (Math.abs(dx) > Math.abs(dy)) setDir(Math.sign(dx), 0); else setDir(0, Math.sign(dy)); a.ptr.sx = a.ptr.x; a.ptr.sy = a.ptr.y; }
        }
        if (star) { star.ttl -= dt; if (star.ttl <= 0) star = null; }
        acc += dt;
        const iv = Math.max(0.06, 0.15 - eaten * 0.002);
        if (acc >= iv) {
          acc = 0; dir = queued;
          const h = { x: body[0].x + dir.x, y: body[0].y + dir.y };
          if (h.x < 0 || h.y < 0 || h.x >= N || h.y >= N || body.some((b) => b.x === h.x && b.y === h.y)) { dead = true; a.sfx('hit'); return; }
          body.unshift(h);
          if (h.x === food.x && h.y === food.y) { eaten++; food = place(); a.sfx('pop'); if (eaten % 5 === 0) star = { ...place(), ttl: 7 }; }
          else if (star && h.x === star.x && h.y === star.y) { eaten += 4; star = null; a.sfx('coin'); }
          else body.pop();
        }
      },
      draw(c) {
        bgGrad(c, a.W, a.H, '#d8f2ff', '#eefaff');
        for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { c.fillStyle = (x + y) % 2 ? '#e8f7ff' : '#f6fcff'; c.fillRect(x * CS, OY + y * CS, CS, CS); }
        emo(c, '🐟', food.x * CS + 10, OY + food.y * CS + 11, 18);
        if (star) emo(c, '⭐', star.x * CS + 10, OY + star.y * CS + 11, 18 + Math.sin(t * 8) * 2);
        for (let i = body.length - 1; i >= 1; i--) { c.fillStyle = i % 2 ? '#7fc8ff' : '#a8dcff'; c.strokeStyle = '#4aa0e0'; c.lineWidth = 2; rr(c, body[i].x * CS + 1, OY + body[i].y * CS + 1, CS - 2, CS - 2, 7); c.fill(); c.stroke(); }
        emo(c, '🐧', body[0].x * CS + 10, OY + body[0].y * CS + 11, 22);
        txt(c, `🐟 ${eaten}`, 12, 20, 22, '#fff');
        if (dead) txt(c, '앗!', a.W / 2, a.H / 2, 40, '#ff6f9e', 'center');
      },
    };
  }} />
);

// ───────── 5. 우주 펭귄 슈터 ─────────
export const Shooter = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={540} onFinish={onFinish} pad="lr" make={(a) => {
    const spr = mySprite();
    let px = 180, py = 460, t = 0, lives = 3, score = 0, inv = 0, fire = 0, level = 1, spawn = 1;
    const bullets: { x: number; y: number }[] = [];
    const foes: { x: number; y: number; vy: number; hp: number; e: string; s: number; ph: number }[] = [];
    const drops: { x: number; y: number; k: string }[] = [];
    const stars = Array.from({ length: 40 }, () => ({ x: rand(0, 360), y: rand(0, 540), s: rand(0.5, 2) }));
    const LIMIT = 60;
    return {
      update(dt) {
        t += dt; inv = Math.max(0, inv - dt);
        if (a.keys.has('ArrowLeft')) px -= 300 * dt; if (a.keys.has('ArrowRight')) px += 300 * dt;
        if (a.keys.has('ArrowUp')) py -= 260 * dt; if (a.keys.has('ArrowDown')) py += 260 * dt;
        if (a.ptr.moved && a.ptr.down) { px += (a.ptr.x - px) * Math.min(1, dt * 14); py += (a.ptr.y - 50 - py) * Math.min(1, dt * 14); }
        px = clamp(px, 24, a.W - 24); py = clamp(py, 100, a.H - 40);
        fire -= dt;
        if (fire <= 0) { fire = 0.2; a.sfx('shoot'); bullets.push({ x: px, y: py - 30 }); if (level >= 2) { bullets.push({ x: px - 14, y: py - 20 }); bullets.push({ x: px + 14, y: py - 20 }); } }
        spawn -= dt;
        if (spawn <= 0) {
          spawn = Math.max(0.35, 1.1 - t * 0.012);
          const r = Math.random();
          if (r < 0.65) foes.push({ x: rand(30, 330), y: -30, vy: rand(60, 100) + t, hp: 1, e: '🛸', s: 30, ph: rand(0, 6) });
          else if (r < 0.92) foes.push({ x: rand(30, 330), y: -30, vy: rand(40, 70), hp: 3, e: '👾', s: 38, ph: rand(0, 6) });
          else foes.push({ x: rand(50, 310), y: -40, vy: 35, hp: 9, e: '🐙', s: 56, ph: rand(0, 6) });
        }
        for (let i = bullets.length - 1; i >= 0; i--) { bullets[i].y -= 520 * dt; if (bullets[i].y < -10) bullets.splice(i, 1); }
        for (let i = foes.length - 1; i >= 0; i--) {
          const f = foes[i]; f.y += f.vy * dt; f.x += Math.sin(t * 2 + f.ph) * 40 * dt;
          let dead = false;
          for (let j = bullets.length - 1; j >= 0; j--) if (Math.abs(bullets[j].x - f.x) < f.s * 0.6 && Math.abs(bullets[j].y - f.y) < f.s * 0.6) { bullets.splice(j, 1); f.hp--; if (f.hp <= 0) { dead = true; break; } }
          if (dead) { score += f.s > 50 ? 100 : f.s > 35 ? 40 : 15; a.sfx('pop'); if (Math.random() < 0.18) drops.push({ x: f.x, y: f.y, k: Math.random() < 0.4 ? 'up' : 'gem' }); foes.splice(i, 1); continue; }
          if (inv <= 0 && Math.abs(f.x - px) < f.s * 0.5 + 12 && Math.abs(f.y - py) < f.s * 0.5 + 20) { lives--; inv = 1.5; a.sfx('hit'); foes.splice(i, 1); continue; }
          if (f.y > a.H + 40) foes.splice(i, 1);
        }
        for (let i = drops.length - 1; i >= 0; i--) {
          const d = drops[i]; d.y += 110 * dt;
          if (Math.abs(d.x - px) < 28 && Math.abs(d.y - py) < 36) { a.sfx('coin'); if (d.k === 'up') level = 2; else score += 30; drops.splice(i, 1); } else if (d.y > a.H + 20) drops.splice(i, 1);
        }
        if (lives <= 0 || t > LIMIT) { a.finish(score, Math.round(score / 5)); lives = 99; t = -999; }
      },
      draw(c) {
        bgGrad(c, a.W, a.H, '#1a1450', '#4a2a8a');
        stars.forEach((s) => { c.fillStyle = '#fff'; c.globalAlpha = 0.5 + 0.5 * Math.sin(t * 2 + s.x); c.beginPath(); c.arc(s.x, (s.y + t * 30 * s.s) % a.H, s.s, 0, 7); c.fill(); }); c.globalAlpha = 1;
        foes.forEach((f) => emo(c, f.e, f.x, f.y, f.s));
        drops.forEach((d) => emo(c, d.k === 'up' ? '🔫' : '💎', d.x, d.y, 26));
        c.fillStyle = '#ffe86a'; bullets.forEach((b) => { rr(c, b.x - 3, b.y - 10, 6, 16, 3); c.fill(); });
        if (inv <= 0 || Math.floor(t * 14) % 2) {
          emo(c, '🚀', px, py + 18, 44); drawPeng(c, spr, px, py - 8, 36);
          c.fillStyle = '#ff9a40aa'; c.beginPath(); c.moveTo(px - 8, py + 36); c.lineTo(px, py + 56 + Math.sin(t * 40) * 6); c.lineTo(px + 8, py + 36); c.fill();
        }
        txt(c, `점수 ${score}`, 12, 24, 20, '#fff'); txt(c, '❤'.repeat(Math.max(0, lives)), a.W - 12, 24, 20, '#ff6f9e', 'right');
        txt(c, `${Math.max(0, Math.ceil(LIMIT - t))}s`, a.W / 2, 24, 18, '#ffe86a', 'center');
      },
    };
  }} />
);

// ───────── 6. 타워 쌓기 ─────────
export const Stack = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={540} onFinish={onFinish} pad="act" make={(a) => {
    const spr = mySprite();
    const BH = 26, BASEY = 480;
    const tower = [{ x: 100, w: 160 }];
    let cur = { x: 0, w: 160, dir: 1 }, level = 1, cam = 0, perfect = 0, combo = 0, dead = false, deadT = 0, t = 0;
    const cuts: { x: number; y: number; w: number; vy: number; h: number }[] = [];
    const hue = (n: number) => `hsl(${(n * 22 + 330) % 360} 85% 72%)`;
    return {
      update(dt) {
        t += dt;
        cam += ((Math.max(0, level - 7) * BH) - cam) * Math.min(1, dt * 4);
        cuts.forEach((k) => { k.vy += 800 * dt; k.y += k.vy * dt; });
        if (dead) { deadT += dt; if (deadT > 1.2) a.finish(level - 1, (level - 1) * 10 + perfect * 6); return; }
        cur.x += cur.dir * (120 + level * 7) * dt;
        if (cur.x < 0) { cur.x = 0; cur.dir = 1; } if (cur.x + cur.w > a.W) { cur.x = a.W - cur.w; cur.dir = -1; }
        if (a.ptr.pressed || a.hit.has(' ')) {
          const top = tower[tower.length - 1];
          const l = Math.max(cur.x, top.x), r = Math.min(cur.x + cur.w, top.x + top.w), ov = r - l;
          if (ov <= 0) { dead = true; a.sfx('lose'); cuts.push({ x: cur.x, y: BASEY - level * BH, w: cur.w, vy: 0, h: BH }); return; }
          if (Math.abs(cur.x - top.x) < 5) { cur.x = top.x; cur.w = top.w; perfect++; combo++; a.sfx('coin'); if (combo >= 3) cur.w = Math.min(200, cur.w + 8); }
          else { combo = 0; a.sfx('click'); const cutL = cur.x < top.x; cuts.push({ x: cutL ? cur.x : r, y: BASEY - level * BH, w: cur.w - ov, vy: 0, h: BH }); cur.x = l; cur.w = ov; }
          tower.push({ x: cur.x, w: cur.w }); level++;
          cur = { x: cur.dir > 0 ? 0 : a.W - cur.w, w: cur.w, dir: -cur.dir };
        }
      },
      draw(c) {
        bgGrad(c, a.W, a.H, '#ffd6ec', '#cfeaff');
        c.save(); c.translate(0, cam);
        c.fillStyle = '#fff'; c.fillRect(-10, BASEY + BH, a.W + 20, 400);
        tower.forEach((b, i) => { c.fillStyle = i === 0 ? '#9fd0f0' : hue(i); c.strokeStyle = '#fff'; c.lineWidth = 2.5; rr(c, b.x, BASEY - i * BH, b.w, BH - 2, 8); c.fill(); c.stroke(); c.fillStyle = '#fff6'; rr(c, b.x + 5, BASEY - i * BH + 4, b.w - 10, 5, 3); c.fill(); });
        cuts.forEach((k) => { c.fillStyle = '#ff9ec8'; rr(c, k.x, k.y, k.w, k.h - 2, 8); c.fill(); });
        if (!dead) { c.fillStyle = hue(level); c.strokeStyle = '#fff'; c.lineWidth = 2.5; rr(c, cur.x, BASEY - level * BH, cur.w, BH - 2, 8); c.fill(); c.stroke(); drawPeng(c, spr, cur.x + cur.w / 2, BASEY - level * BH - 22, 40); }
        else { const top = tower[tower.length - 1]; drawPeng(c, spr, top.x + top.w / 2, BASEY - (level - 1) * BH - 22, 40); }
        c.restore();
        txt(c, `${level - 1}층`, a.W / 2, 40, 36, '#fff', 'center');
        if (combo >= 2) txt(c, `PERFECT x${combo}`, a.W / 2, 80, 20, '#ffe86a', 'center');
      },
    };
  }} />
);

// ───────── 7. 리듬 펭귄 ─────────
export const Rhythm = ({ onFinish }: GameProps) => (
  <CanvasGame W={360} H={540} onFinish={onFinish} pad="none" make={(a) => {
    const spr = mySprite();
    const HIT = 450, SP = 270, KEYS = ['d', 'f', 'j', 'k'], COL = ['#ff8fb8', '#ffd25a', '#7fe0a8', '#7fc0ff'];
    const notes: { t: number; l: number; done: boolean; res: string }[] = [];
    let tt = 2, last = -1;
    for (let i = 0; i < 52; i++) { let l = Math.floor(rand(0, 4)); if (l === last && Math.random() < 0.6) l = (l + 1 + Math.floor(rand(0, 3))) % 4; last = l; notes.push({ t: tt, l, done: false, res: '' }); tt += pick([0.5, 0.5, 0.375, 0.75, 0.5]); }
    const END = tt + 1.5;
    let time = 0, score = 0, combo = 0, maxCombo = 0, perf = 0, good = 0, miss = 0;
    const flash = [0, 0, 0, 0];
    let pop = { s: '', t: 0, c: '#fff' };
    const press = (l: number) => {
      flash[l] = 0.2;
      let best: typeof notes[0] | null = null;
      for (const n of notes) if (!n.done && n.l === l && Math.abs(n.t - time) < 0.2 && (!best || Math.abs(n.t - time) < Math.abs(best.t - time))) best = n;
      a.sfx('note' + l);
      if (!best) return;
      best.done = true;
      const d = Math.abs(best.t - time);
      if (d < 0.08) { best.res = 'P'; perf++; score += 300 + combo * 5; pop = { s: 'PERFECT!', t: 0.5, c: '#ffe86a' }; }
      else { best.res = 'G'; good++; score += 150 + combo * 2; pop = { s: 'GOOD', t: 0.5, c: '#8fe0ff' }; }
      combo++; maxCombo = Math.max(maxCombo, combo);
    };
    return {
      update(dt) {
        time += dt; pop.t -= dt; flash.forEach((_, i) => (flash[i] = Math.max(0, flash[i] - dt)));
        KEYS.forEach((k, i) => { if (a.hit.has(k)) press(i); });
        if (a.ptr.pressed && a.ptr.y > 200) press(clamp(Math.floor(a.ptr.x / 90), 0, 3));
        for (const n of notes) if (!n.done && time - n.t > 0.2) { n.done = true; n.res = 'M'; miss++; combo = 0; pop = { s: 'MISS', t: 0.5, c: '#ff8a8a' }; }
        if (time > END) a.finish(score, Math.min(300, Math.round(score / 55)));
      },
      draw(c) {
        bgGrad(c, a.W, a.H, '#2a1a5a', '#6a3aa8');
        for (let i = 0; i < 4; i++) {
          c.fillStyle = i % 2 ? '#ffffff12' : '#ffffff0a'; c.fillRect(i * 90, 0, 90, a.H);
          if (flash[i] > 0) { c.fillStyle = COL[i] + '66'; c.fillRect(i * 90, 300, 90, 190); }
        }
        c.fillStyle = '#fff'; c.fillRect(0, HIT - 2, a.W, 4);
        for (let i = 0; i < 4; i++) { c.strokeStyle = COL[i]; c.lineWidth = 4; c.beginPath(); c.arc(i * 90 + 45, HIT, 30, 0, 7); c.stroke(); txt(c, KEYS[i].toUpperCase(), i * 90 + 45, HIT + 52, 16, '#fff', 'center'); }
        notes.forEach((n) => {
          const y = HIT - (n.t - time) * SP;
          if (y < -30 || y > a.H + 30 || (n.done && n.res !== 'M')) return;
          c.globalAlpha = n.res === 'M' ? 0.3 : 1; c.fillStyle = COL[n.l]; c.strokeStyle = '#fff'; c.lineWidth = 3;
          c.beginPath(); c.arc(n.l * 90 + 45, y, 26, 0, 7); c.fill(); c.stroke(); emo(c, '🐟', n.l * 90 + 45, y + 1, 26); c.globalAlpha = 1;
        });
        drawPeng(c, spr, a.W / 2, 120, 70 + Math.sin(time * 8) * 4, Math.sin(time * 6) * 0.1);
        txt(c, `${score}`, a.W - 12, 24, 24, '#fff', 'right'); txt(c, combo > 1 ? `${combo} COMBO` : '', 12, 24, 20, '#ffe86a');
        if (pop.t > 0) txt(c, pop.s, a.W / 2, 220, 30, pop.c, 'center');
        if (time < 2) txt(c, 'D F J K 키 또는 레인을 터치!', a.W / 2, 300, 18, '#fff', 'center');
      },
    };
  }} />
);
