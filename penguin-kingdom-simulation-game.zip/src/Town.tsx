import { memo, useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties } from 'react';
import { BuildingArt } from './components/BuildingArt';
import { DecoArt } from './components/DecoArt';
import { Penguin } from './components/Penguin';
import { BUILDINGS } from './data/buildings';
import { PItem, Owned, WORLD, curTown, moveItem, specOf, useG } from './store';
import { sfx } from './audio';

export interface Sel { kind: 'b' | 'd'; id: string }
interface Props {
  edit: boolean; sel: Sel | null; setSel: (s: Sel | null) => void;
  onOpen: (it: PItem) => void; centerRef: { current: { x: number; y: number } };
}

const hash = (s: string) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; };

const Backdrop = memo(function Backdrop() {
  const flakes = useMemo(() => Array.from({ length: 46 }, (_, i) => ({ x: (i * 211) % WORLD.w, r: 2 + (i % 4), d: 6 + (i % 7) * 1.5, dl: -(i % 13) * 1.1 })), []);
  const trees = useMemo(() => Array.from({ length: 16 }, (_, i) => ({ x: 100 + i * 150 + (i % 3) * 20, s: 0.7 + (i % 4) * 0.12 })), []);
  return (
    <g>
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7fd0ff" /><stop offset="0.6" stopColor="#c8ecff" /><stop offset="1" stopColor="#f0faff" /></linearGradient>
        <linearGradient id="sea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#5ec4f0" /><stop offset="1" stopColor="#2e90d8" /></linearGradient>
        <linearGradient id="snow" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#ffffff" /><stop offset="1" stopColor="#dff0fb" /></linearGradient>
        <linearGradient id="aur" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#8fffd0" stopOpacity="0" /><stop offset="0.4" stopColor="#8fffd0" stopOpacity=".55" /><stop offset="0.7" stopColor="#c8a0ff" stopOpacity=".5" /><stop offset="1" stopColor="#ff9ad0" stopOpacity="0" /></linearGradient>
      </defs>
      <rect width={WORLD.w} height={560} fill="url(#sky)" />
      <path className="tw" style={{ animationDuration: '7s' }} d="M0 120 Q400 20 800 110 T1600 90 T2400 120 L2400 220 Q2000 160 1600 210 T800 200 T0 230Z" fill="url(#aur)" />
      <circle cx="1950" cy="130" r="64" fill="#fff6b0" opacity=".9" /><circle cx="1950" cy="130" r="100" fill="#fff6b0" opacity=".25" />
      {[[300, 90, 1], [900, 150, 0.8], [1500, 80, 1.2], [2150, 200, 0.9]].map(([x, y, s], i) => (
        <g key={i} style={{ animation: `drift ${90 + i * 25}s linear infinite`, animationDelay: `${-i * 30}s` }}>
          <g transform={`translate(${(x as number) - 300} ${y}) scale(${s})`} fill="#fff" opacity=".92"><ellipse cx="0" cy="0" rx="70" ry="24" /><ellipse cx="-30" cy="-14" rx="34" ry="22" /><ellipse cx="22" cy="-20" rx="40" ry="26" /></g>
        </g>
      ))}
      <path d="M0 400 L180 250 L300 340 L460 200 L640 360 L800 270 L1000 380 L1200 230 L1420 380 L1620 260 L1800 370 L2000 240 L2200 360 L2400 280 V440 H0Z" fill="#cfe6f8" />
      <path d="M460 200 L400 250 L440 262 L470 244 L500 262 L520 246Z M1200 230 L1150 280 L1190 292 L1210 272 L1240 292 L1260 270Z M2000 240 L1950 285 L1985 295 L2010 276 L2040 296 L2060 280Z M180 250 L140 285 L170 292 L190 278 L215 290Z" fill="#fff" />
      <rect y="360" width={WORLD.w} height="120" fill="url(#sea)" />
      <g style={{ animation: 'wave 6s ease-in-out infinite' }} stroke="#fff" strokeWidth="4" fill="none" opacity=".55" strokeLinecap="round">
        {Array.from({ length: 24 }, (_, i) => <path key={i} d={`M${i * 120} ${390 + (i % 3) * 22} q20 -12 40 0 t40 0`} />)}
      </g>
      {[[260, 400, 1], [820, 420, 1.3], [1500, 396, 0.9], [2100, 420, 1.2]].map(([x, y, s], i) => (
        <g key={i} transform={`translate(${x} ${y}) scale(${s})`} style={{ animation: 'bob 5s ease-in-out infinite' }}><path d="M-60 20 L-34 -26 L-10 -4 L18 -48 L50 20Z" fill="#fff" stroke="#bfe2f5" strokeWidth="3" strokeLinejoin="round" /><path d="M-60 20 H50 L40 40 H-50Z" fill="#9fd8f5" /></g>
      ))}
      <path d="M0 470 Q300 430 700 456 T1500 450 T2400 462 V1400 H0Z" fill="url(#snow)" />
      <path d="M0 440 Q300 420 700 440 T1500 436 T2400 446 V470 Q2000 450 1500 466 T700 470 T0 478Z" fill="#fff" />
      <ellipse cx="1180" cy="800" rx="780" ry="330" fill="#eaf6ff" /><ellipse cx="1180" cy="800" rx="720" ry="296" fill="#f4fbff" />
      <ellipse cx="400" cy="1050" rx="150" ry="52" fill="#a6dcf8" stroke="#fff" strokeWidth="6" /><ellipse cx="380" cy="1044" rx="90" ry="26" fill="#c8ecff" opacity=".7" />
      <ellipse cx="2000" cy="640" rx="120" ry="40" fill="#a6dcf8" stroke="#fff" strokeWidth="6" />
      {trees.map((t, i) => (
        <g key={i} transform={`translate(${t.x} ${520 + (i % 2) * 30}) scale(${t.s})`}><rect x="-5" y="-14" width="10" height="16" fill="#8a5a3a" /><path d="M0 -90 L-24 -48 H-10 L-30 -20 H30 L10 -48 H24Z" fill="#6cc89a" stroke="#4aa878" strokeWidth="3" strokeLinejoin="round" /><path d="M0 -90 L-10 -70 Q0 -62 10 -70Z M-18 -46 Q-8 -40 0 -46 Q8 -40 18 -46 L24 -48 L10 -62 H-10 L-24 -48Z" fill="#fff" /></g>
      ))}
      {flakes.map((f, i) => <circle key={i} cx={f.x} cy={0} r={f.r} fill="#fff" opacity=".85" style={{ animation: `fall ${f.d}s linear infinite`, animationDelay: `${f.dl}s` }} />)}
    </g>
  );
});

const Wanderer = memo(function Wanderer({ p, onPoke, poke }: { p: Owned; onPoke: () => void; poke: number }) {
  const h = hash(p.uid);
  const T = 10 + (h % 9);
  const d = 120 + (h % 200);
  return (
    <g onPointerDown={(e) => { e.stopPropagation(); onPoke(); }} style={{ cursor: 'pointer' }}>
      <g style={{ animation: `walkx ${T}s linear infinite`, animationDelay: `${-(h % T)}s`, ['--d' as string]: d + 'px' } as CSSProperties}>
        <g style={{ animation: `flipx ${T}s linear infinite`, animationDelay: `${-(h % T)}s` }}>
          <ellipse cx="0" cy="0" rx="22" ry="5" fill="#2a4a6a" opacity=".16" />
          <g transform="translate(-31 -74)"><g style={{ animation: `hop ${0.55 + (h % 5) * 0.05}s ease-in-out infinite` }}><Penguin spec={specOf(p)} size={62} /></g></g>
        </g>
        {poke > 0 && <text key={poke} x="0" y="-84" textAnchor="middle" fontSize="26" style={{ animation: 'floatUp 1.2s forwards' }}>💕</text>}
      </g>
    </g>
  );
});

export function Town({ edit, sel, setSel, onOpen, centerRef }: Props) {
  const s = useG();
  const town = curTown(s);
  const box = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [size, setSize] = useState({ w: 1000, h: 700 });
  const [view, setView] = useState({ cx: 1180, cy: 780, z: 0.7 });
  const [drag, setDrag] = useState<{ id: string; kind: 'b' | 'd'; x: number; y: number } | null>(null);
  const [pokes, setPokes] = useState<Record<string, number>>({});
  const dr = useRef<{ kind: 'pan' | 'item' | 'pen'; sx: number; sy: number; cx: number; cy: number; moved: boolean; it?: PItem; ik?: 'b' | 'd'; ox?: number; oy?: number; uid?: string } | null>(null);

  useEffect(() => {
    const ro = new ResizeObserver(() => { if (box.current) setSize({ w: box.current.clientWidth, h: box.current.clientHeight }); });
    if (box.current) { ro.observe(box.current); setSize({ w: box.current.clientWidth, h: box.current.clientHeight }); }
    return () => ro.disconnect();
  }, []);
  const minZ = Math.max(size.w / WORLD.w, size.h / WORLD.h);
  const z = Math.min(2.4, Math.max(minZ, view.z));
  const vw = size.w / z, vh = size.h / z;
  const cx = Math.min(WORLD.w - vw / 2, Math.max(vw / 2, view.cx)), cy = Math.min(WORLD.h - vh / 2, Math.max(vh / 2, view.cy));
  const x0 = cx - vw / 2, y0 = cy - vh / 2;
  centerRef.current = { x: cx, y: cy };
  const toWorld = (e: { clientX: number; clientY: number }) => { const r = svgRef.current!.getBoundingClientRect(); return { x: x0 + (e.clientX - r.left) / z, y: y0 + (e.clientY - r.top) / z }; };

  useEffect(() => { // 휠 줌
    const el = box.current!;
    const wh = (e: WheelEvent) => { e.preventDefault(); setView((v) => ({ ...v, cx, cy, z: Math.min(2.4, Math.max(minZ, v.z * (e.deltaY < 0 ? 1.1 : 0.91))) })); };
    el.addEventListener('wheel', wh, { passive: false }); return () => el.removeEventListener('wheel', wh);
  });
  // 터치 핀치
  const pts = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef(0);

  const pdBg = (e: React.PointerEvent) => {
    pts.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.current.size === 2) { const [a, b] = [...pts.current.values()]; pinch.current = Math.hypot(a.x - b.x, a.y - b.y); dr.current = null; return; }
    if (!dr.current) dr.current = { kind: 'pan', sx: e.clientX, sy: e.clientY, cx, cy, moved: false };
    svgRef.current?.setPointerCapture(e.pointerId);
  };
  const pm = (e: React.PointerEvent) => {
    if (pts.current.has(e.pointerId)) pts.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.current.size === 2) { const [a, b] = [...pts.current.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y); if (pinch.current) { const f = d / pinch.current; setView((v) => ({ cx, cy, z: Math.min(2.4, Math.max(minZ, v.z * f)) })); } pinch.current = d; return; }
    const d = dr.current; if (!d) return;
    const dx = e.clientX - d.sx, dy = e.clientY - d.sy;
    if (Math.hypot(dx, dy) > 5) d.moved = true;
    if (d.kind === 'item' && edit && d.moved && d.it) {
      const w = toWorld(e);
      setDrag({ id: d.it.id, kind: d.ik!, x: Math.round(Math.min(WORLD.w - 40, Math.max(40, d.ox! + (w.x - toWorld({ clientX: d.sx, clientY: d.sy }).x)))), y: Math.round(Math.min(WORLD.h - 10, Math.max(440, d.oy! + (w.y - toWorld({ clientX: d.sx, clientY: d.sy }).y)))) });
    } else if (d.moved && (d.kind === 'pan' || d.kind === 'pen' || (d.kind === 'item' && !edit))) {
      setView({ cx: d.cx - dx / z, cy: d.cy - dy / z, z });
    }
  };
  const pu = (e: React.PointerEvent) => {
    pts.current.delete(e.pointerId); if (pts.current.size < 2) pinch.current = 0;
    const d = dr.current; dr.current = null; if (!d) return;
    if (d.kind === 'item' && d.it) {
      if (d.moved && edit && drag) { moveItem(d.ik!, d.it.id, drag.x, drag.y); sfx('pop'); }
      else if (!d.moved) { if (edit) { setSel({ kind: d.ik!, id: d.it.id }); sfx('click'); } else if (d.ik === 'b') { sfx('click'); onOpen(d.it); } }
    } else if (d.kind === 'pen' && !d.moved && d.uid) { sfx('squeak'); const u = d.uid; setPokes((p) => ({ ...p, [u]: (p[u] || 0) + 1 })); }
    else if (d.kind === 'pan' && !d.moved && edit) setSel(null);
    setDrag(null);
  };
  const pdItem = (e: React.PointerEvent, it: PItem, ik: 'b' | 'd') => {
    e.stopPropagation();
    pts.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.current.size >= 2) return;
    dr.current = { kind: 'item', sx: e.clientX, sy: e.clientY, cx, cy, moved: false, it, ik, ox: it.x, oy: it.y };
    svgRef.current?.setPointerCapture(e.pointerId);
  };

  const pens = useMemo(() => {
    const m = s.pens.filter((p) => p.uid === town.mayor);
    const others = s.pens.filter((p) => p.uid !== town.mayor).slice(-13);
    return [...m, ...others];
  }, [s.pens, town.mayor]);

  type Entry = { k: 'b' | 'd' | 'p'; y: number; key: string; it?: PItem; pen?: Owned; px?: number };
  const entries: Entry[] = [];
  town.b.forEach((it) => entries.push({ k: 'b', y: drag && drag.id === it.id ? drag.y : it.y, key: it.id, it }));
  town.d.forEach((it) => entries.push({ k: 'd', y: drag && drag.id === it.id ? drag.y : it.y, key: it.id, it }));
  pens.forEach((p) => { const h = hash(p.uid); entries.push({ k: 'p', y: 560 + (h % 700), key: p.uid, pen: p, px: 260 + (h % 1800) }); });
  entries.sort((a, b) => a.y - b.y);

  const zoom = (f: number) => setView({ cx, cy, z: Math.min(2.4, Math.max(minZ, z * f)) });

  return (
    <div ref={box} className="absolute inset-0 overflow-hidden" style={{ touchAction: 'none', cursor: dr.current ? 'grabbing' : 'grab' }}>
      <svg ref={svgRef} width={size.w} height={size.h} viewBox={`${x0} ${y0} ${vw} ${vh}`} onPointerDown={pdBg} onPointerMove={pm} onPointerUp={pu} onPointerCancel={pu} style={{ display: 'block' }}>
        <Backdrop />
        {edit && <g opacity=".25" stroke="#7fb8e0" strokeWidth="1">{Array.from({ length: 24 }, (_, i) => <path key={i} d={`M${i * 100} 440 V${WORLD.h}`} />)}{Array.from({ length: 10 }, (_, i) => <path key={i} d={`M0 ${440 + i * 100} H${WORLD.w}`} />)}</g>}
        {entries.map((e) => {
          if (e.k === 'p') return <g key={e.key} transform={`translate(${e.px} ${e.y})`}><Wanderer p={e.pen!} poke={pokes[e.key] || 0} onPoke={() => { sfx('squeak'); setPokes((p) => ({ ...p, [e.key]: (p[e.key] || 0) + 1 })); }} /></g>;
          const it = e.it!; const isDrag = drag && drag.id === it.id; const x = isDrag ? drag!.x : it.x; const y = e.y;
          const selected = sel && sel.id === it.id;
          if (e.k === 'b') {
            const def = BUILDINGS[it.t]; const sc = def.scale;
            return (
              <g key={e.key} transform={`translate(${x} ${y})`} onPointerDown={(ev) => pdItem(ev, it, 'b')} style={{ cursor: edit ? 'move' : 'pointer' }}>
                <g style={!edit && !def.special ? undefined : undefined}><BuildingArt def={def} glow={!!selected} /></g>
                <rect x={-80 * sc} y={-176 * sc} width={160 * sc} height={184 * sc} fill="transparent" />
                {def.special && !edit && (
                  <g transform={`translate(0 ${16})`}><rect x="-62" y="-2" width="124" height="26" rx="13" fill="#fff" stroke="#ff9ec8" strokeWidth="3" /><text x="0" y="16" textAnchor="middle" fontSize="15" fontWeight="bold" fill="#e0558f">{def.name}</text></g>
                )}
              </g>
            );
          }
          return (
            <g key={e.key} transform={`translate(${x} ${y})`} onPointerDown={(ev) => pdItem(ev, it, 'd')} style={{ cursor: edit ? 'move' : 'default' }}>
              <DecoArt t={it.t} glow={!!selected} /><rect x="-46" y="-120" width="92" height="124" fill="transparent" />
            </g>
          );
        })}
      </svg>
      <div className="absolute right-3 bottom-3 flex flex-col gap-2 z-10">
        <button className="btn-cute w-11 h-11 text-2xl font-bold text-pink-500" onClick={() => zoom(1.25)}>＋</button>
        <button className="btn-cute w-11 h-11 text-2xl font-bold text-pink-500" onClick={() => zoom(0.8)}>－</button>
      </div>
    </div>
  );
}
