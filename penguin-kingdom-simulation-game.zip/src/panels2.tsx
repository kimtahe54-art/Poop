import { useEffect, useMemo, useState } from 'react';
import { Modal, RarityTag, Coin, fmt } from './ui';
import { Penguin } from './components/Penguin';
import { BuildingPreview, shade } from './components/BuildingArt';
import { DECOS, DecoPreview } from './components/DecoArt';
import { BUILDINGS, CATS } from './data/buildings';
import { PSpec, RARITY, THEMES, TOTAL_SPECIES, VARIANTS, makeSid, rnd, speciesName, speciesSpec, speciesTier, speciesTheme, speciesVar, pick, NV, Fx } from './data/penguinData';
import { BANK_CAP, BANK_RATE, addTown, bankPending, claimBank, claimDaily, curTown, earn, specOf, toast, useG } from './store';
import { sfx } from './audio';

// ───────── 도감 ─────────
export function DexPanel({ onClose }: { onClose: () => void }) {
  const s = useG();
  const [tab, setTab] = useState<'dex' | 'mine'>('dex');
  const [tier, setTier] = useState(-1);
  const [theme, setTheme] = useState(-1);
  const [ownedOnly, setOwnedOnly] = useState(false);
  const [page, setPage] = useState(0);
  const [sel, setSel] = useState<number | null>(null);
  const dex = useMemo(() => new Set(s.dex), [s.dex]);
  const counts = useMemo(() => { const m = new Map<number, number>(); s.pens.forEach((p) => m.set(p.sid, (m.get(p.sid) || 0) + 1)); return m; }, [s.pens]);
  const list = useMemo(() => {
    const r: number[] = [];
    for (let i = 0; i < TOTAL_SPECIES; i++) {
      if (tier >= 0 && speciesTier(i) !== tier) continue;
      if (theme >= 0 && speciesTheme(i) !== theme) continue;
      if (ownedOnly && !dex.has(i)) continue;
      r.push(i);
    }
    return r;
  }, [tier, theme, ownedOnly, dex]);
  const PER = 40;
  const pages = Math.max(1, Math.ceil(list.length / PER));
  const pg = Math.min(page, pages - 1);
  const owned = s.dex.length;
  return (
    <Modal title="펭귄 도감" icon="📖" onClose={onClose} tone="purple" wide>
      <div className="flex gap-2 mb-3">
        <button className={'px-4 py-1.5 rounded-full font-bold ' + (tab === 'dex' ? 'bg-fuchsia-400 text-white' : 'bg-white text-fuchsia-500 border-2 border-fuchsia-200')} onClick={() => setTab('dex')}>전체 도감</button>
        <button className={'px-4 py-1.5 rounded-full font-bold ' + (tab === 'mine' ? 'bg-fuchsia-400 text-white' : 'bg-white text-fuchsia-500 border-2 border-fuchsia-200')} onClick={() => setTab('mine')}>내 펭귄 ({s.pens.length})</button>
        <div className="ml-auto text-sm font-bold text-fuchsia-600 self-center">수집 {owned} / {fmt(TOTAL_SPECIES)} ({((owned / TOTAL_SPECIES) * 100).toFixed(1)}%)</div>
      </div>
      <div className="h-2 rounded-full bg-fuchsia-100 mb-3 overflow-hidden"><div className="h-full bg-gradient-to-r from-pink-400 to-fuchsia-400" style={{ width: (owned / TOTAL_SPECIES) * 100 + '%' }} /></div>
      {tab === 'dex' ? (
        <>
          <div className="flex flex-wrap gap-2 mb-3 items-center text-sm">
            <select className="rounded-full border-2 border-pink-200 px-3 py-1 bg-white" value={tier} onChange={(e) => { setTier(+e.target.value); setPage(0); }}>
              <option value={-1}>모든 등급</option>{RARITY.map((r, i) => <option key={i} value={i}>{r.name}</option>)}
            </select>
            <select className="rounded-full border-2 border-pink-200 px-3 py-1 bg-white" value={theme} onChange={(e) => { setTheme(+e.target.value); setPage(0); }}>
              <option value={-1}>모든 종류 ({THEMES.length}색)</option>{THEMES.map((t, i) => <option key={i} value={i}>{t.name}</option>)}
            </select>
            <label className="flex items-center gap-1 font-bold text-pink-500"><input type="checkbox" checked={ownedOnly} onChange={(e) => { setOwnedOnly(e.target.checked); setPage(0); }} />모은 것만</label>
            <span className="text-gray-400">{fmt(list.length)}종</span>
          </div>
          <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-2">
            {list.slice(pg * PER, pg * PER + PER).map((sid) => {
              const has = dex.has(sid);
              return (
                <button key={sid} onClick={() => setSel(sid)} className="relative rounded-2xl bg-white border-4 p-1 flex flex-col items-center" style={{ borderColor: has ? RARITY[speciesTier(sid)].glow : '#eee' }}>
                  <div style={has ? undefined : { filter: 'brightness(0)', opacity: 0.18 }}><Penguin spec={speciesSpec(sid)} size={56} still /></div>
                  <span className="text-[10px] leading-tight text-center h-6 overflow-hidden">{has ? speciesName(sid).replace(' 펭귄', '') : '???'}</span>
                  {has && counts.get(sid) ? <span className="absolute top-0 right-0 text-[10px] bg-pink-400 text-white rounded-full px-1.5">x{counts.get(sid)}</span> : null}
                  <span className="absolute top-0 left-0 w-2.5 h-2.5 rounded-full" style={{ background: RARITY[speciesTier(sid)].color }} />
                </button>
              );
            })}
          </div>
          <div className="flex items-center justify-center gap-3 mt-4">
            <button className="btn-cute px-4 py-1" disabled={pg === 0} onClick={() => setPage(pg - 1)}>◀</button>
            <span className="font-bold text-pink-500">{pg + 1} / {pages}</span>
            <button className="btn-cute px-4 py-1" disabled={pg >= pages - 1} onClick={() => setPage(pg + 1)}>▶</button>
          </div>
        </>
      ) : (
        s.pens.length === 0 ? <p className="text-center py-12 text-gray-500">아직 펭귄이 없어요. 알을 부화시켜보세요! 🥚</p> :
          <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-2">
            {s.pens.map((p) => (
              <div key={p.uid} className="rounded-2xl bg-white border-4 border-pink-100 p-1 flex flex-col items-center">
                <Penguin spec={specOf(p)} size={60} still /><span className="text-[11px] font-bold text-pink-500 truncate w-full text-center">{p.name}</span>
                <span className="text-[9px] text-gray-400 truncate w-full text-center">{p.custom ? '나만의 펭귄' : speciesName(p.sid).replace(' 펭귄', '')}</span>
              </div>
            ))}
          </div>
      )}
      {sel != null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setSel(null)}>
          <div className="pop-in bg-white rounded-3xl border-4 border-pink-200 p-6 text-center max-w-xs" onClick={(e) => e.stopPropagation()}>
            <div style={dex.has(sel) ? { animation: 'bob 2s infinite' } : { filter: 'brightness(0)', opacity: 0.2 }} className="flex justify-center"><Penguin spec={speciesSpec(sel)} size={170} /></div>
            <div className="text-xl font-bold text-pink-600 mt-2">{dex.has(sel) ? speciesName(sel) : '???'}</div>
            <div className="my-1"><RarityTag tier={speciesTier(sel)} /></div>
            <div className="text-sm text-gray-500">{THEMES[speciesTheme(sel)].name} 계열 · {VARIANTS[speciesVar(sel)].name || '기본형'}</div>
            <div className="text-sm text-gray-500">보유: {counts.get(sel) || 0}마리</div>
            <button className="btn-main px-6 py-1 mt-3" onClick={() => setSel(null)}>닫기</button>
          </div>
        </div>
      )}
    </Modal>
  );
}

// ───────── 건설 / 꾸미기 ─────────
export function BuildPanel({ onClose, onBuy, initialTab = 'b' }: { onClose: () => void; onBuy: (kind: 'b' | 'd', t: number) => void; initialTab?: 'b' | 'd' }) {
  const s = useG();
  const [tab, setTab] = useState<'b' | 'd'>(initialTab);
  const [cat, setCat] = useState('all');
  const [q, setQ] = useState('');
  const town = curTown(s);
  const cats = ['all', ...Object.keys(CATS)];
  const blist = BUILDINGS.filter((b) => (cat === 'all' || b.cat === cat) && b.name.includes(q));
  const dlist = DECOS.map((d, i) => ({ ...d, i })).filter((d) => d.name.includes(q));
  return (
    <Modal title="건설 · 꾸미기" icon="🏗️" onClose={onClose} tone="green" wide>
      <div className="flex flex-wrap gap-2 mb-3 items-center">
        <button className={'px-4 py-1.5 rounded-full font-bold ' + (tab === 'b' ? 'bg-emerald-400 text-white' : 'bg-white text-emerald-600 border-2 border-emerald-200')} onClick={() => setTab('b')}>🏠 건물 ({BUILDINGS.length})</button>
        <button className={'px-4 py-1.5 rounded-full font-bold ' + (tab === 'd' ? 'bg-emerald-400 text-white' : 'bg-white text-emerald-600 border-2 border-emerald-200')} onClick={() => setTab('d')}>🎀 장식 ({DECOS.length})</button>
        <input className="rounded-full border-2 border-emerald-200 px-3 py-1 text-sm" placeholder="검색…" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="ml-auto"><Coin n={s.coins} className="text-amber-600" /></div>
      </div>
      <p className="text-xs text-emerald-700 mb-2">‘{town.name}’에 건물 {town.b.length}개 · 장식 {town.d.length}개 · 구매하면 화면 중앙에 놓여요. 드래그로 옮기고 삭제하면 50% 환불!</p>
      {tab === 'b' && <div className="flex flex-wrap gap-1.5 mb-3">{cats.map((c) => <button key={c} onClick={() => setCat(c)} className={'px-3 py-0.5 rounded-full text-xs font-bold ' + (cat === c ? 'bg-pink-400 text-white' : 'bg-white text-pink-500 border border-pink-200')}>{c === 'all' ? '전체' : CATS[c].label}</button>)}</div>}
      <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-2">
        {tab === 'b' ? blist.map((b) => (
          <div key={b.id} className="rounded-2xl bg-white border-4 border-emerald-100 p-2 flex flex-col items-center text-center">
            <BuildingPreview def={b} size={74} />
            <div className="text-xs font-bold text-emerald-700 leading-tight h-8 flex items-center">{b.name}</div>
            <button className="btn-main px-2 py-1 mt-1 text-xs w-full" disabled={s.coins < b.price} onClick={() => onBuy('b', b.id)}><Coin n={b.price} className="text-white justify-center" /></button>
          </div>
        )) : dlist.map((d) => (
          <div key={d.i} className="rounded-2xl bg-white border-4 border-emerald-100 p-2 flex flex-col items-center text-center">
            <DecoPreview t={d.i} size={64} />
            <div className="text-xs font-bold text-emerald-700 h-8 flex items-center">{d.name}</div>
            <button className="btn-main px-2 py-1 mt-1 text-xs w-full" disabled={s.coins < d.price} onClick={() => onBuy('d', d.i)}><Coin n={d.price} className="text-white justify-center" /></button>
          </div>
        ))}
      </div>
    </Modal>
  );
}

// ───────── 은행 ─────────
export function BankPanel({ onClose }: { onClose: () => void }) {
  const s = useG();
  const [, tick] = useState(0);
  const [boxT, setBoxT] = useState(() => Number(localStorage.getItem('pn-box') || 0));
  useEffect(() => { const id = setInterval(() => tick((x) => x + 1), 500); return () => clearInterval(id); }, []);
  const pend = bankPending(s);
  const today = new Date().toDateString();
  const boxLeft = Math.max(0, Math.ceil((boxT + 30000 - Date.now()) / 1000));
  const openBox = () => { const n = 30 + rnd(120); earn(n); sfx('coin'); toast(`🎁 행운 상자에서 ${n} 코인!`); const now = Date.now(); localStorage.setItem('pn-box', String(now)); setBoxT(now); };
  return (
    <Modal title="펭귄 은행" icon="🏦" onClose={onClose} tone="yellow">
      <div className="text-center mb-4"><Coin n={s.coins} className="text-2xl text-amber-600" /></div>
      <div className="grid gap-3">
        <div className="rounded-3xl bg-white border-4 border-amber-100 p-4 flex items-center gap-4">
          <div className="text-5xl">🐷</div>
          <div className="flex-1">
            <div className="font-bold text-amber-700">자동 저금통 (1초에 {BANK_RATE}코인 · 최대 {fmt(BANK_CAP)})</div>
            <div className="h-3 rounded-full bg-amber-100 mt-1 overflow-hidden"><div className="h-full bg-gradient-to-r from-yellow-300 to-amber-400" style={{ width: (pend / BANK_CAP) * 100 + '%' }} /></div>
            <div className="text-sm text-gray-500 mt-1">쌓인 코인: <b className="text-amber-600">{fmt(pend)}</b></div>
          </div>
          <button className="btn-main px-4 py-2" disabled={pend <= 0} onClick={() => { const n = claimBank(); sfx('coin'); toast(`💰 ${fmt(n)} 코인을 찾았어요!`); }}>받기</button>
        </div>
        <div className="rounded-3xl bg-white border-4 border-amber-100 p-4 flex items-center gap-4">
          <div className="text-5xl">📅</div>
          <div className="flex-1"><div className="font-bold text-amber-700">출석 보너스</div><div className="text-sm text-gray-500">하루에 한 번 500코인!</div></div>
          <button className="btn-main px-4 py-2" disabled={s.daily === today} onClick={() => { const n = claimDaily(); if (n) { sfx('win'); toast(`📅 출석 보너스 ${n} 코인!`); } }}>{s.daily === today ? '완료' : '받기'}</button>
        </div>
        <div className="rounded-3xl bg-white border-4 border-amber-100 p-4 flex items-center gap-4">
          <div className="text-5xl">🎁</div>
          <div className="flex-1"><div className="font-bold text-amber-700">행운 상자</div><div className="text-sm text-gray-500">30초마다 무료로 30~150코인!</div></div>
          <button className="btn-main px-4 py-2" disabled={boxLeft > 0} onClick={openBox}>{boxLeft > 0 ? boxLeft + '초' : '열기'}</button>
        </div>
        <p className="text-center text-xs text-gray-400">은행에서 받는 코인은 모두 공짜예요 💖</p>
      </div>
    </Modal>
  );
}

// ───────── 나만의 펭귄 + 마을 추가 ─────────
const BODY_SW = ['#8fd3ff', '#ffb3d1', '#b8f08a', '#ffe680', '#cdb4ff', '#ff9d94', '#8ff0d0', '#ffc2a0', '#6a6aff', '#444a66', '#ffffff', '#ffd24a'];
const CHEEK_SW = ['#ff9fb8', '#ff7aa8', '#ffb59a', '#ff8ac8'];
const ACC_OPTS = VARIANTS.map((v, i) => ({ label: v.name || '없음', acc: v.acc, pat: v.pat, i }));
export function CreatePanel({ onClose }: { onClose: () => void }) {
  const s = useG();
  const [body, setBody] = useState('#8fd3ff');
  const [belly, setBelly] = useState('#ffffff');
  const [cheek, setCheek] = useState('#ff9fb8');
  const [outlineAuto, setOutlineAuto] = useState(true);
  const [outline, setOutline] = useState('#2f9be6');
  const [eye, setEye] = useState(0);
  const [vi, setVi] = useState(0);
  const [fx, setFx] = useState<Fx>('none');
  const [a1, setA1] = useState('#ff6fa5');
  const [pname, setPname] = useState('');
  const [tname, setTname] = useState('');
  const spec: PSpec = { body, light: shade(body, 0.45), outline: outlineAuto ? shade(body, -0.35) : outline, belly, cheek, fx, acc: VARIANTS[vi].acc, pat: VARIANTS[vi].pat, eye, a1, a2: shade(a1, 0.7) };
  const random = () => {
    const t = THEMES[rnd(THEMES.length)];
    setBody(t.body); setBelly(t.belly); setCheek(t.cheek); setFx(t.fx); setVi(rnd(NV)); setEye(rnd(6)); setA1(pick(['#ff6fa5', '#5aa8ff', '#ffb020', '#8a5cf0', '#34c78a']));
  };
  const create = () => {
    const pn = pname.trim() || '나의 펭귄', tn = tname.trim() || `${pname.trim() || '새'} 마을`;
    addTown(tn, pn, spec); sfx('win'); toast(`🏡 ${tn} 이(가) 만들어졌어요!`); onClose();
  };
  return (
    <Modal title="나만의 펭귄 만들기 + 마을 추가" icon="➕" onClose={onClose} tone="pink" wide>
      <div className="flex flex-col md:flex-row gap-4">
        <div className="md:w-64 flex flex-col items-center">
          <div className="rounded-3xl bg-gradient-to-b from-sky-100 to-white border-4 border-white shadow-inner p-3 w-full flex justify-center"><div style={{ animation: 'bob 2s infinite' }}><Penguin spec={spec} size={190} /></div></div>
          <input className="mt-3 w-full rounded-full border-2 border-pink-200 px-4 py-2 text-center" placeholder="펭귄 이름" maxLength={8} value={pname} onChange={(e) => setPname(e.target.value)} />
          <input className="mt-2 w-full rounded-full border-2 border-sky-200 px-4 py-2 text-center" placeholder="새 마을 이름" maxLength={10} value={tname} onChange={(e) => setTname(e.target.value)} />
          <button className="btn-cute mt-2 px-4 py-1.5 text-sm w-full" onClick={random}>🎲 랜덤 디자인</button>
          <button className="btn-main mt-2 px-4 py-2.5 text-lg w-full" onClick={create}>🏡 만들고 마을 추가!</button>
          <p className="text-[11px] text-gray-400 mt-1 text-center">현재 마을 {s.towns.length}개 · 만든 펭귄은 새 마을의 이장님이 돼요</p>
        </div>
        <div className="flex-1 grid gap-3 text-sm">
          <Row label="몸 색깔"><Sw list={BODY_SW} v={body} set={setBody} /><input type="color" value={body} onChange={(e) => setBody(e.target.value)} className="w-8 h-8 rounded-full" /></Row>
          <Row label="배 색깔"><Sw list={['#ffffff', '#fff7e0', '#ffe8f0', '#e6f6ff', '#f0e8ff', '#ffe6a8']} v={belly} set={setBelly} /></Row>
          <Row label="볼터치"><Sw list={CHEEK_SW} v={cheek} set={setCheek} /></Row>
          <Row label="테두리"><label className="flex items-center gap-1"><input type="checkbox" checked={outlineAuto} onChange={(e) => setOutlineAuto(e.target.checked)} />자동</label>{!outlineAuto && <input type="color" value={outline} onChange={(e) => setOutline(e.target.value)} className="w-8 h-8 rounded-full" />}</Row>
          <Row label="눈 색깔">{['#5b3df5', '#1f8fff', '#14b88a', '#ff5d8f', '#8a5a2b', '#ff9d1f'].map((c, i) => <button key={c} onClick={() => setEye(i)} className={'w-8 h-8 rounded-full border-4 ' + (eye === i ? 'border-pink-400' : 'border-white')} style={{ background: c }} />)}</Row>
          <Row label="반짝 효과">{(['none', 'rainbow', 'galaxy', 'sparkle', 'aurora', 'gold', 'candy'] as Fx[]).map((f) => <button key={f} onClick={() => setFx(f)} className={'px-3 py-0.5 rounded-full text-xs font-bold ' + (fx === f ? 'bg-pink-400 text-white' : 'bg-white border border-pink-200 text-pink-500')}>{({ none: '없음', rainbow: '무지개', galaxy: '갤럭시', sparkle: '반짝', aurora: '오로라', gold: '황금', candy: '캔디' } as Record<string, string>)[f]}</button>)}</Row>
          <Row label="장식 색"><Sw list={['#ff6fa5', '#5aa8ff', '#ffb020', '#8a5cf0', '#34c78a', '#ff6a4a', '#3b3b6a']} v={a1} set={setA1} /></Row>
          <Row label="모자 · 무늬"><div className="flex flex-wrap gap-1">{ACC_OPTS.map((o) => <button key={o.i} onClick={() => setVi(o.i)} className={'px-2.5 py-0.5 rounded-full text-xs font-bold ' + (vi === o.i ? 'bg-sky-400 text-white' : 'bg-white border border-sky-200 text-sky-600')}>{o.label}</button>)}</div></Row>
        </div>
      </div>
    </Modal>
  );
}
const Row = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <div className="flex items-center gap-2 flex-wrap"><span className="w-20 font-bold text-pink-500 shrink-0">{label}</span>{children}</div>
);
const Sw = ({ list, v, set }: { list: string[]; v: string; set: (c: string) => void }) => (
  <>{list.map((c) => <button key={c} onClick={() => set(c)} className={'w-8 h-8 rounded-full border-4 shadow ' + (v === c ? 'border-pink-400 scale-110' : 'border-white')} style={{ background: c }} />)}</>
);

export { makeSid };
