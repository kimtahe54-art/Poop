export type Fx = 'none' | 'rainbow' | 'galaxy' | 'sparkle' | 'aurora' | 'gold' | 'candy';
export interface PSpec {
  body: string; light: string; outline: string; belly: string; cheek: string;
  fx: Fx; acc: string; pat: string; eye: number; a1: string; a2: string;
}

export const RARITY = [
  { name: '일반', color: '#9aa5b1', glow: '#d5dbe2' },
  { name: '레어', color: '#3d9bff', glow: '#a8d4ff' },
  { name: '슈퍼레어', color: '#9b6bff', glow: '#d2bcff' },
  { name: '에픽', color: '#ff5fae', glow: '#ffb5da' },
  { name: '레전드', color: '#ffb000', glow: '#ffe28a' },
];

// name|body|light|outline|belly|cheek|tier
const RAW = `하늘|8fd3ff|d2efff|2f9be6|ffffff|ff9fb8|0
민트|8ff0d0|d0fbee|2cbf98|f6fffc|ffa6b9|0
레몬|ffe680|fff6c4|dfae1c|fffdf2|ffa0a0|0
복숭아|ffc2a0|ffe3d3|ee8a5c|fff9f4|ff8fa0|0
라벤더|cdb4ff|e9dfff|8a64e0|fcf9ff|ffa3c9|0
분홍|ffb3d1|ffdcea|e8639a|fff9fc|ff7aa8|0
연두|b8f08a|e0f9c8|6cc03a|fbfff4|ffa5a5|0
구름|dfe9f5|f5f9ff|8fa6c4|ffffff|ffb0c4|0
파스텔캔디|ffc6e6|c9e8ff|ec7fbf|fff5fb|ff8fc0|1
크림소다|9ee8dc|f2fff9|35b5a4|fffdf2|ffa8a8|1
메론소다|a8f0a0|e6ffd6|4cc04a|f7fff0|ffa6a6|1
핑크 딸기|ff9ebb|ffd0de|e04a7b|fff4f6|ff6f91|1
블루베리|8f9bff|c9d0ff|4a55d6|f7f8ff|ff9ec6|1
바닐라|fff0c8|fff9e6|d9b36a|ffffff|ffb3a6|1
초코|b07a5a|d9a98a|6a3f27|ffeedd|ff9a8a|1
우유|f4f1ff|ffffff|a9a4c6|ffffff|ffb7c8|1
말차|b5d99a|dcf0c8|6e9f4c|f7ffee|ffa89a|1
마카롱|ffb8d9|e5d4ff|d86aa6|fff7fc|ff8fb7|1
솜사탕|ffc9f0|c4e7ff|d878c4|fff6fd|ff8ac8|1
오렌지에이드|ffb866|ffe0b0|e8841c|fffaf0|ff8a7a|1
체리블라썸|ffc1d6|ffe6ee|e8708f|fffafc|ff7a9c|2
포도|b78cf0|ddc8ff|7a46c2|faf5ff|ff9ccb|2
레몬소다|f6ff8a|fdffd0|b9c61c|ffffee|ffa89a|2
캐러멜|e0a060|f5cf9a|a8662a|fff2dd|ff9078|2
아이스민트|a0fff0|dcfffa|2fd0c0|ffffff|ffa0b8|2
복숭아젤리|ffb0a0|ffd9d0|ec6a58|fff6f2|ff7a8c|2
코튼캔디|e0b8ff|b8e8ff|a066e0|fffaff|ff90d0|2
쿠키앤크림|e8e4e0|ffffff|6b5a50|ffffff|ffb0b0|2
망고|ffd24a|ffe99a|e8a010|fffbea|ff8a60|2
수박|ff8a9a|c8f7a8|3cae5a|fff4f4|ff5c7a|2
라떼|d9b8a0|f3e2d3|9a6e52|fff7ef|ffa59a|2
바다|6ec6ff|b9e7ff|2478d0|f2fbff|ffa0b8|2
무지개|ffadad|ffe7a8|a070e0|ffffff|ff8fb0|3
오로라|7ef5d0|c8b8ff|3aa8a8|f4fffc|ffa0d0|3
크리스탈|a8e4ff|e6f8ff|4aa8e8|ffffff|ffb0d0|3
진주|f6eef8|ffffff|b79ac4|ffffff|ffb7d5|3
벚꽃|ffc4dc|fff0f6|e06a98|ffffff|ff7aa8|3
노을|ff9a76|ffd1a0|d85a50|fff1e6|ff7088|3
캔디팝|ff8ad0|ffd0f0|d03a9a|fff7fc|ff5aa0|3
홀로그램|c8e0ff|f5eaff|8a8ad8|ffffff|ffa0d0|3
네온|3dffa5|a9ffd9|00b86b|f0fff8|ff86b8|3
보석|9a7bff|d0c0ff|5a36d0|f7f2ff|ff8ccc|3
갤럭시|3b2a8a|6e4fd0|1b1050|e6dcff|ff8fd0|4
별빛|2a3a8a|5a78e0|141c5a|e0e8ff|ffa0d0|4
달빛|c9d4ff|f0f4ff|6a7ad8|ffffff|ffa8d0|4
황금|ffd24a|fff2a0|c88a00|fffbe8|ff9a70|4
다이아몬드|d8f6ff|ffffff|5ac0e8|ffffff|ffa8d0|4
우주|2a1a5a|6a3ac0|120a30|e0d4ff|ff7ac0|4
드래곤|7be07b|c8ffa8|2c9a3c|f2ffe0|ff9060|4
불사조|ff7a3a|ffc080|c83a10|fff0d8|ff5a70|4`;

const FX_BY: Record<string, Fx> = {
  파스텔캔디: 'candy', 솜사탕: 'candy', 캔디팝: 'candy', 코튼캔디: 'candy',
  무지개: 'rainbow', 홀로그램: 'rainbow', 오로라: 'aurora',
  크리스탈: 'sparkle', 진주: 'sparkle', 보석: 'sparkle', 네온: 'sparkle', 달빛: 'sparkle', 다이아몬드: 'sparkle', 벚꽃: 'sparkle',
  갤럭시: 'galaxy', 별빛: 'galaxy', 우주: 'galaxy', 황금: 'gold', 불사조: 'sparkle', 드래곤: 'sparkle',
};

export interface Theme { name: string; body: string; light: string; outline: string; belly: string; cheek: string; tier: number; fx: Fx }
export const THEMES: Theme[] = RAW.split('\n').map((l) => {
  const p = l.split('|');
  return { name: p[0], body: '#' + p[1], light: '#' + p[2], outline: '#' + p[3], belly: '#' + p[4], cheek: '#' + p[5], tier: +p[6], fx: FX_BY[p[0]] || 'none' };
});

// name, acc, pat, tierBump
export const VARIANTS: { name: string; acc: string; pat: string; bump: number }[] = [
  { name: '', acc: 'none', pat: 'none', bump: 0 },
  { name: '리본', acc: 'bow', pat: 'none', bump: 0 },
  { name: '별무늬', acc: 'none', pat: 'stars', bump: 0 },
  { name: '하트무늬', acc: 'none', pat: 'hearts', bump: 0 },
  { name: '왕관', acc: 'crown', pat: 'none', bump: 1 },
  { name: '비니', acc: 'beanie', pat: 'none', bump: 0 },
  { name: '안경', acc: 'glasses', pat: 'none', bump: 0 },
  { name: '스카프', acc: 'scarf', pat: 'none', bump: 0 },
  { name: '꽃', acc: 'flower', pat: 'none', bump: 0 },
  { name: '물방울', acc: 'none', pat: 'dots', bump: 0 },
  { name: '줄무늬', acc: 'none', pat: 'stripes', bump: 0 },
  { name: '천사', acc: 'halo', pat: 'none', bump: 1 },
  { name: '고깔모자', acc: 'party', pat: 'none', bump: 0 },
  { name: '헤드폰', acc: 'phones', pat: 'none', bump: 0 },
  { name: '해적', acc: 'pirate', pat: 'none', bump: 0 },
  { name: '요리사', acc: 'chef', pat: 'none', bump: 0 },
  { name: '마법사', acc: 'wizard', pat: 'none', bump: 1 },
  { name: '고양이귀', acc: 'cat', pat: 'none', bump: 0 },
  { name: '곰돌이', acc: 'bear', pat: 'none', bump: 0 },
  { name: '토끼귀', acc: 'bunny', pat: 'none', bump: 0 },
  { name: '유니콘', acc: 'horn', pat: 'none', bump: 1 },
  { name: '반짝이', acc: 'sparkles', pat: 'none', bump: 1 },
];
export const ACCESSORIES = VARIANTS.map((v) => v.acc);
export const PATTERNS = ['none', 'stars', 'hearts', 'dots', 'stripes'];

const ACCS = [['#ff6fa5', '#ffd6e8'], ['#5aa8ff', '#d6ebff'], ['#ffb020', '#fff0c0'], ['#8a5cf0', '#e6dcff'], ['#34c78a', '#d3f8e6'], ['#ff6a4a', '#ffe0d6'], ['#3b3b6a', '#cfcfe8'], ['#e84a6a', '#ffd0da']];

export const NV = VARIANTS.length;
export const TOTAL_SPECIES = THEMES.length * NV;

export const speciesTheme = (sid: number) => Math.floor(sid / NV);
export const speciesVar = (sid: number) => sid % NV;
export const makeSid = (t: number, v: number) => t * NV + v;
export const speciesTier = (sid: number) => Math.min(4, THEMES[speciesTheme(sid)].tier + VARIANTS[speciesVar(sid)].bump);
export function speciesName(sid: number) {
  const t = THEMES[speciesTheme(sid)];
  const v = VARIANTS[speciesVar(sid)];
  return `${t.name}${v.name ? ' ' + v.name : ''} 펭귄`;
}
const specCache = new Map<number, PSpec>();
export function speciesSpec(sid: number): PSpec {
  let s = specCache.get(sid);
  if (s) return s;
  const ti = speciesTheme(sid), vi = speciesVar(sid);
  const t = THEMES[ti], v = VARIANTS[vi];
  const ac = ACCS[(ti * 3 + vi) % ACCS.length];
  s = { body: t.body, light: t.light, outline: t.outline, belly: t.belly, cheek: t.cheek, fx: t.fx, acc: v.acc, pat: v.pat, eye: (ti + vi) % 6, a1: ac[0], a2: ac[1] };
  // 어두운 계열은 장신구 색을 밝게
  if (t.fx === 'galaxy' || t.name === '초코') s = { ...s, a1: ['#ffd24a', '#ff8fd0', '#8fe0ff'][vi % 3], a2: '#fff' };
  specCache.set(sid, s);
  return s;
}

export const NAMES = ['몽실', '보리', '콩이', '두부', '별이', '구름', '솜이', '밤이', '푸딩', '꿈이', '하늘', '모찌', '코코', '뽀로', '새봄', '라떼', '쿠키', '젤리', '초롱', '아롱', '다롱', '토리', '마루', '나비', '호두', '미미', '루루', '뭉치', '단비', '해랑', '바다', '레이', '핑크', '소다', '크림', '몽이', '뽀짝', '둥이', '포도', '봄이'];

export const rnd = (n: number) => Math.floor(Math.random() * n);
export const pick = <T,>(a: T[]): T => a[rnd(a.length)];
export const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3);

// ===== 알 종류 =====
export interface EggType {
  id: number; name: string; price: number; base: string; spot: string; accent: string; pat: string;
  weights: number[]; pool?: string[]; desc: string;
}
export const EGGS: EggType[] = [
  { id: 0, name: '노말에그', price: 100, base: '#fff4e0', spot: '#e8c9a0', accent: '#ffd9a8', pat: 'dots', weights: [70, 25, 5, 0, 0], desc: '가장 기본적인 알. 어떤 펭귄이 나올까요?' },
  { id: 1, name: '큐티에그', price: 250, base: '#ffd6ec', spot: '#fff', accent: '#ff9ccb', pat: 'hearts', weights: [35, 45, 20, 0, 0], desc: '하트가 콕콕! 귀여운 펭귄이 잘 나와요.' },
  { id: 2, name: '디저트에그', price: 400, base: '#ffe0b8', spot: '#fff', accent: '#c88858', pat: 'stripes', weights: [10, 55, 35, 0, 0], desc: '달콤한 디저트 계열 펭귄 전용!', pool: ['파스텔캔디', '크림소다', '메론소다', '핑크 딸기', '바닐라', '초코', '마카롱', '솜사탕', '오렌지에이드', '쿠키앤크림', '캐러멜', '말차', '우유', '복숭아젤리', '라떼', '코튼캔디'] },
  { id: 3, name: '파스텔캔디에그', price: 600, base: '#d6ecff', spot: '#ffc6e6', accent: '#ff8fc8', pat: 'dots', weights: [0, 50, 40, 10, 0], desc: '솜사탕처럼 몽글몽글한 캔디 펭귄!', pool: ['파스텔캔디', '솜사탕', '캔디팝', '코튼캔디', '마카롱'] },
  { id: 4, name: '크림소다에그', price: 500, base: '#c8f7ec', spot: '#fff', accent: '#4cc9b0', pat: 'dots', weights: [0, 55, 40, 5, 0], desc: '톡톡 터지는 소다 펭귄들.', pool: ['크림소다', '메론소다', '레몬소다', '오렌지에이드', '아이스민트', '바다', '민트'] },
  { id: 5, name: '딸기에그', price: 500, base: '#ffc0d0', spot: '#fff', accent: '#e04a7b', pat: 'dots', weights: [0, 55, 40, 5, 0], desc: '새콤달콤 딸기 펭귄!', pool: ['핑크 딸기', '체리블라썸', '분홍', '복숭아', '수박', '복숭아젤리', '벚꽃'] },
  { id: 6, name: '과일에그', price: 700, base: '#ffeaa0', spot: '#8fd070', accent: '#ff9a40', pat: 'stripes', weights: [0, 40, 50, 10, 0], desc: '상큼한 과일 펭귄 모음.', pool: ['망고', '수박', '포도', '복숭아젤리', '오렌지에이드', '레몬', '레몬소다', '연두', '블루베리'] },
  { id: 7, name: '벚꽃에그', price: 900, base: '#ffe6f0', spot: '#ff9cc0', accent: '#ff7aa8', pat: 'stars', weights: [0, 20, 55, 25, 0], desc: '봄바람 가득, 분홍빛 펭귄!', pool: ['체리블라썸', '벚꽃', '분홍', '라벤더', '노을', '마카롱'] },
  { id: 8, name: '레인보우 에그', price: 1500, base: '#fff', spot: '#ff9ec0', accent: '#8ad0ff', pat: 'rainbow', weights: [0, 15, 40, 35, 10], desc: '무지갯빛으로 반짝이는 신비한 알.' },
  { id: 9, name: '크리스탈에그', price: 2000, base: '#d8f4ff', spot: '#fff', accent: '#6ad0ff', pat: 'stars', weights: [0, 0, 30, 55, 15], desc: '반짝반짝 보석 펭귄이 숨어있어요.', pool: ['크리스탈', '진주', '보석', '다이아몬드', '달빛', '홀로그램', '아이스민트'] },
  { id: 10, name: '오로라에그', price: 2500, base: '#bff7e8', spot: '#d0b8ff', accent: '#7ee0ff', pat: 'rainbow', weights: [0, 0, 30, 50, 20], desc: '북극의 오로라를 품은 알.', pool: ['오로라', '크리스탈', '아이스민트', '진주', '홀로그램', '노을'] },
  { id: 11, name: '갤럭시에그', price: 3000, base: '#3b2a8a', spot: '#fff', accent: '#ff8fd0', pat: 'galaxy', weights: [0, 0, 0, 55, 45], desc: '우주를 담은 알! 갤럭시 펭귄 등장!', pool: ['갤럭시', '우주', '별빛', '달빛', '오로라', '보석'] },
  { id: 12, name: '황금에그', price: 5000, base: '#ffe27a', spot: '#fff6c0', accent: '#e0a010', pat: 'stars', weights: [0, 0, 0, 55, 45], desc: '반짝이는 황금빛 알. 전설이 깃들어 있어요.', pool: ['황금', '드래곤', '불사조', '다이아몬드', '네온', '보석'] },
  { id: 13, name: '미스틱에그', price: 8000, base: '#c9a8ff', spot: '#fff', accent: '#ff7ad0', pat: 'galaxy', weights: [0, 0, 0, 40, 60], desc: '가장 신비로운 알. 에픽 이상만 나와요!' },
];

export function drawSpecies(eggId: number): number {
  const e = EGGS[eggId];
  const themes = THEMES.map((t, i) => ({ t, i })).filter((x) => !e.pool || e.pool.includes(x.t.name));
  const cands: { sid: number; w: number }[] = [];
  for (const { i } of themes) {
    for (let v = 0; v < NV; v++) {
      const sid = makeSid(i, v);
      const w = e.weights[speciesTier(sid)];
      if (w > 0) cands.push({ sid, w });
    }
  }
  if (!cands.length) return rnd(TOTAL_SPECIES);
  const total = cands.reduce((a, c) => a + c.w, 0);
  let r = Math.random() * total;
  for (const c of cands) { r -= c.w; if (r <= 0) return c.sid; }
  return cands[0].sid;
}

// ===== 교배 =====
export function breedResult(a: number, b: number): { sid: number; c1: string; c2: string } {
  const ta = a >= 0 ? speciesTheme(a) : rnd(THEMES.length), tb = b >= 0 ? speciesTheme(b) : rnd(THEMES.length);
  const va = a >= 0 ? speciesVar(a) : rnd(NV), vb = b >= 0 ? speciesVar(b) : rnd(NV);
  const r = Math.random();
  let t: number, v: number;
  if (r < 0.28) { t = ta; v = vb; }
  else if (r < 0.56) { t = tb; v = va; }
  else if (r < 0.74) { t = ta; v = va; }
  else if (r < 0.92) { t = tb; v = vb; }
  else if (r < 0.97) { t = rnd(THEMES.length); v = Math.random() < 0.5 ? va : vb; } // 돌연변이
  else { t = Math.random() < 0.5 ? ta : tb; v = rnd(NV); }
  return { sid: makeSid(t, v), c1: THEMES[ta].body, c2: THEMES[tb].body };
}
