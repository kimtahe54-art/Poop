export type Special = 'shop' | 'egg' | 'arcade' | 'aqua' | 'bank' | 'hatch' | 'dex' | 'deco';
export interface BDef {
  id: number; name: string; icon: string; cat: string; price: number; tpl: string; wall: string; roof: string; scale: number; special?: Special;
}

export const CATS: Record<string, { label: string; act: string[]; props: string[]; floor: string; wallTint: string; says: string[] }> = {
  home: { label: '주거', act: ['😴', '📺', '🍵', '🧸'], props: ['🛋️', '🛏️', '🪴', '📺', '🧸', '🕯️'], floor: '#e8c9a0', wallTint: '#ffeedd', says: ['집이 최고야~ 포근해!', '오늘은 뭐 하고 놀까?', '따뜻한 코코아 마실래?'] },
  food: { label: '음식', act: ['😋', '🍽️', '🥄', '👨‍🍳'], props: ['🍰', '🍩', '☕', '🥛', '🍓', '🧁'], floor: '#ffd9b8', wallTint: '#fff0e0', says: ['냠냠! 너무 맛있다!', '신선한 생선이 들어왔어요~', '오늘의 추천 메뉴는 이거!'] },
  school: { label: '학습', act: ['📖', '✏️', '🤔', '💡'], props: ['📚', '🔬', '🌍', '🖍️', '🔭', '🎒'], floor: '#d8c8f0', wallTint: '#f0eaff', says: ['오늘도 열심히 공부해요!', '이 책 정말 재밌어!', '와, 새로운 걸 알았어!'] },
  fun: { label: '놀이', act: ['🎉', '🎶', '🤸', '😆'], props: ['🎈', '🎮', '🎲', '🎪', '🎁', '🎵'], floor: '#ffc8e0', wallTint: '#ffe8f4', says: ['꺄하하! 신난다~', '한 번 더 해볼래!', '다 같이 놀자!'] },
  health: { label: '건강', act: ['🧘', '💪', '💆', '😌'], props: ['💊', '🌿', '🛁', '🧴', '🕯️', '⚖️'], floor: '#cdeee4', wallTint: '#e6fbf5', says: ['건강이 최고예요~', '몸이 가벼워졌어!', '스트레칭 쭈욱~'] },
  work: { label: '일터', act: ['🛠️', '📦', '✂️', '🧹'], props: ['📦', '🧰', '🧺', '📮', '🎣', '🗂️'], floor: '#cfd9e6', wallTint: '#eaf1fa', says: ['오늘도 열심히 일해요!', '배달 완료~!', '바쁘다 바빠!'] },
  magic: { label: '특별', act: ['✨', '🔮', '🌟', '🪄'], props: ['🔮', '🌙', '⭐', '🪄', '💎', '🌈'], floor: '#c9c0f5', wallTint: '#efe9ff', says: ['반짝반짝 마법이야!', '신비로운 기운이 느껴져~', '소원을 빌어봐!'] },
  special: { label: '시설', act: [], props: [], floor: '#fff', wallTint: '#fff', says: [] },
};

// name|icon|cat|template(optional)
const RAW = `아기 이글루|🏠|home|igloo
눈 오두막|🛖|home|house
통나무집|🪵|home|barn
벽돌집|🧱|home|house
파스텔 하우스|🌸|home|round
딸기 하우스|🍓|home|house
민트 하우스|🌿|home|round
레몬 하우스|🍋|home|igloo
구름 집|☁️|home|dome
아파트 타워|🏢|home|tower
별빛 집|⭐|home|round
꽃 집|🌼|home|house
피자 가게|🍕|food|shop
아이스크림 가게|🍦|food|shop
케이크 카페|🍰|food|cake
도넛 가게|🍩|food|shop
초밥 집|🍣|food|pagoda
라면 가게|🍜|food|shop
햄버거 가게|🍔|food|shop
쿠키 하우스|🍪|food|house
팬케이크 카페|🥞|food|cake
핫초코 카페|☕|food|round
빙수 가게|🍧|food|igloo
마카롱 샵|🧁|food|cake
베이커리|🥐|food|shop
딸기 디저트|🍓|food|cake
멜론소다 바|🍈|food|shop
크림소다 카페|🥤|food|round
생선구이 식당|🐟|food|barn
샌드위치 가게|🥪|food|shop
팝콘 가게|🍿|food|tent
펭귄 학교|🏫|school|barn
도서관|📚|school|tower
유치원|🧸|school|house
과학 연구소|🔬|school|dome
천문대|🔭|school|dome
미술관|🎨|school|round
음악 학교|🎼|school|tower
박물관|🏛️|school|pagoda
외국어 학원|🔤|school|house
요리 학원|👩‍🍳|school|barn
놀이공원|🎡|fun|tent
롤러코스터 센터|🎢|fun|tent
회전목마 하우스|🎠|fun|round
풍선 가게|🎈|fun|shop
펭귄 극장|🎬|fun|barn
콘서트홀|🎤|fun|dome
댄스 스튜디오|💃|fun|house
스케이트장|⛸️|fun|igloo
눈썰매장|🛷|fun|barn
스키 롯지|🎿|fun|house
볼링장|🎳|fun|shop
보드게임 카페|🎲|fun|round
서커스 텐트|🎪|fun|tent
노래방|🎶|fun|shop
워터슬라이드|🌊|fun|dome
눈싸움장|❄️|fun|igloo
병원|🏥|health|house
약국|💊|health|shop
온천 스파|♨️|health|pagoda
요가 센터|🧘|health|dome
헬스장|🏋️|health|barn
마사지 숍|💆|health|round
소방서|🚒|work|barn
경찰서|🚓|work|house
우체국|📮|work|shop
시청|🏛|work|tower
공장|🏭|work|barn
어시장|🐠|work|shop
낚시 가게|🎣|work|house
세탁소|🧺|work|round
미용실|✂️|work|shop
옷 가게|👗|work|shop
꽃집|🌷|work|round
선물 가게|🎁|work|shop
장난감 가게|🪀|work|shop
기차역|🚉|work|barn
공항|✈️|work|dome
항구|⚓|work|lighthouse
등대|🗼|work|lighthouse
온실|🌱|magic|dome
오로라 전망대|🌌|magic|lighthouse
얼음 성|🏰|magic|castle
눈사람 공방|⛄|magic|igloo
크리스마스 하우스|🎄|magic|house
산타 하우스|🎅|magic|barn
요정의 집|🧚|magic|round
마법 학교|🪄|magic|castle
보석 가게|💎|magic|shop
달 전망대|🌙|magic|tower
별 관측소|🌟|magic|dome
무지개 정자|🌈|magic|pagoda
용궁|🐉|magic|pagoda
UFO 기지|🛸|magic|dome
로봇 공방|🤖|magic|tower
해적 선술집|🏴‍☠️|magic|barn
닌자 도장|🥷|magic|pagoda
신비의 사원|⛩️|magic|pagoda
풍차 방앗간|🌬️|magic|tower
드림 캐슬|💖|magic|castle`;

const PALS: [string, string][] = [
  ['#fff1f6', '#ff8fb8'], ['#eaf8ff', '#5fb8ff'], ['#fffbe0', '#ffb830'], ['#effff4', '#4cc98a'],
  ['#f3ecff', '#9a6cf0'], ['#fff0e6', '#ff7a5a'], ['#e8fffb', '#2cc7b4'], ['#fff6ea', '#c8844a'],
  ['#f0f4ff', '#6a7cf0'], ['#ffeef0', '#e8506a'], ['#f6ffe8', '#8cc83a'], ['#fdf0ff', '#d85ad0'],
];
const BASE: Record<string, number> = { home: 200, food: 450, school: 600, fun: 900, health: 500, work: 400, magic: 1200 };
const SCALE: Record<string, number> = { igloo: 1, house: 1, round: 1, tower: 1.05, dome: 1.05, shop: 1, castle: 1.25, pagoda: 1.1, tent: 1.1, lighthouse: 1.05, barn: 1.1, cake: 1 };

export const BUILDINGS: BDef[] = RAW.split('\n').map((l, i) => {
  const [name, icon, cat, tpl] = l.split('|');
  const pal = PALS[(i * 5 + (i >> 2)) % PALS.length];
  const mult = 1 + (i % 6) * 0.3;
  return { id: i, name, icon, cat, price: Math.round((BASE[cat] * mult) / 10) * 10, tpl, wall: pal[0], roof: pal[1], scale: SCALE[tpl] || 1 };
});

const SPECIALS: [string, string, Special, string, string, string, number, string][] = [
  ['펭귄 상점', '🛍️', 'shop', 'shop', '#fff0f6', '#ff6fa5', 3000, 'shop'],
  ['에그메이킹 룸', '💞', 'egg', 'round', '#fff0ff', '#e060d0', 4000, 'egg'],
  ['오락실', '🕹️', 'arcade', 'tent', '#eef4ff', '#6a7cf0', 4000, 'arcade'],
  ['아쿠아리움', '🐠', 'aqua', 'dome', '#e6fbff', '#2cb8e8', 5000, 'aqua'],
  ['펭귄 은행', '🏦', 'bank', 'pagoda', '#fffbe0', '#e8a820', 3500, 'bank'],
  ['부화장', '🐣', 'hatch', 'barn', '#fff7e0', '#ff9a40', 3000, 'hatch'],
  ['펭귄 도감관', '📖', 'dex', 'castle', '#f3ecff', '#8a64e0', 4500, 'dex'],
  ['꾸미기 공방', '🎀', 'deco', 'cake', '#fff0f6', '#ff8fb8', 2500, 'deco'],
];
SPECIALS.forEach((s, k) => {
  BUILDINGS.push({ id: 100 + k, name: s[0], icon: s[1], cat: 'special', price: s[6], tpl: s[3], wall: s[4], roof: s[5], scale: (SCALE[s[3]] || 1) * 1.1, special: s[2] });
});

export const SPECIAL_IDS: Record<Special, number> = { shop: 100, egg: 101, arcade: 102, aqua: 103, bank: 104, hatch: 105, dex: 106, deco: 107 };
export const NBUILD = BUILDINGS.length;
