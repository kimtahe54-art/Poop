import { useMemo } from 'react';
import type { CSSProperties } from 'react';
import { Modal, Coin } from './ui';
import { SEA, SeaArt, SeaDefs, SeaPreview } from './components/SeaArt';
import { buySea, toast, useG } from './store';
import { sfx } from './audio';

const hash = (n: number) => { let h = n * 2654435761 >>> 0; h ^= h >>> 13; return h >>> 0; };

export function AquariumPanel({ onClose }: { onClose: () => void }) {
  const s = useG();
  const fishes = useMemo(() => {
    const out: { id: number; k: number }[] = [];
    Object.entries(s.sea).forEach(([id, n]) => { for (let k = 0; k < n; k++) out.push({ id: +id, k }); });
    return out.slice(0, 45);
  }, [s.sea]);
  const total = Object.values(s.sea).reduce((a, b) => a + b, 0);
  const kinds = Object.keys(s.sea).length;
  return (
    <Modal title="아쿠아리움" icon="🐠" onClose={onClose} tone="sky" wide>
      <div className="relative rounded-3xl overflow-hidden border-4 border-white shadow-lg">
        <svg viewBox="0 0 800 420" className="w-full block bg-sky-400">
          <defs>
            <linearGradient id="aqw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7fe0ff" /><stop offset=".6" stopColor="#3aa8ee" /><stop offset="1" stopColor="#1e6cc0" /></linearGradient>
            <linearGradient id="ray" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fff" stopOpacity=".5" /><stop offset="1" stopColor="#fff" stopOpacity="0" /></linearGradient>
          </defs>
          <SeaDefs />
          <rect width="800" height="420" fill="url(#aqw)" />
          {[80, 260, 470, 650].map((x, i) => <path key={x} className="tw" style={{ animationDuration: 4 + i + 's' }} d={`M${x} 0 L${x + 90} 0 L${x + 30} 420 L${x - 80} 420Z`} fill="url(#ray)" opacity=".4" />)}
          {/* 모래 + 산호 */}
          <path d="M0 380 Q200 350 400 372 T800 364 V420 H0Z" fill="#ffe8b8" /><path d="M0 396 Q250 380 500 396 T800 390 V420 H0Z" fill="#ffd89a" />
          {[[60, '#ff8ab8'], [150, '#ffb44a'], [330, '#b08aff'], [560, '#ff7a8a'], [700, '#5ae0b8'], [770, '#ff9ad0']].map(([x, c], i) => (
            <g key={i} transform={`translate(${x} 380)`} style={{ transformOrigin: `${x}px 380px` }}>
              <path d="M0 0 Q-10 -30 -22 -44 M0 0 Q0 -40 0 -60 M0 0 Q12 -30 24 -40" stroke={c as string} strokeWidth="9" strokeLinecap="round" fill="none" />
              <circle cx="-22" cy="-46" r="6" fill={c as string} /><circle cx="0" cy="-62" r="7" fill={c as string} /><circle cx="24" cy="-42" r="6" fill={c as string} />
            </g>
          ))}
          {[[240, 380], [610, 378]].map((p, i) => <g key={i} transform={`translate(${p[0]} ${p[1]})`}><ellipse cx="0" cy="-8" rx="22" ry="12" fill="#fff" stroke="#f0c8d8" strokeWidth="3" /><path d="M-20 -10 Q0 -34 20 -10" fill="#ffc8dc" /></g>)}
          {Array.from({ length: 16 }, (_, i) => <circle key={i} cx={(i * 53) % 800} cy={400} r={3 + (i % 4)} fill="#fff" opacity=".6" style={{ animation: `bubbleUp ${5 + (i % 5)}s linear infinite`, animationDelay: `${-i * 0.7}s` }} />)}
          {fishes.map((f) => {
            const d = SEA[f.id]; const h = hash(f.id * 31 + f.k * 7 + 1);
            const bottom = d.zone === 'bottom';
            const y = bottom ? 350 + (h % 20) : 70 + (h % 230);
            const x0 = 60 + (h >> 4) % 200;
            const dist = 280 + (h >> 8) % 280; const T = (bottom ? 22 : 9) + (h >> 12) % 10;
            return (
              <g key={f.id + '-' + f.k} transform={`translate(${x0} ${y})`}>
                <g style={{ animation: `walkx ${T}s ease-in-out infinite`, animationDelay: `${-(h % 7)}s`, ['--d' as string]: dist + 'px' } as CSSProperties}>
                  <g style={{ animation: `flipx ${T}s linear infinite`, animationDelay: `${-(h % 7)}s` }}>
                    <g style={{ animation: `swimy ${3 + (h % 3)}s ease-in-out infinite`, ['--dy' as string]: (bottom ? -2 : 18 + (h % 20)) + 'px' } as CSSProperties}>
                      <SeaArt d={d} />
                    </g>
                  </g>
                </g>
              </g>
            );
          })}
          {!fishes.length && <text x="400" y="200" textAnchor="middle" fontSize="26" fontWeight="bold" fill="#fff">아직 텅 비었어요. 아래에서 바다 친구들을 데려와요!</text>}
        </svg>
        <div className="absolute top-2 left-3 bg-white/80 rounded-full px-3 py-0.5 text-sm font-bold text-sky-600">🐟 {total}마리 · {kinds}/{SEA.length}종</div>
      </div>
      <div className="flex items-center justify-between my-3"><span className="font-bold text-sky-600">🛒 바다 친구 상점 (코인으로 구매)</span><Coin n={s.coins} className="text-amber-600" /></div>
      <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-2">
        {SEA.map((d) => (
          <div key={d.id} className="relative rounded-2xl bg-gradient-to-b from-sky-100 to-white border-4 border-sky-100 p-1.5 flex flex-col items-center text-center">
            <SeaPreview d={d} size={78} />
            <div className="text-[11px] font-bold text-sky-700 leading-tight h-7 flex items-center">{d.name}</div>
            {s.sea[d.id] ? <span className="absolute top-1 right-1 text-[10px] bg-pink-400 text-white rounded-full px-1.5">x{s.sea[d.id]}</span> : null}
            <button className="btn-main px-2 py-0.5 mt-1 text-xs w-full" disabled={s.coins < d.price} onClick={() => { if (buySea(d.id)) { sfx('buy'); toast(`${d.name} 입양! 🐠`); } }}><Coin n={d.price} className="text-white justify-center" /></button>
          </div>
        ))}
      </div>
    </Modal>
  );
}
