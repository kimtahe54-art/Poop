import { useMemo, useState } from 'react';
import type { CSSProperties } from 'react';
import { Penguin } from './components/Penguin';
import { BuildingPreview, shade } from './components/BuildingArt';
import { BUILDINGS, CATS } from './data/buildings';
import { PItem, specOf, useG } from './store';
import { sfx } from './audio';
import { speciesName } from './data/penguinData';

const hash = (s: string) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; };

export function Interior({ item, onClose }: { item: PItem; onClose: () => void }) {
  const s = useG();
  const def = BUILDINGS[item.t];
  const cat = CATS[def.cat];
  const [say, setSay] = useState<{ uid: string; text: string; n: number } | null>(null);
  const seed = hash(item.id);
  const residents = useMemo(() => {
    const pens = s.pens; if (!pens.length) return [];
    const n = Math.min(pens.length, 2 + (seed % 3));
    const start = seed % pens.length;
    return Array.from({ length: n }, (_, i) => pens[(start + i * 3) % pens.length]).filter((p, i, a) => a.indexOf(p) === i);
  }, [s.pens, seed]);

  const props = useMemo(() => {
    const out: { e: string; x: number; y: number; s: number }[] = [];
    const list = cat.props;
    for (let i = 0; i < 6; i++) out.push({ e: list[(seed + i) % list.length], x: 70 + i * 128 + ((seed >> i) % 20), y: 200, s: 40 });
    return out;
  }, [seed, cat]);
  const floorProps = useMemo(() => [0, 1, 2].map((i) => ({ e: cat.props[(seed + i * 2 + 1) % cat.props.length], x: 60 + i * 340 + (seed % 60), y: 410 + (i % 2) * 40, s: 54 + (i % 2) * 10 })), [seed, cat]);
  const stripe = shade(def.roof, 0.78);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-2 bg-sky-900/50 backdrop-blur-[2px]" onPointerDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="pop-in w-full max-w-4xl rounded-[28px] border-[5px] border-white bg-white shadow-2xl overflow-hidden">
        <div className="flex items-center gap-3 px-4 py-2 text-white bg-gradient-to-r from-pink-300 to-sky-300">
          <div className="-my-2"><BuildingPreview def={def} size={44} /></div>
          <h2 className="text-xl font-bold flex-1" style={{ textShadow: '0 2px 0 #0002' }}>{def.icon} {def.name} <span className="text-sm opacity-90">· {cat.label}</span></h2>
          <span className="text-sm bg-white/30 rounded-full px-3">주민 {residents.length}명</span>
          <button className="w-9 h-9 rounded-full bg-white text-pink-500 font-bold" onClick={() => { sfx('click'); onClose(); }}>✕</button>
        </div>
        <svg viewBox="0 0 800 500" className="w-full block" style={{ maxHeight: '78vh' }}>
          <defs>
            <linearGradient id="flr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={shade(cat.floor, 0.1)} /><stop offset="1" stopColor={shade(cat.floor, -0.15)} /></linearGradient>
            <linearGradient id="win" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#8fd8ff" /><stop offset="1" stopColor="#e8f8ff" /></linearGradient>
          </defs>
          <rect width="800" height="330" fill={cat.wallTint} />
          {Array.from({ length: 16 }, (_, i) => <rect key={i} x={i * 50} y="0" width="25" height="330" fill={stripe} opacity=".5" />)}
          <rect y="300" width="800" height="22" fill={shade(cat.floor, -0.25)} />
          <rect y="322" width="800" height="178" fill="url(#flr)" />
          {Array.from({ length: 9 }, (_, i) => <path key={i} d={`M${-100 + i * 150} 500 L${200 + i * 50} 322`} stroke={shade(cat.floor, -0.25)} strokeWidth="2" opacity=".5" />)}
          <path d="M0 400 H800 M0 460 H800" stroke={shade(cat.floor, -0.25)} strokeWidth="2" opacity=".3" />
          {/* 창문 */}
          {[130, 670].map((x) => (
            <g key={x}>
              <rect x={x - 62} y="40" width="124" height="130" rx="14" fill="url(#win)" stroke={def.roof} strokeWidth="8" />
              <path d={`M${x} 40 V170 M${x - 62} 105 H${x + 62}`} stroke={def.roof} strokeWidth="5" />
              {[0, 1, 2, 3, 4].map((k) => <circle key={k} cx={x - 44 + k * 22} cy={0} r="3" fill="#fff" style={{ animation: `fall ${4 + k}s linear infinite`, animationDelay: `${-k}s` }} transform="translate(0 40)" />)}
              <path d={`M${x - 70} 36 Q${x} 64 ${x + 70} 36 L${x + 70} 30 Q${x} 50 ${x - 70} 30Z`} fill={def.roof} opacity=".6" />
            </g>
          ))}
          {/* 간판 */}
          <g transform="translate(400 70)">
            <rect x="-150" y="-34" width="300" height="68" rx="20" fill="#fff" stroke={def.roof} strokeWidth="6" />
            <text x="-110" y="12" textAnchor="middle" fontSize="42">{def.icon}</text>
            <text x="20" y="10" textAnchor="middle" fontSize="28" fontWeight="bold" fill={shade(def.roof, -0.2)}>{def.name}</text>
          </g>
          {/* 선반 */}
          <rect x="30" y="226" width="740" height="12" rx="6" fill={shade(cat.floor, -0.2)} /><rect x="30" y="236" width="740" height="6" fill="#0001" />
          {props.map((p, i) => <text key={i} x={p.x} y={p.y + 14} fontSize={p.s} textAnchor="middle" style={{ animation: `bob ${3 + (i % 3)}s ease-in-out infinite` }}>{p.e}</text>)}
          <ellipse cx="400" cy="420" rx="230" ry="46" fill={def.roof} opacity=".22" /><ellipse cx="400" cy="420" rx="190" ry="34" fill="#fff" opacity=".35" />
          {floorProps.map((p, i) => <text key={i} x={p.x} y={p.y} fontSize={p.s} textAnchor="middle">{p.e}</text>)}
          {/* 주민 */}
          {residents.map((p, i) => {
            const h = hash(p.uid + item.id);
            const y = 380 + (i * 37) % 100;
            const x0 = 110 + ((h % 400) + i * 130) % 500;
            const walker = i % 2 === 0;
            const d = 80 + (h % 120), T = 8 + (h % 6);
            const act = cat.act[(h >> 3) % cat.act.length];
            const mine = say && say.uid === p.uid;
            return (
              <g key={p.uid} transform={`translate(${x0} ${y})`} onPointerDown={() => { sfx('squeak'); const t = cat.says[Math.floor(Math.random() * cat.says.length)]; setSay({ uid: p.uid, text: t, n: Math.random() }); setTimeout(() => setSay((c) => (c && c.n ? null : c)), 2600); }} style={{ cursor: 'pointer' }}>
                <g style={walker ? ({ animation: `walkx ${T}s ease-in-out infinite`, ['--d' as string]: d + 'px' } as CSSProperties) : undefined}>
                  <g style={walker ? { animation: `flipx ${T}s linear infinite` } : undefined}>
                    <ellipse cx="0" cy="0" rx="38" ry="8" fill="#000" opacity=".15" />
                    <g transform="translate(-55 -128)"><g style={{ animation: `hop ${walker ? 0.6 : 1.4}s ease-in-out infinite` }}><Penguin spec={specOf(p)} size={110} /></g></g>
                  </g>
                  <text x="0" y="-146" textAnchor="middle" fontSize="30" style={{ animation: 'bob 1.6s ease-in-out infinite' }}>{act}</text>
                  <text x="0" y="22" textAnchor="middle" fontSize="13" fontWeight="bold" fill="#fff" stroke="#0005" strokeWidth="3" paintOrder="stroke">{p.name}</text>
                  {mine && (
                    <g transform="translate(0 -176)" className="pop-in"><rect x="-90" y="-26" width="180" height="40" rx="16" fill="#fff" stroke="#ff9ec8" strokeWidth="3" /><text x="0" y="0" textAnchor="middle" fontSize="13" fontWeight="bold" fill="#e0558f">{say!.text}</text><text x="0" y="-12" textAnchor="middle" fontSize="0">.</text></g>
                  )}
                </g>
              </g>
            );
          })}
          {!residents.length && <g><rect x="200" y="360" width="400" height="60" rx="30" fill="#fff" opacity=".9" /><text x="400" y="398" textAnchor="middle" fontSize="20" fontWeight="bold" fill="#e0558f">아직 주민이 없어요! 알을 부화시켜보세요 🥚</text></g>}
        </svg>
        <div className="px-4 py-2 text-sm text-gray-500 bg-pink-50 flex flex-wrap gap-x-4">
          {residents.length ? residents.map((p) => <span key={p.uid}>🐧 <b className="text-pink-500">{p.name}</b> ({p.custom ? '나만의 펭귄' : speciesName(p.sid).replace(' 펭귄', '')})</span>) : <span>건물을 눌러 구경해요</span>}
          <span className="ml-auto">펭귄을 누르면 말을 걸어요!</span>
        </div>
      </div>
    </div>
  );
}
