import { useState } from 'react';
import { Modal, Coin } from './ui';
import { GAMES, GameDef } from './games';
import { earn, setBest, toast, useG } from './store';
import { sfx } from './audio';

function Shell({ g, onExit }: { g: GameDef; onExit: () => void }) {
  const [stage, setStage] = useState<'intro' | 'play' | 'result'>('intro');
  const [run, setRun] = useState(0);
  const [res, setRes] = useState({ score: 0, coins: 0 });
  const s = useG();
  const Comp = g.comp;
  const finish = (score: number, coins: number) => {
    const c = Math.max(0, Math.round(coins));
    earn(c); setBest(g.id, score); setRes({ score, coins: c }); setStage('result');
    sfx(c > 0 ? 'win' : 'lose'); if (c > 0) toast(`🪙 ${c} 코인 획득!`);
  };
  return (
    <Modal title={g.title} icon={g.icon} onClose={onExit} tone="purple" wide={stage === 'play'}>
      {stage === 'intro' && (
        <div className="text-center py-6">
          <div className="text-7xl mb-3" style={{ animation: 'bobBig 2s infinite' }}>{g.icon}</div>
          <div className="inline-block px-3 py-0.5 rounded-full bg-fuchsia-100 text-fuchsia-600 text-sm font-bold mb-2">{g.type}</div>
          <p className="text-lg font-bold text-pink-600">{g.desc}</p>
          <p className="mt-3 text-gray-600 max-w-md mx-auto bg-white rounded-2xl border-2 border-pink-100 p-3 text-sm">📖 {g.how}</p>
          <p className="mt-2 text-sm text-gray-400">내 최고 기록: {s.best[g.id] || 0}</p>
          <div className="flex justify-center gap-3 mt-5">
            <button className="btn-cute px-6 py-2 text-pink-500 font-bold" onClick={onExit}>뒤로</button>
            <button className="btn-main px-10 py-2 text-xl" onClick={() => { sfx('click'); setStage('play'); }}>▶ 시작!</button>
          </div>
        </div>
      )}
      {stage === 'play' && <div key={run} className="flex flex-col items-center"><Comp onFinish={finish} /></div>}
      {stage === 'result' && (
        <div className="text-center py-8 pop-in">
          <div className="text-6xl mb-2">{res.coins >= 100 ? '🏆' : res.coins > 0 ? '🎉' : '💧'}</div>
          <div className="text-2xl font-bold text-pink-600">게임 끝!</div>
          <div className="mt-2 text-gray-600">점수 <b className="text-sky-600 text-xl">{res.score}</b></div>
          <div className="mt-2"><Coin n={res.coins} className="text-3xl text-amber-500" /></div>
          <div className="text-sm text-gray-400 mt-1">최고 기록 {s.best[g.id] || 0}</div>
          <div className="flex justify-center gap-3 mt-6">
            <button className="btn-cute px-6 py-2 text-pink-500 font-bold" onClick={onExit}>목록으로</button>
            <button className="btn-main px-8 py-2 text-lg" onClick={() => { setRun(run + 1); setStage('play'); }}>🔄 다시 하기</button>
          </div>
        </div>
      )}
    </Modal>
  );
}

export function ArcadePanel({ onClose }: { onClose: () => void }) {
  const s = useG();
  const [game, setGame] = useState<GameDef | null>(null);
  const [type, setType] = useState('전체');
  if (game) return <Shell g={game} onExit={() => setGame(null)} />;
  const types = ['전체', ...Array.from(new Set(GAMES.map((g) => g.type)))];
  return (
    <Modal title="오락실" icon="🕹️" onClose={onClose} tone="purple" wide>
      <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
        <p className="text-sm font-bold text-fuchsia-600">미니게임 {GAMES.length}종! 잘하면 코인을 듬뿍 받아요.</p>
        <Coin n={s.coins} className="text-amber-600" />
      </div>
      <div className="flex flex-wrap gap-1.5 mb-3">{types.map((t) => <button key={t} onClick={() => setType(t)} className={'px-3 py-0.5 rounded-full text-xs font-bold ' + (type === t ? 'bg-fuchsia-400 text-white' : 'bg-white border border-fuchsia-200 text-fuchsia-500')}>{t}</button>)}</div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {GAMES.filter((g) => type === '전체' || g.type === type).map((g) => (
          <button key={g.id} onClick={() => { sfx('click'); setGame(g); }} className="rounded-3xl bg-white border-4 border-fuchsia-100 p-3 flex flex-col items-center text-center hover:scale-105 hover:border-pink-300 transition">
            <div className="text-4xl">{g.icon}</div>
            <div className="font-bold text-pink-600 mt-1 text-sm">{g.title}</div>
            <div className="text-[11px] text-gray-500 leading-tight min-h-[28px]">{g.desc}</div>
            <div className="mt-1 text-[10px] flex gap-1"><span className="bg-fuchsia-100 text-fuchsia-600 rounded-full px-1.5">{g.type}</span>{s.best[g.id] ? <span className="bg-amber-100 text-amber-600 rounded-full px-1.5">🏅{s.best[g.id]}</span> : null}</div>
          </button>
        ))}
      </div>
    </Modal>
  );
}
