import { memo, useId } from 'react';
import type { ReactNode } from 'react';
import type { PSpec } from '../data/penguinData';

export const EYE_COLORS = ['#5b3df5', '#1f8fff', '#14b88a', '#ff5d8f', '#8a5a2b', '#ff9d1f'];

const starPts = (cx: number, cy: number, r: number) => {
  const p: string[] = [];
  for (let i = 0; i < 10; i++) {
    const a = (Math.PI / 5) * i - Math.PI / 2;
    const rr = i % 2 ? r * 0.45 : r;
    p.push(`${(cx + Math.cos(a) * rr).toFixed(1)},${(cy + Math.sin(a) * rr).toFixed(1)}`);
  }
  return p.join(' ');
};
const Heart = ({ x, y, s, fill, o = 1 }: { x: number; y: number; s: number; fill: string; o?: number }) => (
  <path transform={`translate(${x} ${y}) scale(${s})`} d="M0 5 C-9 -1 -7 -9 0 -4 C7 -9 9 -1 0 5Z" fill={fill} opacity={o} />
);
const Sparkle = ({ x, y, s, fill = '#fff', o = 1, d = 0 }: { x: number; y: number; s: number; fill?: string; o?: number; d?: number }) => (
  <path className="tw" style={{ animationDelay: d + 's' }} transform={`translate(${x} ${y}) scale(${s})`} d="M0 -8 Q1 -1 8 0 Q1 1 0 8 Q-1 1 -8 0 Q-1 -1 0 -8Z" fill={fill} opacity={o} />
);

const BODY_PTS = [[56, 150], [146, 148], [60, 186], [144, 184], [52, 122], [150, 124], [78, 205], [124, 205]];
const HEAD_PTS = [[56, 40], [84, 28], [116, 28], [144, 40], [100, 42], [42, 66], [158, 66]];

function pattern(kind: string, color: string, pts: number[][], bands: number[]): ReactNode {
  switch (kind) {
    case 'stars': return pts.map((p, i) => <polygon key={i} points={starPts(p[0], p[1], 8)} fill={color} opacity={0.85} />);
    case 'hearts': return pts.map((p, i) => <Heart key={i} x={p[0]} y={p[1]} s={1.1} fill={color} o={0.85} />);
    case 'dots': return pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r={5.5} fill={color} opacity={0.75} />);
    case 'stripes': return bands.map((y, i) => <rect key={i} x={0} y={y} width={200} height={9} fill={color} opacity={0.7} />);
    default: return null;
  }
}

function accessory(acc: string, a1: string, a2: string, outline: string, body: string, ids: string): { back?: ReactNode; front?: ReactNode } {
  const gold = `url(#${ids}g)`;
  switch (acc) {
    case 'bow':
      return { front: (
        <g transform="translate(140 36) rotate(18)">
          <path d="M0 0 C-22 -18 -30 6 -24 12 C-18 18 -8 8 0 0Z" fill={a1} stroke="#0002" strokeWidth="1.5" />
          <path d="M0 0 C22 -18 30 6 24 12 C18 18 8 8 0 0Z" fill={a1} stroke="#0002" strokeWidth="1.5" />
          <path d="M-18 -4 Q-12 -2 -6 2 M18 -4 Q12 -2 6 2" stroke={a2} strokeWidth="2" fill="none" opacity=".8" />
          <circle r="6.5" fill={a1} stroke="#0002" strokeWidth="1.5" /><circle cx="-2" cy="-2" r="2" fill="#fff" opacity=".7" />
        </g>) };
    case 'crown':
      return { front: (
        <g transform="translate(0 -2)">
          <path d="M68 40 L72 8 L88 24 L100 2 L112 24 L128 8 L132 40 Q100 48 68 40Z" fill={gold} stroke="#b07800" strokeWidth="2.5" strokeLinejoin="round" />
          <circle cx="72" cy="8" r="4.5" fill="#ff5f9e" stroke="#fff" strokeWidth="1" /><circle cx="100" cy="2" r="5" fill="#5fd0ff" stroke="#fff" strokeWidth="1" /><circle cx="128" cy="8" r="4.5" fill="#ff5f9e" stroke="#fff" strokeWidth="1" />
          <circle cx="100" cy="36" r="4" fill="#ff5f9e" /><path d="M72 36 Q100 42 128 36" stroke="#fff8" strokeWidth="2" fill="none" />
        </g>) };
    case 'beanie':
      return { front: (
        <g>
          <path d="M40 56 C34 -2 166 -2 160 56 Z" fill={a1} stroke="#0003" strokeWidth="2" />
          <path d="M58 44 C60 24 78 14 100 12 M100 12 L100 52 M80 16 L76 52 M120 16 L124 52 M140 28 L146 52" stroke={a2} strokeWidth="2.5" fill="none" opacity=".45" />
          <rect x="34" y="42" width="132" height="18" rx="9" fill={a2} stroke="#0003" strokeWidth="2" />
          <path d="M44 51 H156" stroke={a1} strokeWidth="3" strokeDasharray="3 6" opacity=".6" />
          <circle cx="100" cy="6" r="12" fill={a2} stroke="#0003" strokeWidth="2" /><circle cx="96" cy="2" r="4" fill="#fff" opacity=".7" />
        </g>) };
    case 'glasses':
      return { front: (
        <g fill="#fff" fillOpacity=".18" stroke={a1} strokeWidth="4">
          <circle cx="72" cy="88" r="23" /><circle cx="128" cy="88" r="23" /><path d="M95 86 Q100 80 105 86" fill="none" /><path d="M49 82 L36 76 M151 82 L164 76" fill="none" strokeLinecap="round" />
          <path d="M58 76 Q66 70 76 72" stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" opacity=".9" />
        </g>) };
    case 'scarf':
      return { front: (
        <g>
          <path d="M120 142 L136 190 L116 196 L104 148Z" fill={a2} stroke="#0003" strokeWidth="2" />
          <path d="M124 160 L132 158 M128 174 L136 172" stroke={a1} strokeWidth="5" />
          <path d="M48 128 Q100 160 152 128 L150 146 Q100 176 50 146Z" fill={a1} stroke="#0003" strokeWidth="2.5" strokeLinejoin="round" />
          <path d="M66 140 L68 156 M86 148 L87 164 M110 148 L110 164 M130 142 L131 156" stroke={a2} strokeWidth="5" opacity=".9" />
        </g>) };
    case 'flower':
      return { front: (
        <g transform="translate(142 34)">
          {[0, 72, 144, 216, 288].map((r) => <ellipse key={r} cx="0" cy="-10" rx="7.5" ry="10" fill={a1} stroke="#0002" strokeWidth="1.2" transform={`rotate(${r})`} />)}
          <circle r="6.5" fill="#ffd84a" stroke="#d09a10" strokeWidth="1.5" /><circle cx="-2" cy="-2" r="2" fill="#fff" opacity=".8" />
        </g>) };
    case 'halo':
      return { front: (
        <g className="tw" style={{ animationDuration: '3s' }}>
          <ellipse cx="100" cy="4" rx="32" ry="8" fill="none" stroke="#ffe27a" strokeWidth="6" />
          <ellipse cx="100" cy="4" rx="32" ry="8" fill="none" stroke="#fff6c0" strokeWidth="2" />
        </g>) };
    case 'party':
      return { front: (
        <g>
          <path d="M100 -16 L66 46 Q100 56 134 46Z" fill={a1} stroke="#0003" strokeWidth="2" />
          <path d="M88 8 L112 8 M80 24 L120 24 M74 36 L126 36" stroke={a2} strokeWidth="5" opacity=".85" />
          <circle cx="100" cy="-16" r="8" fill="#ffd84a" stroke="#0003" strokeWidth="1.5" />
          <circle cx="92" cy="16" r="3" fill="#fff" /><circle cx="108" cy="30" r="3" fill="#fff" />
        </g>) };
    case 'phones':
      return { front: (
        <g>
          <path d="M32 84 C28 -6 172 -6 168 84" fill="none" stroke={a1} strokeWidth="9" strokeLinecap="round" />
          <path d="M40 60 C46 14 154 14 160 60" fill="none" stroke="#fff6" strokeWidth="2.5" />
          <rect x="18" y="66" width="24" height="42" rx="12" fill={a2} stroke={a1} strokeWidth="5" />
          <rect x="158" y="66" width="24" height="42" rx="12" fill={a2} stroke={a1} strokeWidth="5" />
          <circle cx="30" cy="87" r="5" fill={a1} /><circle cx="170" cy="87" r="5" fill={a1} />
        </g>) };
    case 'pirate':
      return { front: (
        <g>
          <path d="M34 62 C36 4 164 4 166 62 C140 48 60 48 34 62Z" fill="#2a2a3a" stroke="#000" strokeWidth="2" />
          {[[60, 36], [90, 22], [120, 24], [146, 40], [100, 40]].map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="3.5" fill="#fff" />)}
          <path d="M160 52 L186 66 L166 70Z" fill="#2a2a3a" />
          <ellipse cx="72" cy="90" rx="20" ry="21" fill="#17171f" stroke="#444" strokeWidth="2" />
          <path d="M52 78 L34 56 M92 78 L124 50" stroke="#17171f" strokeWidth="3.5" />
          <path d="M66 86 L78 98 M78 86 L66 98" stroke="#ddd" strokeWidth="3" strokeLinecap="round" />
        </g>) };
    case 'chef':
      return { front: (
        <g fill="#fff" stroke="#d6dde6" strokeWidth="2.5">
          <circle cx="68" cy="14" r="20" /><circle cx="100" cy="2" r="24" /><circle cx="132" cy="14" r="20" />
          <rect x="62" y="22" width="76" height="30" rx="8" />
          <path d="M80 28 V48 M100 28 V48 M120 28 V48" stroke="#e6ebf2" strokeWidth="2.5" fill="none" />
        </g>) };
    case 'wizard':
      return { front: (
        <g>
          <path d="M104 -26 C98 4 90 24 52 50 Q100 62 148 50 C116 28 108 4 104 -26Z" fill={a1} stroke="#0003" strokeWidth="2.5" />
          <ellipse cx="100" cy="50" rx="62" ry="11" fill={a1} stroke="#0003" strokeWidth="2.5" />
          <path d="M60 46 Q100 56 140 46" stroke="#ffd84a" strokeWidth="4" fill="none" />
          <polygon points={starPts(98, 24, 10)} fill="#ffe27a" stroke="#c89000" strokeWidth="1.2" />
          <circle cx="116" cy="10" r="2.5" fill="#fff" /><circle cx="86" cy="38" r="2" fill="#fff" />
        </g>) };
    case 'cat':
      return { back: (
        <g stroke={outline} strokeWidth="3" strokeLinejoin="round">
          <path d="M40 58 L42 8 L82 30Z" fill={body} /><path d="M160 58 L158 8 L118 30Z" fill={body} />
          <path d="M48 40 L49 20 L66 30Z" fill="#ffb3c7" stroke="none" /><path d="M152 40 L151 20 L134 30Z" fill="#ffb3c7" stroke="none" />
        </g>) };
    case 'bear':
      return { back: (
        <g stroke={outline} strokeWidth="3">
          <circle cx="46" cy="36" r="18" fill={body} /><circle cx="154" cy="36" r="18" fill={body} />
          <circle cx="46" cy="38" r="9" fill="#ffc9d6" stroke="none" /><circle cx="154" cy="38" r="9" fill="#ffc9d6" stroke="none" />
        </g>) };
    case 'bunny':
      return { back: (
        <g stroke={outline} strokeWidth="3">
          <ellipse cx="68" cy="-4" rx="14" ry="38" fill={body} transform="rotate(-12 68 30)" /><ellipse cx="132" cy="-4" rx="14" ry="38" fill={body} transform="rotate(12 132 30)" />
          <ellipse cx="68" cy="-2" rx="6.5" ry="28" fill="#ffc0d2" stroke="none" transform="rotate(-12 68 30)" /><ellipse cx="132" cy="-2" rx="6.5" ry="28" fill="#ffc0d2" stroke="none" transform="rotate(12 132 30)" />
        </g>) };
    case 'horn':
      return { front: (
        <g>
          <path d="M90 30 L100 -22 L110 30Z" fill={gold} stroke="#b07800" strokeWidth="2" strokeLinejoin="round" />
          <path d="M92 20 L108 14 M94 8 L106 3 M96 -4 L104 -8" stroke="#fff9" strokeWidth="2.5" />
          <Sparkle x={122} y={-8} s={0.9} fill="#fff7b0" /><Sparkle x={78} y={4} s={0.7} fill="#ffd0f0" d={0.7} />
        </g>) };
    case 'sparkles':
      return { front: (
        <g>
          <Sparkle x={36} y={30} s={1.5} fill="#fff6a0" /><Sparkle x={168} y={20} s={1.2} fill="#ffd0f0" d={0.5} />
          <Sparkle x={24} y={140} s={1} fill="#c8f0ff" d={1} /><Sparkle x={178} y={150} s={1.4} fill="#fff6a0" d={1.4} /><Sparkle x={100} y={-6} s={1.1} fill="#fff" d={0.3} />
        </g>) };
    default: return {};
  }
}

interface Props { spec: PSpec; size?: number; still?: boolean; idp?: string; className?: string; style?: React.CSSProperties }

export const Penguin = memo(function Penguin({ spec, size = 120, still, idp, className, style }: Props) {
  const rid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const id = idp || 'pg' + rid;
  const { body, light, outline, belly, cheek, fx, acc, pat, eye, a1, a2 } = spec;
  const delay = (parseInt(rid.slice(-3), 36) % 40) / 10;
  const ac = accessory(acc, a1, a2, outline, body, id);
  const eyeCol = EYE_COLORS[eye % 6];
  const patCol = fx === 'galaxy' ? '#fff' : a1;
  const blinkCls = still ? '' : 'blink';
  const blinkStyle = { animationDelay: delay + 's' };

  let stops: ReactNode;
  if (fx === 'rainbow') stops = <><stop offset="0" stopColor="#ff9aa8" /><stop offset=".25" stopColor="#ffd08a" /><stop offset=".45" stopColor="#fff09a" /><stop offset=".65" stopColor="#a8f0a8" /><stop offset=".82" stopColor="#9ad8ff" /><stop offset="1" stopColor="#c4a8ff" /></>;
  else if (fx === 'aurora') stops = <><stop offset="0" stopColor="#8fffd8" /><stop offset=".5" stopColor="#9ad0ff" /><stop offset="1" stopColor="#d0a8ff" /></>;
  else if (fx === 'gold') stops = <><stop offset="0" stopColor="#fff6b0" /><stop offset=".5" stopColor="#ffd24a" /><stop offset="1" stopColor="#e0a010" /></>;
  else if (fx === 'galaxy') stops = <><stop offset="0" stopColor={light} /><stop offset=".55" stopColor={body} /><stop offset="1" stopColor={outline} /></>;
  else stops = <><stop offset="0" stopColor={light} /><stop offset="1" stopColor={body} /></>;
  const linear = fx === 'rainbow' || fx === 'aurora' || fx === 'gold';
  const bodyFill = `url(#${id}b)`;
  const stroke = fx === 'gold' ? '#c88a00' : outline;

  return (
    <svg viewBox="0 -28 200 258" width={size} height={size * 258 / 200} className={className} style={style} overflow="visible">
      <defs>
        {linear ? <linearGradient id={id + 'b'} x1="0" y1="0" x2="1" y2="1">{stops}</linearGradient> : <radialGradient id={id + 'b'} cx=".35" cy=".25" r=".95">{stops}</radialGradient>}
        <radialGradient id={id + 'f'} cx=".4" cy=".3" r=".9"><stop offset="0" stopColor="#fff" /><stop offset="1" stopColor={belly} /></radialGradient>
        <linearGradient id={id + 'o'} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#ffd96a" /><stop offset="1" stopColor="#ffa92a" /></linearGradient>
        <linearGradient id={id + 'g'} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#fff2a0" /><stop offset=".5" stopColor="#ffd24a" /><stop offset="1" stopColor="#e0a010" /></linearGradient>
        <clipPath id={id + 'cb'}><path d="M100 100 C55 100 38 150 42 180 C46 208 70 214 100 214 C130 214 154 208 158 180 C162 150 145 100 100 100Z" /></clipPath>
        <clipPath id={id + 'ch'}><ellipse cx="100" cy="78" rx="68" ry="62" /></clipPath>
      </defs>
      {/* 그림자 */}
      <ellipse cx="100" cy="218" rx="56" ry="9" fill="#2a4a6a" opacity=".18" />
      {/* 뒤쪽 장신구 */}
      {ac.back}
      {/* 발 */}
      <g stroke="#e08a10" strokeWidth="2.5">
        <ellipse cx="70" cy="209" rx="23" ry="10.5" fill={`url(#${id}o)`} /><ellipse cx="130" cy="209" rx="23" ry="10.5" fill={`url(#${id}o)`} />
      </g>
      <g stroke="#e08a10" strokeWidth="2" fill="none" opacity=".5"><path d="M58 214 v-4 M70 216 v-4 M82 214 v-4 M118 214 v-4 M130 216 v-4 M142 214 v-4" /></g>
      {/* 날개 */}
      <g fill={bodyFill} stroke={stroke} strokeWidth="3" strokeLinejoin="round">
        <path d="M48 122 C22 126 8 160 16 178 C24 192 46 178 58 152 C61 140 57 128 48 122Z" />
        <path d="M152 122 C178 126 192 160 184 178 C176 192 154 178 142 152 C139 140 143 128 152 122Z" />
      </g>
      <g fill="#fff" opacity=".28"><ellipse cx="28" cy="158" rx="5" ry="14" transform="rotate(18 28 158)" /><ellipse cx="172" cy="158" rx="5" ry="14" transform="rotate(-18 172 158)" /></g>
      {/* 몸 */}
      <path d="M100 100 C55 100 38 150 42 180 C46 208 70 214 100 214 C130 214 154 208 158 180 C162 150 145 100 100 100Z" fill={bodyFill} stroke={stroke} strokeWidth="3" />
      <g clipPath={`url(#${id}cb)`}>
        {pattern(pat, patCol, BODY_PTS, [128, 156, 184])}
        {fx === 'candy' && BODY_PTS.map((p, i) => <circle key={i} cx={p[0] + 4} cy={p[1] - 4} r="4" fill="#fff" opacity=".6" />)}
        {fx === 'galaxy' && <>{BODY_PTS.map((p, i) => <circle key={i} cx={p[0] + 8} cy={p[1] - 10} r={1.6 + (i % 3)} fill="#fff" className="tw" style={{ animationDelay: i * 0.3 + 's' }} />)}<ellipse cx="62" cy="150" rx="22" ry="16" fill="#ff7ad0" opacity=".25" /><ellipse cx="140" cy="190" rx="22" ry="14" fill="#5ad0ff" opacity=".25" /></>}
        {fx === 'rainbow' && <path d="M40 190 Q100 150 160 190" stroke="#fff" strokeWidth="6" opacity=".35" fill="none" />}
        <ellipse cx="64" cy="140" rx="9" ry="22" fill="#fff" opacity=".22" transform="rotate(14 64 140)" />
        <path d="M44 196 Q100 232 156 196" fill="#000" opacity=".07" />
      </g>
      <ellipse cx="100" cy="170" rx="35" ry="41" fill={`url(#${id}f)`} stroke={stroke} strokeWidth="1.5" strokeOpacity=".25" />
      <ellipse cx="88" cy="150" rx="9" ry="15" fill="#fff" opacity=".5" transform="rotate(15 88 150)" />
      {/* 머리 */}
      <ellipse cx="100" cy="78" rx="68" ry="62" fill={bodyFill} stroke={stroke} strokeWidth="3" />
      <g clipPath={`url(#${id}ch)`}>
        {pattern(pat, patCol, HEAD_PTS, [20, 36])}
        {fx === 'candy' && <><circle cx="56" cy="40" r="5" fill="#fff" opacity=".6" /><circle cx="140" cy="36" r="5" fill="#fff" opacity=".6" /><circle cx="100" cy="30" r="4" fill="#fff" opacity=".6" /></>}
        {fx === 'galaxy' && <>{HEAD_PTS.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r={1.5 + (i % 3)} fill="#fff" className="tw" style={{ animationDelay: i * 0.25 + 's' }} />)}<ellipse cx="150" cy="46" rx="26" ry="14" fill="#ff7ad0" opacity=".25" /></>}
        {fx === 'rainbow' && <path d="M40 60 Q100 -10 160 60" stroke="#fff" strokeWidth="7" opacity=".3" fill="none" />}
      </g>
      {/* 얼굴 흰 부분 (하트형) */}
      <path d="M100 120 C70 126 38 110 35 84 C33 62 52 50 70 56 C84 60 95 70 100 82 C105 70 116 60 130 56 C148 50 167 62 165 84 C162 110 130 126 100 120Z" fill={`url(#${id}f)`} stroke={stroke} strokeWidth="1.2" strokeOpacity=".3" />
      {/* 볼터치 */}
      <ellipse cx="50" cy="106" rx="11" ry="7" fill={cheek} opacity=".7" /><ellipse cx="150" cy="106" rx="11" ry="7" fill={cheek} opacity=".7" />
      <path d="M44 106 l3 -3 M50 109 l3 -3 M56 107 l3 -3 M144 107 l3 -3 M150 109 l3 -3 M156 106 l3 -3" stroke="#fff" strokeWidth="1.2" opacity=".7" />
      {/* 눈 */}
      {[72, 128].map((x, i) => (
        <g key={x} className={blinkCls} style={blinkStyle}>
          <ellipse cx={x} cy="88" rx="16.5" ry="18.5" fill="#1b1830" />
          <ellipse cx={x} cy="94" rx="12.5" ry="11.5" fill={eyeCol} opacity=".6" />
          <path d={`M${x - 15} ${82 - i * 0} Q${x} ${68} ${x + 15} 82`} stroke="#1b1830" strokeWidth="3" fill="none" strokeLinecap="round" />
          <circle cx={x - 5.5} cy="81" r="6.8" fill="#fff" /><circle cx={x + 6.5} cy="96" r="3.2" fill="#fff" opacity=".95" /><circle cx={x + 7} cy="79" r="1.8" fill="#fff" />
        </g>
      ))}
      {/* 부리 */}
      <path d="M88 99 Q100 92 112 99 Q111 113 100 114 Q89 113 88 99Z" fill={`url(#${id}o)`} stroke="#e08a10" strokeWidth="2" strokeLinejoin="round" />
      <ellipse cx="97" cy="99" rx="5" ry="2" fill="#fff" opacity=".6" />
      <path d="M96 107 Q100 110 104 107" stroke="#e08a10" strokeWidth="1.5" fill="none" strokeLinecap="round" opacity=".7" />
      {/* 머리 하이라이트 + 삐죽머리 */}
      <ellipse cx="66" cy="38" rx="22" ry="9" fill="#fff" opacity=".4" transform="rotate(-24 66 38)" />
      {acc === 'none' && <path d="M96 18 Q92 4 100 6 Q104 8 102 18 M104 18 Q112 6 118 12" stroke={stroke} strokeWidth="3" fill="none" strokeLinecap="round" />}
      {fx === 'sparkle' && <g><Sparkle x={34} y={44} s={1.1} /><Sparkle x={168} y={110} s={1.3} d={0.7} /><Sparkle x={30} y={170} s={1} d={1.2} /><Sparkle x={172} y={50} s={0.8} d={0.3} /></g>}
      {fx === 'galaxy' && <g><Sparkle x={30} y={60} s={1.1} fill="#ffe6ff" /><Sparkle x={172} y={170} s={1.2} fill="#c8e8ff" d={0.9} /></g>}
      {fx === 'rainbow' && <g><Sparkle x={32} y={40} s={1} fill="#fff7b0" /><Sparkle x={170} y={128} s={1} fill="#ffd0f0" d={1} /></g>}
      {ac.front}
    </svg>
  );
});

export default Penguin;
