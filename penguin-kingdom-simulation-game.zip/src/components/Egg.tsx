import { memo, useId } from 'react';
import { EGGS } from '../data/penguinData';

interface Props { type: number; size?: number; crack?: number; c1?: string; c2?: string; className?: string; style?: React.CSSProperties }

const PATH = 'M50 6 C76 6 94 50 94 82 C94 110 74 126 50 126 C26 126 6 110 6 82 C6 50 24 6 50 6Z';

export const EggArt = memo(function EggArt({ type, size = 80, crack = 0, c1, c2, className, style }: Props) {
  const rid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const bred = type < 0;
  const e = bred ? { base: c1 || '#fff', accent: c2 || '#fbb', spot: '#fff', pat: 'hearts' } : EGGS[type];
  const id = 'eg' + rid;
  const rainbow = e.pat === 'rainbow';
  const galaxy = e.pat === 'galaxy';
  return (
    <svg viewBox="0 0 100 135" width={size} height={size * 1.35} className={className} style={style} overflow="visible">
      <defs>
        {rainbow ? (
          <linearGradient id={id} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#ffc2d0" /><stop offset=".3" stopColor="#fff0a8" /><stop offset=".6" stopColor="#b8f0c0" /><stop offset="1" stopColor="#b8d8ff" /></linearGradient>
        ) : bred ? (
          <linearGradient id={id} x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor={e.base} /><stop offset=".48" stopColor={e.base} /><stop offset=".52" stopColor={e.accent} /><stop offset="1" stopColor={e.accent} /></linearGradient>
        ) : (
          <radialGradient id={id} cx=".35" cy=".3" r=".9"><stop offset="0" stopColor="#fff" stopOpacity=".9" /><stop offset=".25" stopColor={e.base} /><stop offset="1" stopColor={galaxy ? '#1a1050' : e.accent} /></radialGradient>
        )}
        <clipPath id={id + 'c'}><path d={PATH} /></clipPath>
      </defs>
      <ellipse cx="50" cy="128" rx="34" ry="6" fill="#2a4a6a" opacity=".18" />
      <path d={PATH} fill={`url(#${id})`} stroke="#fff" strokeWidth="3" />
      <path d={PATH} fill="none" stroke={e.accent} strokeOpacity=".6" strokeWidth="1.5" />
      <g clipPath={`url(#${id}c)`}>
        {e.pat === 'dots' && [[30, 40], [64, 36], [46, 62], [22, 80], [74, 74], [40, 98], [66, 104], [50, 22]].map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r={5 + (i % 3)} fill={e.spot} opacity=".85" />)}
        {e.pat === 'stripes' && [34, 56, 78, 100].map((y, i) => <path key={i} d={`M0 ${y} Q25 ${y - 8} 50 ${y} T100 ${y}`} stroke={e.spot} strokeWidth="7" fill="none" opacity=".8" />)}
        {(e.pat === 'hearts') && [[30, 44], [66, 40], [48, 72], [26, 96], [72, 90]].map((p, i) => <path key={i} transform={`translate(${p[0]} ${p[1]}) scale(${1.2 + (i % 2) * 0.5})`} d="M0 5 C-9 -1 -7 -9 0 -4 C7 -9 9 -1 0 5Z" fill={bred ? '#ff7aa8' : e.spot} opacity=".9" />)}
        {(e.pat === 'stars' || galaxy) && [[30, 40], [66, 34], [50, 66], [24, 90], [74, 86], [46, 108]].map((p, i) => <path key={i} className="tw" style={{ animationDelay: i * 0.3 + 's' }} transform={`translate(${p[0]} ${p[1]}) scale(${0.8 + (i % 3) * 0.3})`} d="M0 -8 Q1 -1 8 0 Q1 1 0 8 Q-1 1 -8 0 Q-1 -1 0 -8Z" fill={galaxy ? '#fff' : e.spot} />)}
        {galaxy && <><ellipse cx="38" cy="50" rx="20" ry="12" fill={e.accent} opacity=".3" /><ellipse cx="66" cy="96" rx="22" ry="12" fill="#5ad0ff" opacity=".3" /></>}
        {rainbow && <path d="M0 96 Q50 56 100 96" stroke="#fff" strokeWidth="7" fill="none" opacity=".5" />}
        {crack >= 1 && <path d="M30 40 L42 52 L36 62 L50 74" stroke="#7a5a3a" strokeWidth="2.5" fill="none" strokeLinejoin="round" />}
        {crack >= 2 && <path d="M70 34 L62 48 L72 58 L60 72 M50 74 L58 88 L48 98" stroke="#7a5a3a" strokeWidth="2.5" fill="none" strokeLinejoin="round" />}
        {crack >= 3 && <path d="M14 74 L28 70 L34 82 L22 94 M86 80 L74 86 L70 100" stroke="#7a5a3a" strokeWidth="2.5" fill="none" strokeLinejoin="round" />}
      </g>
      <ellipse cx="32" cy="38" rx="9" ry="16" fill="#fff" opacity=".6" transform="rotate(24 32 38)" />
      <circle cx="26" cy="64" r="3" fill="#fff" opacity=".6" />
    </svg>
  );
});

export default EggArt;
