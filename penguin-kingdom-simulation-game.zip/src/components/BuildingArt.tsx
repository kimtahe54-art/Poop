import { memo } from 'react';
import type { ReactNode } from 'react';
import type { BDef } from '../data/buildings';

export function shade(hex: string, amt: number) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  const f = (v: number) => Math.max(0, Math.min(255, Math.round(amt >= 0 ? v + (255 - v) * amt : v * (1 + amt))));
  r = f(r); g = f(g); b = f(b);
  return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

const Badge = ({ x, y, r = 15, icon }: { x: number; y: number; r?: number; icon: string }) => (
  <g>
    <circle cx={x} cy={y} r={r} fill="#fff" stroke="#0002" strokeWidth="2" />
    <circle cx={x} cy={y} r={r - 3} fill="#fff" stroke="#ffd6e8" strokeWidth="1.5" />
    <text x={x} y={y + r * 0.38} textAnchor="middle" fontSize={r * 1.15}>{icon}</text>
  </g>
);
const Window = ({ x, y, w = 24, h = 26 }: { x: number; y: number; w?: number; h?: number }) => (
  <g>
    <rect x={x} y={y} width={w} height={h} rx="6" fill="#fff0a8" stroke="#8a6a3a" strokeWidth="2.5" />
    <path d={`M${x + w / 2} ${y} V${y + h} M${x} ${y + h / 2} H${x + w}`} stroke="#8a6a3a" strokeWidth="2" />
    <rect x={x + 3} y={y + 3} width="6" height="8" rx="2" fill="#fff" opacity=".7" />
  </g>
);
const Door = ({ x, y, w = 28, h = 46, c }: { x: number; y: number; w?: number; h?: number; c: string }) => (
  <g>
    <path d={`M${x} ${y + h} V${y + w / 2} A${w / 2} ${w / 2} 0 0 1 ${x + w} ${y + w / 2} V${y + h}Z`} fill={c} stroke="#0003" strokeWidth="2.5" />
    <circle cx={x + w - 6} cy={y + h * 0.6} r="2.5" fill="#ffd84a" />
  </g>
);
const Snow = ({ d }: { d: string }) => <path d={d} fill="#fff" stroke="#cfe6f5" strokeWidth="1.5" strokeLinejoin="round" />;

function tpl(def: BDef): ReactNode {
  const w = def.wall, r = def.roof, dk = shade(r, -0.25), wd = shade(w, -0.2), ic = def.icon;
  switch (def.tpl) {
    case 'igloo':
      return <g>
        <path d="M12 176 A68 68 0 0 1 148 176Z" fill={w} stroke={wd} strokeWidth="3" />
        <path d="M22 140 H138 M16 158 H144 M44 108 H116 M30 124 H130 M80 66 V108 M60 108 V140 M100 108 V140 M40 140 V158 M80 140 V158 M120 140 V158" stroke={wd} strokeWidth="2" opacity=".5" fill="none" />
        <path d="M30 100 Q50 66 84 60" stroke="#fff" strokeWidth="6" strokeLinecap="round" fill="none" opacity=".7" />
        <path d="M54 176 V140 Q54 120 80 120 Q106 120 106 140 V176Z" fill={dk} stroke="#0003" strokeWidth="3" />
        <path d="M54 176 V150 Q54 130 80 130 Q106 130 106 150 V176Z" fill="#3a2a4a" opacity=".55" />
        <rect x="70" y="30" width="20" height="12" rx="6" fill={r} />
        <Badge x={80} y={92} icon={ic} />
      </g>;
    case 'round':
      return <g>
        <rect x="26" y="80" width="108" height="94" rx="14" fill={w} stroke={wd} strokeWidth="3" />
        <path d="M14 86 Q80 -6 146 86Z" fill={r} stroke={dk} strokeWidth="3" strokeLinejoin="round" />
        <path d="M34 72 Q60 28 86 18" stroke="#fff" strokeWidth="6" strokeLinecap="round" fill="none" opacity=".4" />
        <Snow d="M30 64 Q50 36 80 24 Q110 36 130 64 Q120 74 110 64 Q100 76 90 64 Q80 76 70 64 Q60 76 50 64 Q40 74 30 64Z" />
        <Door x={66} y={126} c={dk} />
        <circle cx="44" cy="112" r="12" fill="#fff0a8" stroke="#8a6a3a" strokeWidth="2.5" /><circle cx="116" cy="112" r="12" fill="#fff0a8" stroke="#8a6a3a" strokeWidth="2.5" />
        <Badge x={80} y={104} r={13} icon={ic} />
        <circle cx="80" cy="14" r="6" fill="#ffd84a" stroke="#d09a10" strokeWidth="2" />
      </g>;
    case 'tower':
      return <g>
        <rect x="42" y="58" width="76" height="116" rx="8" fill={w} stroke={wd} strokeWidth="3" />
        <path d="M30 64 L80 8 L130 64Z" fill={r} stroke={dk} strokeWidth="3" strokeLinejoin="round" />
        <Snow d="M38 58 L80 14 L122 58 Q112 66 104 58 Q92 68 80 58 Q68 68 56 58 Q46 66 38 58Z" />
        <Window x={68} y={72} w={24} h={26} /><Window x={52} y={108} w={20} h={22} /><Window x={88} y={108} w={20} h={22} />
        <Door x={66} y={134} c={dk} w={28} h={40} />
        <Badge x={80} y={160} r={0.01} icon="" />
        <path d="M80 8 V-12 L100 -6 L80 0" fill="#ff6fa5" stroke="#c43d7a" strokeWidth="2" />
        <circle cx="52" cy="82" r="11" fill="#fff" stroke="#0002" strokeWidth="2" /><text x="52" y="86" textAnchor="middle" fontSize="13">{ic}</text>
      </g>;
    case 'dome':
      return <g>
        <rect x="18" y="130" width="124" height="44" rx="10" fill={w} stroke={wd} strokeWidth="3" />
        <path d="M24 134 A56 62 0 0 1 136 134Z" fill="#dff6ff" stroke={r} strokeWidth="4" opacity=".95" />
        <path d="M80 72 V134 M52 82 Q50 110 52 134 M108 82 Q110 110 108 134 M30 112 H130" stroke={r} strokeWidth="2.5" opacity=".6" fill="none" />
        <path d="M40 106 Q48 80 70 72" stroke="#fff" strokeWidth="6" strokeLinecap="round" fill="none" />
        <circle cx="80" cy="12" r="6" fill={r} /><path d="M80 18 V72" stroke={r} strokeWidth="3" />
        <Door x={64} y={134} w={32} h={40} c={dk} />
        <Badge x={80} y={106} r={17} icon={ic} />
      </g>;
    case 'shop': {
      const stripes: ReactNode[] = [];
      for (let i = 0; i < 6; i++) stripes.push(<path key={i} d={`M${14 + i * 22} 62 H${36 + i * 22} V80 A11 11 0 0 1 ${14 + i * 22} 80Z`} fill={i % 2 ? '#fff' : r} stroke={dk} strokeWidth="2" />);
      return <g>
        <rect x="16" y="64" width="128" height="110" rx="8" fill={w} stroke={wd} strokeWidth="3" />
        <rect x="12" y="52" width="136" height="14" rx="6" fill={r} stroke={dk} strokeWidth="3" />
        <Snow d="M14 52 Q30 38 50 46 Q80 32 110 46 Q130 38 146 52 Q136 56 128 52 Q118 60 108 52 Q98 60 88 52 Q78 60 68 52 Q58 60 48 52 Q38 60 28 52Z" />
        {stripes}
        <rect x="26" y="106" width="64" height="48" rx="8" fill="#e8f8ff" stroke="#8a6a3a" strokeWidth="3" />
        <path d="M34 114 L50 114 L34 130Z" fill="#fff" opacity=".8" />
        <text x="58" y="144" textAnchor="middle" fontSize="26">{ic}</text>
        <Door x={104} y={112} w={26} h={62} c={dk} />
        <rect x="48" y="14" width="64" height="26" rx="10" fill="#fff" stroke={dk} strokeWidth="3" /><text x="80" y="34" textAnchor="middle" fontSize="20">{ic}</text>
        <path d="M60 40 V52 M100 40 V52" stroke={dk} strokeWidth="3" />
      </g>;
    }
    case 'castle':
      return <g>
        <rect x="46" y="62" width="68" height="112" fill={w} stroke={wd} strokeWidth="3" />
        <path d="M46 62 V50 H56 V58 H66 V50 H76 V58 H86 V50 H96 V58 H104 V50 H114 V62Z" fill={w} stroke={wd} strokeWidth="3" strokeLinejoin="round" />
        {[[6, 80], [114, 80]].map(([x, h], i) => <g key={i}>
          <rect x={x} y={h} width="40" height={176 - h} fill={w} stroke={wd} strokeWidth="3" />
          <path d={`M${x - 6} ${h + 6} L${x + 20} ${h - 46} L${x + 46} ${h + 6}Z`} fill={r} stroke={dk} strokeWidth="3" strokeLinejoin="round" />
          <path d={`M${x + 20} ${h - 46} V${h - 64} L${x + 36} ${h - 58} L${x + 20} ${h - 52}`} fill="#ff6fa5" stroke="#c43d7a" strokeWidth="2" />
          <Window x={x + 12} y={h + 18} w={16} h={22} />
        </g>)}
        <path d="M60 176 V132 A20 20 0 0 1 100 132 V176Z" fill={dk} stroke="#0003" strokeWidth="3" />
        <path d="M70 176 V136 M80 176 V132 M90 176 V136" stroke="#0004" strokeWidth="2" />
        <Badge x={80} y={92} r={16} icon={ic} />
        <path d="M80 50 V26 L100 32 L80 38" fill={r} stroke={dk} strokeWidth="2" />
      </g>;
    case 'pagoda':
      return <g>
        <rect x="34" y="136" width="92" height="38" fill={w} stroke={wd} strokeWidth="3" />
        <rect x="46" y="94" width="68" height="34" fill={w} stroke={wd} strokeWidth="3" />
        <rect x="58" y="56" width="44" height="30" fill={w} stroke={wd} strokeWidth="3" />
        {[[134, 0, 1], [92, 6, 0.78], [54, 14, 0.58]].map(([y, , s], i) => <path key={i} d={`M${80 - 76 * s} ${y + 2} Q${80 - 54 * s} ${y - 2} ${80 - 40 * s} ${y - 20 * s - 6} L${80 + 40 * s} ${y - 20 * s - 6} Q${80 + 54 * s} ${y - 2} ${80 + 76 * s} ${y + 2} Q${80} ${y + 12} ${80 - 76 * s} ${y + 2}Z`} fill={r} stroke={dk} strokeWidth="3" strokeLinejoin="round" />)}
        <path d="M80 36 V14 M72 24 H88" stroke="#d09a10" strokeWidth="3" /><circle cx="80" cy="12" r="5" fill="#ffd84a" stroke="#d09a10" strokeWidth="2" />
        <Door x={67} y={142} w={26} h={32} c={dk} />
        <Window x={58} y={100} w={18} h={20} /><Window x={86} y={100} w={18} h={20} />
        <Badge x={80} y={70} r={12} icon={ic} />
      </g>;
    case 'tent': {
      const st: ReactNode[] = [];
      for (let i = 0; i < 8; i++) { const a = 16 + i * 16; st.push(<path key={i} d={`M80 40 L${a} 172 L${a + 16} 172Z`} fill={i % 2 ? '#fff' : r} />); }
      return <g>
        {st}
        <path d="M16 172 L80 40 L144 172Z" fill="none" stroke={dk} strokeWidth="3.5" strokeLinejoin="round" />
        <path d="M60 172 L80 116 L100 172Z" fill="#3a2a4a" stroke={dk} strokeWidth="2.5" /><path d="M80 116 L72 172 M80 116 L88 172" stroke="#fff4" strokeWidth="2" />
        <path d="M80 40 V12 L102 20 L80 28" fill="#ffd84a" stroke="#d09a10" strokeWidth="2" />
        <Snow d="M62 62 L80 40 L98 62 Q90 68 80 62 Q70 68 62 62Z" />
        <Badge x={80} y={96} r={14} icon={ic} />
        <path d="M14 172 Q80 186 146 172" fill="none" stroke={dk} strokeWidth="3" />
      </g>;
    }
    case 'lighthouse':
      return <g>
        <path d="M46 176 L58 58 H102 L114 176Z" fill={w} stroke={wd} strokeWidth="3" strokeLinejoin="round" />
        <path d="M51 140 L110 140 L112 160 L49 160Z M55 98 L106 98 L108 118 L53 118Z" fill={r} opacity=".9" />
        <rect x="52" y="44" width="56" height="16" rx="4" fill="#fff" stroke={dk} strokeWidth="3" />
        <rect x="60" y="22" width="40" height="24" rx="6" fill="#fff6b0" stroke={dk} strokeWidth="3" className="tw" style={{ animationDuration: '2.5s' }} />
        <path d="M54 22 L80 0 L106 22Z" fill={r} stroke={dk} strokeWidth="3" strokeLinejoin="round" />
        <Door x={68} y={140} w={24} h={36} c={dk} />
        <Badge x={80} y={80} r={12} icon={ic} />
        <rect x="34" y="168" width="92" height="10" rx="5" fill="#cfe6f5" />
      </g>;
    case 'barn':
      return <g>
        <rect x="14" y="76" width="132" height="98" rx="6" fill={w} stroke={wd} strokeWidth="3" />
        <path d="M4 84 L28 34 H132 L156 84Z" fill={r} stroke={dk} strokeWidth="3" strokeLinejoin="round" />
        <Snow d="M12 80 L32 38 H128 L148 80 Q138 86 130 80 Q120 88 110 80 Q100 88 90 80 Q80 88 70 80 Q60 88 50 80 Q40 88 30 80 Q20 86 12 80Z" />
        <rect x="56" y="104" width="48" height="70" rx="4" fill={dk} stroke="#0003" strokeWidth="3" />
        <path d="M56 104 L104 174 M104 104 L56 174 M80 104 V174" stroke="#fff" strokeWidth="3.5" opacity=".85" />
        <Window x={24} y={96} /><Window x={112} y={96} />
        <circle cx="80" cy="56" r="12" fill="#fff" stroke={dk} strokeWidth="3" /><text x="80" y="62" textAnchor="middle" fontSize="15">{ic}</text>
      </g>;
    case 'cake':
      return <g>
        <rect x="14" y="124" width="132" height="50" rx="14" fill={w} stroke={wd} strokeWidth="3" />
        <rect x="30" y="86" width="100" height="42" rx="12" fill={shade(w, -0.06)} stroke={wd} strokeWidth="3" />
        <rect x="46" y="54" width="68" height="36" rx="12" fill={w} stroke={wd} strokeWidth="3" />
        {[[14, 124, 132], [30, 86, 100], [46, 54, 68]].map(([x, y, ww], i) => {
          const n = Math.round(ww / 18);
          let d = `M${x} ${y + 4} Q${x} ${y - 4} ${x + 10} ${y - 4} H${x + ww - 10} Q${x + ww} ${y - 4} ${x + ww} ${y + 4}`;
          for (let k = n; k > 0; k--) d += ` q-${ww / n / 2} 18 -${ww / n} 0`;
          return <path key={i} d={d + 'Z'} fill={r} stroke={shade(r, -0.25)} strokeWidth="2.5" />;
        })}
        <circle cx="80" cy="44" r="9" fill="#ff4a6a" stroke="#c42a4a" strokeWidth="2" /><circle cx="77" cy="41" r="2.5" fill="#fff" />
        <path d="M80 36 Q84 26 92 24" stroke="#4a8a3a" strokeWidth="2.5" fill="none" />
        <Door x={66} y={134} w={28} h={40} c={shade(r, -0.1)} />
        <Window x={24} y={142} w={20} h={20} /><Window x={116} y={142} w={20} h={20} />
        <Badge x={80} y={106} r={13} icon={ic} />
        {[[36, 124], [124, 124]].map((p, i) => <circle key={i} cx={p[0]} cy={p[1] + 22} r="0.1" />)}
      </g>;
    default: // house
      return <g>
        <rect x="22" y="80" width="116" height="94" rx="8" fill={w} stroke={wd} strokeWidth="3" />
        <path d="M8 92 L80 22 L152 92Z" fill={r} stroke={dk} strokeWidth="3" strokeLinejoin="round" />
        <path d="M28 82 L76 36" stroke="#fff" strokeWidth="5" strokeLinecap="round" opacity=".4" />
        <Snow d="M24 80 L80 26 L136 80 Q126 88 116 80 Q106 90 96 80 Q86 90 76 80 Q66 90 56 80 Q46 90 36 80 Q28 86 24 80Z" />
        <rect x="108" y="30" width="16" height="30" fill={dk} stroke="#0003" strokeWidth="2" /><Snow d="M106 32 Q116 24 126 32 Q116 38 106 32Z" />
        <Window x={32} y={108} /><Window x={104} y={108} />
        <Door x={66} y={124} c={dk} />
        <Badge x={80} y={98} r={13} icon={ic} />
        <path d="M22 174 H138" stroke={wd} strokeWidth="3" />
      </g>;
  }
}

export const BuildingArt = memo(function BuildingArt({ def, glow }: { def: BDef; glow?: boolean }) {
  return (
    <g transform={`scale(${def.scale}) translate(-80 -176)`} style={glow ? { filter: 'drop-shadow(0 0 8px #fff) drop-shadow(0 0 14px #ff5fae)' } : undefined}>
      <ellipse cx="80" cy="176" rx="70" ry="8" fill="#2a4a6a" opacity=".16" />
      {tpl(def)}
    </g>
  );
});

export function BuildingPreview({ def, size = 80 }: { def: BDef; size?: number }) {
  return (
    <svg viewBox="-10 -20 180 210" width={size} height={size * 210 / 180}>
      <g transform="translate(80 176)"><BuildingArt def={{ ...def, scale: 1 }} /></g>
    </svg>
  );
}
