import { memo } from 'react';
import type { ReactNode } from 'react';
import { shade } from './BuildingArt';

export interface SeaDef { id: number; name: string; price: number; kind: string; c1: string; c2: string; zone: 'swim' | 'bottom'; size: number }

const L: [string, number, string, string, string][] = [
  ['네온 테트라', 80, 'fish', '#4ac8ff', '#ff5a7a'], ['니모 물고기', 100, 'fish', '#ff8a30', '#ffffff'], ['블루탱', 120, 'fish', '#3a7aff', '#ffd84a'],
  ['핑크 엔젤피시', 150, 'fish', '#ff9ac8', '#ffffff'], ['레몬 나비고기', 130, 'fish', '#ffe24a', '#ffffff'], ['민트 베타', 180, 'fish', '#5af0c8', '#a8ff8a'],
  ['라벤더 구피', 160, 'fish', '#b08aff', '#ffc8f0'], ['무지개 물고기', 600, 'fish', 'rainbow', '#ffffff'], ['황금 잉어', 500, 'fish', '#ffc83a', '#fff6c0'],
  ['체리 베타', 220, 'fish', '#ff5a7a', '#ffb0c0'], ['별무늬 물고기', 300, 'fish', '#7a8aff', '#ffffff'], ['사탕 물고기', 350, 'fish', '#ff8ad0', '#8ae0ff'],
  ['오로라 물고기', 700, 'fish', '#8affd8', '#b08aff'], ['솜사탕 물고기', 400, 'fish', '#ffc8f0', '#c8e8ff'],
  ['노랑 복어', 250, 'puffer', '#ffd84a', '#fff6c0'], ['파랑 복어', 280, 'puffer', '#6ac8ff', '#e0f6ff'],
  ['핑크 해파리', 300, 'jelly', '#ff9ac8', '#ffe0f0'], ['하늘 해파리', 320, 'jelly', '#8ad8ff', '#e0f6ff'], ['보라 해파리', 380, 'jelly', '#b08aff', '#eadfff'], ['민트 해파리', 340, 'jelly', '#8affd0', '#e0fff4'],
  ['분홍 문어', 450, 'octopus', '#ff8ab8', '#ffd0e4'], ['보라 문어', 500, 'octopus', '#a888ff', '#e0d4ff'], ['주황 문어', 480, 'octopus', '#ff9a58', '#ffd8b8'],
  ['분홍 불가사리', 120, 'star', '#ff8ab8', '#ffd0e4'], ['주황 불가사리', 120, 'star', '#ffa04a', '#ffd8b0'], ['노랑 불가사리', 140, 'star', '#ffe04a', '#fff6b0'],
  ['빨간 꽃게', 260, 'crab', '#ff6a5a', '#ffc0b8'], ['분홍 꽃게', 300, 'crab', '#ff9ab8', '#ffd8e4'],
  ['초록 바다거북', 650, 'turtle', '#5ad88a', '#d8b878'], ['파랑 바다거북', 750, 'turtle', '#5ab8ff', '#e8c888'],
  ['파랑 아기고래', 1200, 'whale', '#5aa8ff', '#e0f0ff'], ['핑크 아기고래', 1500, 'whale', '#ff9ac8', '#ffe8f4'],
  ['노랑 해마', 350, 'seahorse', '#ffd84a', '#fff0a0'], ['보라 해마', 400, 'seahorse', '#b08aff', '#e4d8ff'],
];
export const SEA: SeaDef[] = L.map((l, i) => ({
  id: i, name: l[0], price: l[1], kind: l[2], c1: l[3], c2: l[4],
  zone: l[2] === 'star' || l[2] === 'crab' ? 'bottom' : 'swim',
  size: l[2] === 'whale' ? 1.8 : l[2] === 'turtle' ? 1.4 : l[2] === 'octopus' ? 1.3 : l[2] === 'seahorse' ? 1.1 : l[2] === 'fish' ? 1 : 1.1,
}));

const Face = ({ x, y, s = 1 }: { x: number; y: number; s?: number }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle r="6.5" fill="#fff" /><circle cx="1.5" cy="0.5" r="4.4" fill="#2a2040" /><circle cx="0" cy="-1.8" r="1.8" fill="#fff" /><circle cx="3" cy="2" r="0.9" fill="#fff" />
  </g>
);
const Blush = ({ x, y }: { x: number; y: number }) => <ellipse cx={x} cy={y} rx="4.5" ry="3" fill="#ff7aa8" opacity=".5" />;

function draw(d: SeaDef): ReactNode {
  const { c1, c2 } = d;
  const dk = c1 === 'rainbow' ? '#a070e0' : shade(c1, -0.28);
  switch (d.kind) {
    case 'fish': {
      const fill = c1 === 'rainbow' ? 'url(#seaRb)' : c1;
      return <g>
        <path d="M-20 0 Q-34 -22 -50 -18 Q-42 0 -50 18 Q-34 22 -20 0Z" fill={c1 === 'rainbow' ? '#ffb0d0' : shade(c1, 0.15)} stroke={dk} strokeWidth="2.5" strokeLinejoin="round" style={{ transformOrigin: '-20px 0px', animation: 'shake 0.8s infinite' }} />
        <path d="M-8 -17 Q4 -34 16 -16Z" fill={c1 === 'rainbow' ? '#ffd0a0' : shade(c1, 0.1)} stroke={dk} strokeWidth="2.5" strokeLinejoin="round" />
        <ellipse cx="0" cy="0" rx="30" ry="21" fill={fill} stroke={dk} strokeWidth="2.5" />
        <clipPath id="fishClip"><ellipse cx="0" cy="0" rx="30" ry="21" /></clipPath>
        <g clipPath="url(#fishClip)" fill={c2} opacity=".85"><rect x="-14" y="-24" width="7" height="48" /><rect x="-2" y="-24" width="5" height="48" /></g>
        <ellipse cx="-4" cy="-12" rx="14" ry="5" fill="#fff" opacity=".4" />
        <path d="M-6 8 Q2 20 12 10Q4 12 -6 8Z" fill={shade(c1 === 'rainbow' ? '#ffb0d0' : c1, 0.2)} stroke={dk} strokeWidth="1.5" />
        <Face x={17} y={-4} /><Blush x={14} y={8} /><path d="M22 6 Q26 9 29 5" stroke={dk} strokeWidth="2" fill="none" strokeLinecap="round" />
      </g>;
    }
    case 'puffer':
      return <g>
        {[0, 40, 80, 120, 160, 200, 240, 280, 320].map((r) => <path key={r} d="M0 -26 L-3.5 -34 L3.5 -34Z" fill={dk} transform={`rotate(${r})`} />)}
        <path d="M-24 0 Q-38 -12 -42 -6 Q-36 0 -42 8 Q-36 12 -24 0Z" fill={shade(c1, 0.1)} stroke={dk} strokeWidth="2.5" />
        <circle r="27" fill={c1} stroke={dk} strokeWidth="2.5" /><ellipse cx="0" cy="10" rx="20" ry="13" fill={c2} opacity=".9" />
        <ellipse cx="-6" cy="-14" rx="11" ry="5" fill="#fff" opacity=".45" />
        <Face x={11} y={-5} s={1.2} /><Blush x={8} y={9} /><circle cx="22" cy="5" r="3" fill="#ff8a8a" />
      </g>;
    case 'jelly':
      return <g>
        {[-14, -5, 5, 14].map((x, i) => <path key={x} d={`M${x} 6 Q${x + 6} 18 ${x - 2} 28 Q${x + 4} 38 ${x} 46`} stroke={c1} strokeWidth="4" fill="none" strokeLinecap="round" opacity=".8" style={{ animation: `bob ${1.2 + i * 0.2}s ease-in-out infinite` }} />)}
        <path d="M-30 6 A30 30 0 0 1 30 6 Q20 12 10 6 Q0 12 -10 6 Q-20 12 -30 6Z" fill={c1} fillOpacity=".85" stroke={dk} strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M-20 -12 Q-14 -22 -4 -22" stroke="#fff" strokeWidth="4" fill="none" strokeLinecap="round" opacity=".8" />
        <circle cx="-14" cy="-6" r="3" fill={c2} /><circle cx="14" cy="-10" r="3.5" fill={c2} />
        <Face x={-8} y={-2} s={0.9} /><Face x={8} y={-2} s={0.9} /><Blush x={-18} y={4} /><Blush x={18} y={4} />
      </g>;
    case 'octopus':
      return <g>
        {[-24, -12, 0, 12, 24].map((x, i) => <path key={x} d={`M${x} 10 Q${x * 1.6} 28 ${x * 1.2 + (i % 2 ? 8 : -8)} 38`} stroke={c1} strokeWidth="8" fill="none" strokeLinecap="round" style={{ animation: `bob ${1.4 + i * 0.15}s ease-in-out infinite` }} />)}
        <ellipse cx="0" cy="-8" rx="30" ry="30" fill={c1} stroke={dk} strokeWidth="2.5" />
        {[[-14, -22], [10, -26], [18, -14]].map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="3" fill={c2} />)}
        <ellipse cx="-12" cy="-22" rx="10" ry="5" fill="#fff" opacity=".4" />
        <Face x={-10} y={-4} s={1.1} /><Face x={10} y={-4} s={1.1} /><Blush x={-20} y={6} /><Blush x={20} y={6} /><path d="M-4 8 Q0 12 4 8" stroke={dk} strokeWidth="2" fill="none" strokeLinecap="round" />
      </g>;
    case 'star':
      return <g>
        <path d="M0 -28 L8 -9 L28 -9 L12 3 L18 24 L0 12 L-18 24 L-12 3 L-28 -9 L-8 -9Z" fill={c1} stroke={dk} strokeWidth="2.5" strokeLinejoin="round" />
        {[[0, -16], [-14, -2], [14, -2], [-9, 14], [9, 14]].map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="2.2" fill={c2} />)}
        <Face x={-6} y={0} s={0.7} /><Face x={6} y={0} s={0.7} /><Blush x={-12} y={6} /><Blush x={12} y={6} />
      </g>;
    case 'crab':
      return <g>
        <path d="M-24 -4 Q-40 -20 -32 -32 Q-22 -34 -22 -22" fill={c1} stroke={dk} strokeWidth="2.5" /><path d="M24 -4 Q40 -20 32 -32 Q22 -34 22 -22" fill={c1} stroke={dk} strokeWidth="2.5" />
        {[-18, -8, 8, 18].map((x) => <path key={x} d={`M${x} 10 L${x * 1.5} 22`} stroke={dk} strokeWidth="3" strokeLinecap="round" />)}
        <path d="M-8 -16 V-26 M8 -16 V-26" stroke={dk} strokeWidth="3" />
        <ellipse cx="0" cy="0" rx="28" ry="18" fill={c1} stroke={dk} strokeWidth="2.5" /><ellipse cx="-8" cy="-9" rx="10" ry="4" fill="#fff" opacity=".4" />
        <Face x={-8} y={-26} s={0.9} /><Face x={8} y={-26} s={0.9} /><Blush x={-16} y={4} /><Blush x={16} y={4} /><path d="M-5 5 Q0 10 5 5" stroke="#fff" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      </g>;
    case 'turtle':
      return <g>
        <ellipse cx="-24" cy="12" rx="8" ry="5" fill={c1} stroke={dk} strokeWidth="2" /><ellipse cx="14" cy="16" rx="9" ry="6" fill={c1} stroke={dk} strokeWidth="2" style={{ animation: 'shake 1s infinite' }} />
        <path d="M-30 4 L-42 8 L-32 -2Z" fill={c1} stroke={dk} strokeWidth="2" />
        <ellipse cx="32" cy="-2" rx="15" ry="13" fill={c1} stroke={dk} strokeWidth="2.5" />
        <path d="M-34 6 Q-34 -30 0 -30 Q28 -28 28 6Z" fill={c2} stroke="#8a6a38" strokeWidth="2.5" />
        <path d="M-14 -26 L-18 -6 M6 -29 L8 -6 M-34 0 L26 0 M-18 -6 L6 -6" stroke="#8a6a38" strokeWidth="2" opacity=".6" fill="none" />
        <ellipse cx="-8" cy="-22" rx="10" ry="4" fill="#fff" opacity=".4" />
        <Face x={36} y={-5} s={0.85} /><Blush x={34} y={5} /><path d="M38 4 Q41 7 44 3" stroke={dk} strokeWidth="1.8" fill="none" strokeLinecap="round" />
      </g>;
    case 'whale':
      return <g>
        <path d="M-36 4 Q-52 -8 -50 -24 Q-38 -22 -30 -12 Q-24 -24 -14 -26 Q-20 -6 -24 4Z" fill={c1} stroke={dk} strokeWidth="2.5" strokeLinejoin="round" style={{ transformOrigin: '-30px 0px', animation: 'shake 2s infinite' }} />
        <path d="M-40 6 C-40 -28 -10 -34 18 -32 C44 -30 52 -10 48 10 C44 26 20 28 -10 24 C-26 20 -40 18 -40 6Z" fill={c1} stroke={dk} strokeWidth="2.5" />
        <path d="M-6 24 C20 28 44 26 48 10 C30 18 10 14 -6 24Z" fill={c2} />
        <path d="M0 -34 Q-6 -46 -14 -48 M0 -34 Q6 -46 14 -48 M0 -34 V-48" stroke="#8ad8ff" strokeWidth="3" fill="none" strokeLinecap="round" />
        <ellipse cx="-6" cy="-22" rx="16" ry="5" fill="#fff" opacity=".4" />
        <Face x={26} y={-6} s={1.2} /><Blush x={22} y={8} /><path d="M32 10 Q38 14 44 8" stroke={dk} strokeWidth="2.2" fill="none" strokeLinecap="round" />
        <path d="M-2 10 Q8 24 18 14" fill={shade(c1, 0.2)} stroke={dk} strokeWidth="2" />
      </g>;
    case 'seahorse':
      return <g>
        <path d="M-4 20 Q-20 24 -20 36 Q-16 44 -8 38 Q-12 34 -8 30" stroke={c1} strokeWidth="8" fill="none" strokeLinecap="round" />
        <path d="M-6 -22 Q-20 -6 -10 12 Q-2 26 4 22 Q14 14 8 -4 Q4 -16 8 -22Z" fill={c1} stroke={dk} strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M-8 -18 Q-24 -24 -18 -34 Q-12 -28 -6 -26" fill={c1} stroke={dk} strokeWidth="2.5" />
        <path d="M4 -26 Q22 -34 26 -22 Q28 -16 14 -16Z" fill={c1} stroke={dk} strokeWidth="2.5" strokeLinejoin="round" />
        <ellipse cx="2" cy="6" rx="5" ry="12" fill={c2} opacity=".9" />
        <path d="M-8 -6 Q-18 0 -12 8" stroke={dk} strokeWidth="2" fill="none" /><path d="M0 -30 L2 -40 L6 -30 M-8 -26 L-10 -36" stroke={shade(c1, 0.1)} strokeWidth="3" fill="none" strokeLinecap="round" />
        <Face x={10} y={-22} s={0.8} /><Blush x={12} y={-14} />
      </g>;
    default: return null;
  }
}

export const SeaArt = memo(function SeaArt({ d }: { d: SeaDef }) {
  return <g transform={`scale(${d.size})`}>{draw(d)}</g>;
});

export function SeaDefs() {
  return (
    <defs>
      <linearGradient id="seaRb" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#ff9aa8" /><stop offset=".3" stopColor="#ffe08a" /><stop offset=".6" stopColor="#a8f0a8" /><stop offset="1" stopColor="#a8c8ff" /></linearGradient>
    </defs>
  );
}

export function SeaPreview({ d, size = 70 }: { d: SeaDef; size?: number }) {
  return <svg viewBox="-70 -60 140 120" width={size} height={size * 120 / 140}><SeaDefs /><g transform={`scale(${1 / Math.max(1, d.size * 0.85)})`}><SeaArt d={{ ...d, size: d.size }} /></g></svg>;
}
